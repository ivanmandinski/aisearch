/**
 * Hybrid Search - Consolidated JavaScript
 * All functionality in one file for better performance and maintainability
 * Version: 2.26.0
 * 
 * This file consolidates all JavaScript functionality from FrontendManager.php
 * to eliminate inline scripts and improve performance.
 */

(function($) {
    'use strict';
    
    // =========================================================================
    // GLOBAL VARIABLES
    // =========================================================================
    let searchTimeout;
    let suggestionTimeout;
    let currentQuery = '';
    let currentPage = 1;
    let isLoadingMore = false;
    let hasMoreResults = false;
    let allResults = [];
    let lastSearchQuery = '';
    let searchHistory = [];
    let suggestionsVisible = false;
    let selectedSuggestionIndex = -1;
    // Pagination/result state to avoid duplicates and use server offsets
    let paginationState = { offset: 0, nextOffset: 0, hasMore: false, query: '', pageSize: 0 };
    let seenResults = new Set();
    
    // =========================================================================
    // INITIALIZATION
    // =========================================================================
    $(document).ready(function() {
        // Wait a bit for wp_localize_script to load
        setTimeout(function() {
            initializeHybridSearch();
        }, 100);
    });
    
    function initializeHybridSearch() {
        // Check if hybridSearch object is available, create fallback if not
        // But preserve any existing properties (like isAdmin from PHP)
        if (typeof hybridSearch === 'undefined') {
            // Configuration object not found, using fallback
            window.hybridSearch = {
                ajaxUrl: '/wp-admin/admin-ajax.php',
                apiUrl: '',
                maxResults: 10,
                includeAnswer: false,
                aiInstructions: '',
                nonce: '',
                enableVoiceSearch: true,
                enableKeyboardShortcuts: true,
                isAdmin: false,
                showRankingTooltips: false
            };
        } else {
            // Preserve the PHP-provided hybridSearch object
            window.hybridSearch = hybridSearch;
        }
        
        // Initialize search functionality
        initializeSearchForm();
        initializeSearchResults();
        initializeFilters();
        initializeKeyboardShortcuts();
        
        // Set global instance for debugging
        window.hybridSearchInstance = {
            performSearch: performSearch,
            getCurrentQuery: () => currentQuery,
            getSearchHistory: () => searchHistory
        };
    }
    
    // =========================================================================
    // SEARCH FORM INITIALIZATION
    // =========================================================================
    function initializeSearchForm() {
        // Replace existing search forms with hybrid search form
        replaceSearchForms();
        
        // Also replace forms that might be loaded dynamically
        const observer = new MutationObserver(function(mutations) {
            mutations.forEach(function(mutation) {
                if (mutation.type === 'childList') {
                    replaceSearchForms();
                }
            });
        });
        
        observer.observe(document.body, {
            childList: true,
            subtree: true
        });
        
        // Handle clear button
        document.addEventListener('click', function(e) {
            if (e.target.classList.contains('hybrid-search-clear')) {
                const input = e.target.parentNode.querySelector('.hybrid-search-input');
                if (input) {
                    input.value = '';
                    input.focus();
                }
            }
        });
        
        // Handle search form submission
        document.addEventListener('submit', function(e) {
            if (e.target.classList.contains('hybrid-search-form')) {
                e.preventDefault();
                const input = e.target.querySelector('.hybrid-search-input');
                if (input && input.value.trim()) {
                    // Redirect to search page with query
                    const query = input.value.trim();
                    const searchUrl = window.location.origin + '/?s=' + encodeURIComponent(query);
                    window.location.href = searchUrl;
                }
            }
        });

        // Suggestions: debounce input and render list (optimized)
        let lastSuggestionQuery = '';
        document.addEventListener('input', function(e) {
            if (!e.target.classList.contains('hybrid-search-input')) return;
            const q = (e.target.value || '').trim();
            
            // Skip if query hasn't changed (performance optimization)
            if (q === lastSuggestionQuery) {
                return;
            }
            lastSuggestionQuery = q;
            
            clearTimeout(suggestionTimeout);
            if (q.length < 2) { hideSuggestions(); return; }
            
            // Optimized debounce: 250ms for better responsiveness
            suggestionTimeout = setTimeout(() => {
                renderSuggestions(q);
            }, 250);
        });
    }

    function hideSuggestions() {
        const box = document.getElementById('hybrid-search-suggestions');
        if (box) { box.innerHTML = ''; box.style.display = 'none'; suggestionsVisible = false; }
    }

    function renderSuggestions(query) {
        const box = document.getElementById('hybrid-search-suggestions');
        if (!box) return;
        // Very lightweight local suggestions: show last 5 history + current query variations
        const items = [];
        const unique = new Set();
        const add = (t) => { const k = String(t||'').trim(); if (!k || unique.has(k)) return; unique.add(k); items.push(k); };
        add(query);
        if (searchHistory && searchHistory.length) {
            for (let i = searchHistory.length - 1; i >= 0 && items.length < 6; i--) add(searchHistory[i]);
        }
        if (!items.length) { hideSuggestions(); return; }
        box.innerHTML = '<div class="hybrid-search-suggestions-list">' + items.map(t => (
            '<div class="suggestion-item" role="button" tabindex="0" data-q="'+escapeHtml(t)+'">'+escapeHtml(t)+'</div>'
        )).join('') + '</div>';
        box.style.display = 'block';
        suggestionsVisible = true;
        box.onclick = (evt) => {
            const el = evt.target.closest('.suggestion-item');
            if (!el) return;
            const q = el.getAttribute('data-q') || '';
            const input = document.querySelector('.hybrid-search-input');
            if (input) { input.value = q; }
            const searchUrl = window.location.origin + '/?s=' + encodeURIComponent(q);
            window.location.href = searchUrl;
        };
    }
    
    function replaceSearchForms() {
        // No-op: forms are rendered server-side by PHP (renderSearchForm)
    }
    
    function getCurrentSearchQuery() {
        const urlParams = new URLSearchParams(window.location.search);
        return urlParams.get('s') || '';
    }
    
    // =========================================================================
    // SEARCH RESULTS INITIALIZATION
    // =========================================================================
    function initializeSearchResults() {
        // Display search results if we're on a search page
        if (isSearchPage()) {
            displaySearchResults();
        }
    }
    
    function isSearchPage() {
        return window.location.pathname === '/' && window.location.search.includes('s=');
    }
    
    function displaySearchResults() {
        const resultsContainer = document.querySelector('.hybrid-search-results');
        
        if (!resultsContainer) {
            return;
        }
        
        const searchQuery = getCurrentSearchQuery();
        
        // Minimum query length validation (3 characters)
        if (!searchQuery || searchQuery.trim().length < 3) {
            if (searchQuery && searchQuery.trim().length > 0) {
                resultsContainer.innerHTML = '<div class="hybrid-search-empty"><div class="hybrid-search-empty-icon">✏️</div><h3 class="hybrid-search-empty-title">Keep typing...</h3><p class="hybrid-search-empty-description">Please enter at least 3 characters to search.</p></div>';
            } else {
                displayNoResults(resultsContainer);
            }
            return;
        }
        
        // Show loading state
        resultsContainer.innerHTML = '<div class="hybrid-search-loading">Searching...</div>';
        
        // Make AJAX call using fetch API (from inline script)
        const showAIAnswer = hybridSearch.includeAnswer || false;
        const aiInstructions = hybridSearch.aiInstructions || '';
        const filters = getFilterValues();
        const startTime = Date.now();
        
        // Update maxResults if limit filter changed
        if (filters.limit && parseInt(filters.limit) !== hybridSearch.maxResults) {
            hybridSearch.maxResults = parseInt(filters.limit);
        }
        
        // Build request body with filters
        const requestBody = [
            'action=hybrid_search',
            'query=' + encodeURIComponent(searchQuery),
            'limit=' + encodeURIComponent(String(hybridSearch.maxResults || 10)),
            'offset=0',
            'include_answer=1',
            'ai_instructions=' + encodeURIComponent(aiInstructions),
            'filter_type=' + encodeURIComponent(filters.type || ''),
            'filter_date=' + encodeURIComponent(filters.date || ''),
            'filter_sort=' + encodeURIComponent(filters.sort || 'relevance')
        ].join('&');
        
        fetch(hybridSearch.ajaxUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: requestBody
        })
        .then(response => {
            return response.json();
        })
        .then(data => {
            const timeTaken = (Date.now() - startTime) / 1000;
            const resultsArray = (data && data.data && Array.isArray(data.data.results)) ? data.data.results : [];

            if (data.success && data.data && data.data.results && data.data.results.length > 0) {
                // AI answer can be in two places due to WordPress wrapping
                let aiAnswer = '';
                if (data.data.metadata) {
                    // Check direct answer field
                    if (data.data.metadata.answer && data.data.metadata.answer.trim()) {
                        aiAnswer = data.data.metadata.answer;
                    }
                    // Check nested search_metadata.answer field
                    else if (data.data.metadata.search_metadata && data.data.metadata.search_metadata.answer && data.data.metadata.search_metadata.answer.trim()) {
                        aiAnswer = data.data.metadata.search_metadata.answer;
                    }
                }
                
                // Add AI answer to pagination data if available
                if (aiAnswer) {
                    if (!data.data.pagination) data.data.pagination = {};
                    data.data.pagination.ai_answer = aiAnswer;
                }
                
                // Update active filters display
                updateActiveFilters(filters);
                
                // Reset state for new query
                seenResults.clear();
                paginationState.query = searchQuery;
                paginationState.offset = 0;
                paginationState.nextOffset = (data.data.pagination && typeof data.data.pagination.next_offset === 'number') ? data.data.pagination.next_offset : (data.data.results ? data.data.results.length : 0);
                paginationState.pageSize = (data.data.pagination && typeof data.data.pagination.limit === 'number') ? data.data.pagination.limit : ((data.data.results && data.data.results.length) ? data.data.results.length : (hybridSearch.maxResults || 10));
                paginationState.hasMore = !!(data.data.pagination && data.data.pagination.has_more);

                displayResults(data.data.results, resultsContainer, data.data.pagination);
            } else {
                displayNoResults(resultsContainer);
            }

            if (shouldTrackSearch(searchQuery)) {
                trackSearchAnalytics(searchQuery, resultsArray, timeTaken);
            }
        })
        .catch(error => {
            displayNoResults(resultsContainer);
        });
    }
    
    // =========================================================================
    // SEARCH FUNCTIONALITY
    // =========================================================================
    function performSearch(query, page = 1, filters = null) {
        if (!query) return;
        
        // Show loading state
        showLoading();
        
        // Calculate offset for pagination
        const offset = (page - 1) * hybridSearch.maxResults;
        
        // Get filter values if not provided
        if (!filters) {
            filters = getFilterValues();
        }
        
        // Update maxResults if limit filter changed
        if (filters.limit && parseInt(filters.limit) !== hybridSearch.maxResults) {
            hybridSearch.maxResults = parseInt(filters.limit);
        }
        
        const searchData = {
            action: 'hybrid_search',
            query: query,
            limit: hybridSearch.maxResults,
            offset: offset,
            include_answer: hybridSearch.includeAnswer && page === 1,
            ai_instructions: hybridSearch.aiInstructions || '',
            session_id: getSessionId(),
            filter_type: filters.type || '',
            filter_date: filters.date || '',
            filter_sort: filters.sort || 'relevance'
        };
        
        const startTime = Date.now();
        
        $.ajax({
            url: hybridSearch.ajaxUrl,
            type: 'POST',
            data: searchData,
            timeout: 20000, // Reduced from 30s to 20s for faster failure detection
            cache: false, // Ensure fresh results
            beforeSend: function(xhr) {
                // AJAX request being sent
            },
            success: function(response) {
                const timeTaken = (Date.now() - startTime) / 1000;
                
                hideLoading();
                hideLoadMoreIndicator();
                
                if (response.success && response.data) {
                    // Track analytics only for meaningful searches
                    if (shouldTrackSearch(query)) {
                        trackSearchAnalytics(query, response.data.results || [], timeTaken);
                    }
                    
                    // Debug: Check if ranking_explanation exists in results (admin only)
                    if (window.hybridSearch && window.hybridSearch.isAdmin && response.data.results && response.data.results.length > 0) {
                        console.debug('Admin debug: First result has ranking_explanation?', {
                            hasRankingExpl: !!response.data.results[0].ranking_explanation,
                            firstResult: response.data.results[0]
                        });
                    }
                    
                    // Update active filters display
                    updateActiveFilters(filters);
                    
                    const containerEl = document.querySelector('.hybrid-search-results');
                    if (page === 1) {
                        // New search - replace all results
                        seenResults.clear();
                        paginationState.query = query;
                        paginationState.offset = 0;
                        paginationState.nextOffset = (response.data.pagination && typeof response.data.pagination.next_offset === 'number') ? response.data.pagination.next_offset : ((response.data.results || []).length);
                        paginationState.hasMore = !!(response.data.pagination && response.data.pagination.has_more);
                        allResults = response.data.results || [];
                        displayResults(response.data.results || [], containerEl, response.data.pagination || null, false);
                    } else {
                        // Load more - append results
                        allResults = allResults.concat(response.data.results || []);
                        displayResults(response.data.results || [], containerEl, response.data.pagination || null, true);
                        if (response.data.pagination) {
                            paginationState.query = query;
                            paginationState.offset = (typeof response.data.pagination.offset === 'number') ? response.data.pagination.offset : paginationState.offset;
                            paginationState.nextOffset = (typeof response.data.pagination.next_offset === 'number') ? response.data.pagination.next_offset : paginationState.nextOffset;
                            paginationState.hasMore = !!response.data.pagination.has_more;
                        }
                    }
                    
                    // Update pagination state
                    currentPage = page;
                    isLoadingMore = false;
                    
                    // Update load more button
                    updateLoadMoreButton(response.data.pagination);
                } else {
                    // Handle error response with better messaging
                    let errorMessage = response.data?.error || response.data?.message || 'Search failed';
                    
                    // Check if it's a timeout error
                    if (response.data?.metadata?.is_timeout || 
                        errorMessage.toLowerCase().includes('timeout') ||
                        errorMessage.toLowerCase().includes('timed out')) {
                        errorMessage = 'Search request timed out. ';
                        errorMessage += 'The server may be processing a complex query. ';
                        errorMessage += 'Please try again with a simpler query, or try disabling AI reranking in settings for faster searches.';
                    }
                    
                    showError(errorMessage);
                    isLoadingMore = false;
                }
            },
            error: function(xhr, status, error) {
                hideLoading();
                hideLoadMoreIndicator();
                isLoadingMore = false;
                
                let errorMessage = 'Search failed. Please try again.';
                
                // Provide more specific error messages based on status code
                if (status === 'timeout' || status === 'abort') {
                    errorMessage = 'Search request timed out. The server may be processing a complex query. ';
                    errorMessage += 'Please try again with a simpler query, or try disabling AI reranking in settings for faster searches.';
                } else if (xhr.status === 0) {
                    errorMessage = 'Unable to connect to search server. Please check your connection and try again.';
                } else if (xhr.status === 400) {
                    errorMessage = 'Invalid request. Please check your search query.';
                } else if (xhr.status === 404) {
                    errorMessage = 'Search service not found. Please contact support.';
                } else if (xhr.status >= 500) {
                    errorMessage = 'Server error. Please try again later.';
                }
                
                // Try to parse error from response if available
                try {
                    if (xhr.responseText) {
                        const errorData = JSON.parse(xhr.responseText);
                        if (errorData.data && errorData.data.error) {
                            errorMessage = errorData.data.error;
                        }
                    }
                } catch (e) {
                    // Use default error message
                }
                
                showError(errorMessage);
            }
        });
    }
    
    function displayResults(results, container, pagination = null, isAppend = false) {
        if (!results || results.length === 0) {
            if (!isAppend) {
                displayNoResults(container);
            }
            return;
        }
        
        if (!isAppend) {
            // First load - create full structure
            let html = '';
            
            // Add AI answer if available and enabled
            if (pagination && pagination.ai_answer && pagination.ai_answer.trim()) {
                html += buildAIAnswerHTML(pagination.ai_answer);
            }
            
            html += '<div class="hybrid-search-results-header">';
            html += '<div class="hybrid-search-results-count">Found results</div>';
            html += '</div>';
            html += '<div class="hybrid-search-results-list">';
            
            results.forEach((result, index) => {
                const key = (result.id ? String(result.id) : '') + '|' + (result.url || '');
                if (!seenResults.has(key)) {
                    seenResults.add(key);
                    html += buildResultHTML(result, index);
                }
            });
            
            html += '</div>';
            
            // Add "Talk to an Expert?" CTA before pagination controls
            const query = getCurrentSearchQuery();
            html += buildExpertCTAHTML(query);
            
            // Add Load More button instead of infinite scroll
            if (pagination && pagination.has_more) {
                html += '<div class="hybrid-search-load-more-container">';
                html += '<button class="hybrid-search-load-more-btn" onclick="hybridSearchLoadMore(\'' + getCurrentSearchQuery() + '\', this)">';
                html += '    <span class="load-more-text">Load More Results</span>';
                html += '    <span class="load-more-loading">Loading...</span>';
                html += '</button>';
                html += '</div>';
            } else {
                html += '<div class="hybrid-search-no-more">No more results to load</div>';
            }
            
            container.innerHTML = html;
            
            // Store results globally for tooltip access (preserve all fields including ranking_explanation)
            window.currentSearchResults = results.map(r => ({...r})); // Deep copy to preserve all fields
            
            // Debug: Log if ranking_explanation exists
            if (window.hybridSearch && window.hybridSearch.isAdmin && window.currentSearchResults.length > 0) {
                console.debug('Admin debug: Stored results with ranking_explanation?', {
                    firstResultHasExpl: !!window.currentSearchResults[0].ranking_explanation,
                    firstResult: window.currentSearchResults[0]
                });
            }
            
            // Fetch images for items with media IDs but no URL
            fetchMissingImages(container);
            
            // Initialize ranking tooltips for admin users
            initRankingTooltips(container);
        } else {
            // Append mode - just add results to existing list
            const resultsList = container.querySelector('.hybrid-search-results-list');
            if (resultsList) {
                results.forEach((result) => {
                    const key = (result.id ? String(result.id) : '') + '|' + (result.url || '');
                    if (seenResults.has(key)) return;
                    seenResults.add(key);
                    const existingCount = resultsList.children.length;
                    const resultHTML = buildResultHTML(result, existingCount);
                    resultsList.insertAdjacentHTML('beforeend', resultHTML);
                });
                
                // Fetch images for items with media IDs but no URL
                fetchMissingImages(container);
                
                // Initialize ranking tooltips for admin users
                initRankingTooltips(container);
                
                // Update Load More button
                updateLoadMoreButton(container, pagination);
            }
        }
    }
    
    function appendResults(results) {
        const container = $('.hybrid-search-results');
        let resultsList = container.find('.hybrid-search-results-list');
        
        if (results.length > 0) {
            if (!resultsList.length) {
                container.append('<div class="hybrid-search-results-list"></div>');
                resultsList = container.find('.hybrid-search-results-list');
            }
            results.forEach((result) => {
                const key = (result.id ? String(result.id) : '') + '|' + (result.url || '');
                if (seenResults.has(key)) return;
                seenResults.add(key);
                const existingCount = resultsList.children().length;
                const resultHTML = buildResultHTML(result, existingCount);
                resultsList.append(resultHTML);
            });
            
            // Initialize interactions for new results
            initializeResultInteractions();
        }
    }
    
    function buildResultHTML(result, index) {
        // Get thumbnail - check multiple possible fields and handle edge cases
        let thumbnail = result.featured_image || result.featured_image_src || result.thumbnail || result.image || result.featured_image_url || (result._embedded && result._embedded['wp:featuredmedia'] && result._embedded['wp:featuredmedia'][0] && result._embedded['wp:featuredmedia'][0].source_url) || '';
        
        // If no thumbnail found, try to construct from media ID
        if (!thumbnail || thumbnail.trim() === '') {
            const mediaId = result.featured_media || result.media_id || result.attachment_id;
            if (mediaId && mediaId > 0) {
                const baseUrl = window.location.origin;
                thumbnail = tryConstructImageUrl(mediaId, baseUrl);
            }
        }
        
        // Try extracting from HTML content/excerpt if still empty
        if (!thumbnail || thumbnail.trim() === '') {
            const htmlBlob = (result.content || result.excerpt || '');
            const m = typeof htmlBlob === 'string' ? htmlBlob.match(/<img[^>]+src=["']([^"']+)["']/i) : null;
            if (m && m[1]) {
                thumbnail = m[1];
            }
        }

        // More lenient validation for thumbnail URLs
        const hasThumbnail = thumbnail && 
                            thumbnail.trim() !== '' && 
                            thumbnail !== 'null' && 
                            thumbnail !== 'undefined' &&
                            thumbnail !== 'false' &&
                            thumbnail.length > 5 && // Reduced minimum URL length
                            (thumbnail.startsWith('http') || thumbnail.startsWith('/') || thumbnail.startsWith('data:')); // Added data: support
        
        // Get post type for styling
        const postType = result.type || 'page';
        const postTypeClass = 'post-type-' + postType.toLowerCase().replace(/[^a-z0-9]/g, '-');
        
        // Format date
        const date = result.date || result.modified || '';
        let formattedDate = '';
        if (date) {
            const dateObj = new Date(date);
            formattedDate = dateObj.toLocaleDateString('en-US', { 
                year: 'numeric', 
                month: 'short', 
                day: 'numeric' 
            });
        }
        
        // Get archive URL for post type
        const archiveUrl = getArchiveUrl(postType);
        
        // Check if it's a professional post
        const professionalTypes = ['scs-professional', 'scs_professional', 'professional', 'scs-professionals', 'scs_professionals', 'team', 'staff'];
        const isProfessional = result.type && professionalTypes.includes(result.type.toLowerCase());
        
        // Get media ID for fallback
        const mediaId = result.featured_media || result.media_id || result.attachment_id || '0';
        
        let html = '<article class="hybrid-search-result ' + postTypeClass + '" data-result-id="' + (result.id || index) + '" data-position="' + (index + 1) + '" data-media-id="' + mediaId + '">';
        
        // Thumbnail section with improved error handling
        if (hasThumbnail) {
            html += '<div class="hybrid-search-result-thumbnail">';
            html += '<img src="' + escapeHtml(thumbnail) + '" alt="' + escapeHtml(result.title || '') + '" loading="lazy" onerror="handleImageError(this)" onload="handleImageLoad(this)">';
            html += '</div>';
        } else {
            // If we have a media ID but no URL, fetch from REST API
            if (mediaId && mediaId !== '0' && mediaId !== '') {
                // Create thumbnail div that will be populated by async fetch
                html += '<div class="hybrid-search-result-thumbnail" data-media-id="' + mediaId + '">';
                html += '<div class="image-loading-placeholder">Loading image...</div>';
                html += '</div>';
                // Trigger async image fetch after DOM insertion
                // We'll handle this in the renderResults function
            } else {
                html += '<div class="hybrid-search-result-thumbnail no-image">';
                html += '<div class="no-image-placeholder">📄</div>';
                html += '</div>';
            }
        }
        
        // Content section
        html += '<div class="hybrid-search-result-content">';
        
        // Header with meta
        html += '<div class="hybrid-search-result-header">';
        html += '<div class="hybrid-search-result-meta">';
        if (formattedDate) {
            html += '<span class="hybrid-search-result-date">' + formattedDate + '</span>';
        }
        if (result.categories && result.categories.length > 0) {
            const primaryCategory = result.categories[0].name || result.categories[0];
            html += '<span class="hybrid-search-result-type">' + escapeHtml(primaryCategory) + '</span>';
        }
        html += '</div>';
        html += '</div>';
        
        // Title
        html += '<h3 class="hybrid-search-result-title">';
        html += '<a href="' + (result.url || '#') + '" data-result-id="' + (result.id || index) + '" data-title="' + (result.title || '') + '" data-url="' + (result.url || '#') + '" data-position="' + (index + 1) + '" data-score="' + (result.score || 0) + '">';
        html += escapeHtml(result.title || 'Untitled');
        html += '</a>';
        
        // Add tooltip trigger for admin users
        // Check both isAdmin and showRankingTooltips to be safe
        // Also check the global hybridSearch variable (from PHP wp_localize_script)
        // PHP sends strings ('1'/'0'), not booleans, so check for truthy values
        const hybridSearchObj = typeof hybridSearch !== 'undefined' ? hybridSearch : (typeof window !== 'undefined' && window.hybridSearch ? window.hybridSearch : {});
        const isAdmin = hybridSearchObj && (
            hybridSearchObj.isAdmin === true || 
            hybridSearchObj.isAdmin === '1' || 
            hybridSearchObj.isAdmin === 1 ||
            hybridSearchObj.showRankingTooltips === true || 
            hybridSearchObj.showRankingTooltips === '1' || 
            hybridSearchObj.showRankingTooltips === 1
        );
        
        // Debug logging for admin users
        if (isAdmin) {
            console.debug('buildResultHTML: Checking for ranking_explanation', {
                hasRankingExpl: !!result.ranking_explanation,
                resultId: result.id,
                resultTitle: result.title?.substring(0, 50),
                resultKeys: Object.keys(result),
                hybridSearchObj: hybridSearchObj
            });
        }
        
        if (isAdmin && result.ranking_explanation) {
            html += '<span class="ranking-tooltip-trigger" data-result-position="' + (index + 1) + '" title="Click to see ranking explanation">ℹ️</span>';
        } else if (isAdmin) {
            // Debug: Log why tooltip trigger is not showing
            console.debug('buildResultHTML: Admin user but no ranking_explanation', {
                resultId: result.id,
                resultTitle: result.title?.substring(0, 50),
                hasRankingExpl: !!result.ranking_explanation
            });
        }
        
        html += '</h3>';
        
        // Excerpt
        if (result.excerpt) {
            let cleanExcerpt = cleanExcerptText(result.excerpt);
            html += '<div class="hybrid-search-result-excerpt">' + cleanExcerpt + '</div>';
        }
        
        // Footer
        html += '<div class="hybrid-search-result-footer">';
        html += '<div class="hybrid-search-result-footer-left">';
        
        // Post type section
        const postTypeDisplayName = getPostTypeDisplayName(postType);
        html += '<div class="hybrid-search-result-post-type">';
        html += '<div class="hybrid-search-result-post-type-icon"></div>';
        html += '<div>';
        if (archiveUrl) {
            html += '<a href="' + archiveUrl + '" class="hybrid-search-result-post-type-text hybrid-search-result-post-type-link">' + escapeHtml(postTypeDisplayName) + '</a>';
        } else {
            html += '<div class="hybrid-search-result-post-type-text">' + escapeHtml(postTypeDisplayName) + '</div>';
        }
        html += '</div>';
        html += '</div>';
        
        html += '</div>'; // footer-left
        
        html += '<div class="hybrid-search-result-footer-right">';
        
        // Contact button for professionals
        if (isProfessional) {
            const staffId = result.staff_id || '505748';
            html += '<button class="hybrid-search-result-contact-btn contact-popup" data-staff-id="' + staffId + '" data-contact-popup="true">';
            html += 'Contact Professional';
            html += '</button>';
        }
        
        html += '</div>'; // footer-right
        html += '</div>'; // footer
        html += '</div>'; // content
        html += '</article>';
        
        return html;
    }
    
    function shouldShowExpertCTA(query) {
        if (!query || query.trim() === '') {
            return false;
        }
        
        const queryLower = query.toLowerCase().trim();
        
        // Person name queries (typically 2-3 words, capitalized names)
        if (/^[A-Z][a-z]+ [A-Z][a-z]+/.test(query)) {
            const words = query.trim().split(/\s+/);
            if (words.length >= 2 && words.length <= 3) {
                const allCapitalized = words.every(word => /^[A-Z][a-z]+$/.test(word.trim()));
                if (allCapitalized) {
                    return true;
                }
            }
        }
        
        // Service queries
        const serviceKeywords = ['service', 'services', 'consulting', 'consultant', 'management', 'solution', 'solutions', 'support', 'help', 'assistance', 'expertise'];
        for (const keyword of serviceKeywords) {
            if (queryLower.includes(keyword)) {
                return true;
            }
        }
        
        // Sector/industry queries
        const sectorKeywords = ['environmental', 'waste', 'remediation', 'compliance', 'sustainability', 'engineering', 'sector', 'industry', 'field'];
        for (const keyword of sectorKeywords) {
            if (queryLower.includes(keyword)) {
                return true;
            }
        }
        
        return false;
    }
    
    function buildExpertCTAHTML(query) {
        const safeQuery = (query && query.trim()) ? escapeHtml(query.trim()) : '';
        const description = safeQuery
            ? 'Our experts are ready to assist you with ' + safeQuery + '. Get personalized guidance and answers to your specific questions.'
            : 'Our experts are ready to assist you. Get personalized guidance and answers tailored to your needs.';

        let html = '<div class="hybrid-search-expert-cta">';
        html += '<div class="hybrid-search-expert-cta-content">';
        html += '<h3 class="hybrid-search-expert-cta-title">Need More Help?</h3>';
        html += '<p class="hybrid-search-expert-cta-text">';
        html += description;
        html += '</p>';
        html += '<a href="/contact/" class="hybrid-search-expert-cta-button">';
        html += 'Talk to an Expert';
        html += '</a>';
        html += '</div>';
        html += '</div>';
        return html;
    }
    
    function truncateHtmlPreservingTags(html, maxChars) {
        if (!html) return '';
        const container = document.createElement('div');
        container.innerHTML = html;
        let charCount = 0;
        let truncated = false;

        const trimEnd = (text) => text.replace(/\s+$/u, '');

        const traverse = (node) => {
            if (charCount >= maxChars) {
                node.remove();
                return;
            }

            if (node.nodeType === Node.TEXT_NODE) {
                const nodeText = node.textContent || '';
                const remaining = maxChars - charCount;

                if (nodeText.length > remaining) {
                    node.textContent = trimEnd(nodeText.slice(0, remaining)) + '…';
                    charCount = maxChars;
                    truncated = true;
                } else {
                    charCount += nodeText.length;
                }
            } else if (node.nodeType === Node.ELEMENT_NODE) {
                const children = Array.from(node.childNodes);
                for (const child of children) {
                    traverse(child);
                    if (charCount >= maxChars) {
                        let sibling = child.nextSibling;
                        while (sibling) {
                            const next = sibling.nextSibling;
                            sibling.remove();
                            sibling = next;
                        }
                        break;
                    }
                }
            }
        };

        const topLevelChildren = Array.from(container.childNodes);
        for (const child of topLevelChildren) {
            traverse(child);
            if (charCount >= maxChars) {
                let sibling = child.nextSibling;
                while (sibling) {
                    const next = sibling.nextSibling;
                    sibling.remove();
                    sibling = next;
                }
                break;
            }
        }

        if (!truncated && charCount > maxChars) {
            return trimEnd(container.textContent || '') + '…';
        }

        return container.innerHTML;
    }

    function createAIAnswerPreview(answerHtml) {
        const maxChars = (window.hybridSearch && window.hybridSearch.aiAnswerPreviewLength) ? parseInt(window.hybridSearch.aiAnswerPreviewLength, 10) : 400;
        const temp = document.createElement('div');
        temp.innerHTML = answerHtml || '';
        const plainText = (temp.textContent || temp.innerText || '').trim();

        if (!plainText) {
            return {
                preview: '',
                full: '',
                needsTruncation: false
            };
        }

        if (plainText.length <= maxChars) {
            return {
                preview: answerHtml || plainText,
                full: answerHtml || plainText,
                needsTruncation: false
            };
        }

        return {
            preview: truncateHtmlPreservingTags(answerHtml, maxChars),
            full: answerHtml,
            needsTruncation: true
        };
    }

    function buildAIAnswerHTML(aiAnswer) {
        if (!aiAnswer) {
            return '';
        }

        const previewData = createAIAnswerPreview(aiAnswer);
        const answerId = 'hybrid-search-ai-answer-' + Math.random().toString(36).slice(2, 10);
        const titleId = answerId + '-title';
        const fullEncoded = encodeURIComponent(previewData.full);
        const previewEncoded = previewData.needsTruncation ? encodeURIComponent(previewData.preview) : '';

        let html = '<section class="hybrid-search-ai-answer" role="region" aria-live="polite" aria-labelledby="' + titleId + '">';
        html += '<header class="hybrid-search-ai-answer-header">';
        html += '<h3 id="' + titleId + '" class="hybrid-search-ai-answer-title">';
        html += '<span class="hybrid-search-ai-answer-icon">🤖</span>';
        html += '<span>AI Answer</span>';
        html += '</h3>';
        html += '</header>';
        html += '<div id="' + answerId + '" class="hybrid-search-ai-answer-content' + (previewData.needsTruncation ? ' collapsed' : '') + '"';
        if (previewData.needsTruncation) {
            html += ' data-full="' + fullEncoded + '" data-preview="' + previewEncoded + '"';
        }
        html += '>';
        html += '<div class="hybrid-search-ai-answer-body" aria-live="polite">' + (previewData.needsTruncation ? previewData.preview : previewData.full) + '</div>';
        html += '</div>';

        if (previewData.needsTruncation) {
            html += '<footer class="hybrid-search-ai-answer-footer">';
            html += '<button type="button" class="hybrid-search-ai-answer-toggle" onclick="toggleAIAnswer(this)" aria-expanded="false" aria-controls="' + answerId + '">';
            html += '<span>Show more</span>';
            html += '<span class="hybrid-search-ai-answer-toggle-icon">▼</span>';
            html += '</button>';
            html += '</footer>';
        }

        html += '</section>';
        return html;
    }
    
    // =========================================================================
    // LOAD MORE FUNCTIONALITY (from inline script)
    // =========================================================================
    window.hybridSearchLoadMore = function(query, button) {
        if (isLoadingMore) { return; }
        isLoadingMore = true;
        // Get current offset from existing results
        const container = document.querySelector('.hybrid-search-results');
        // Prefer server-provided next_offset; fallback to DOM count
        const resultsList = container.querySelector('.hybrid-search-results-list');
        const fallbackOffset = resultsList ? resultsList.children.length : 0;
        const currentOffset = (paginationState.query === query && typeof paginationState.nextOffset === 'number') ? paginationState.nextOffset : fallbackOffset;
        const pageSize = (paginationState.pageSize && Number.isFinite(paginationState.pageSize)) ? paginationState.pageSize : (hybridSearch.maxResults || 10);
        
        // Show loading state
        const loadMoreText = button.querySelector('.load-more-text');
        const loadingText = button.querySelector('.load-more-loading');
        loadMoreText.style.display = 'none';
        loadingText.style.display = 'inline';
        button.disabled = true;
        
        const aiInstructions = hybridSearch.aiInstructions || '';
        const filters = getFilterValues();
        
        // Make AJAX call with proper offset using fetch API
        fetch(hybridSearch.ajaxUrl, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded',
            },
            body: 'action=hybrid_search&query=' + encodeURIComponent(query) + '&limit=' + encodeURIComponent(String(pageSize)) + '&offset=' + encodeURIComponent(String(currentOffset)) + '&ai_instructions=' + encodeURIComponent(aiInstructions) + '&filter_type=' + encodeURIComponent(filters.type || '') + '&filter_date=' + encodeURIComponent(filters.date || '') + '&filter_sort=' + encodeURIComponent(filters.sort || 'relevance')
        })
        .then(response => response.json())
        .then(data => {
            if (data.success && data.data && data.data.results && data.data.results.length > 0) {
                // Append new results to existing list
                let resultsList = container.querySelector('.hybrid-search-results-list');
                if (!resultsList) {
                    const listEl = document.createElement('div');
                    listEl.className = 'hybrid-search-results-list';
                    container.appendChild(listEl);
                    resultsList = listEl;
                }
                if (resultsList) {
                    data.data.results.forEach((result) => {
                        const key = (result.id ? String(result.id) : '') + '|' + (result.url || '');
                        if (seenResults.has(key)) return;
                        seenResults.add(key);
                        const existingCount = resultsList.children.length;
                        const resultHTML = buildResultHTML(result, existingCount);
                        resultsList.insertAdjacentHTML('beforeend', resultHTML);
                    });
                    // Update pagination state from server
                    if (data.data.pagination) {
                        paginationState.query = query;
                        paginationState.offset = (typeof data.data.pagination.offset === 'number') ? data.data.pagination.offset : currentOffset;
                        paginationState.nextOffset = (typeof data.data.pagination.next_offset === 'number') ? data.data.pagination.next_offset : (resultsList.children.length);
                        paginationState.pageSize = (typeof data.data.pagination.limit === 'number') ? data.data.pagination.limit : pageSize;
                        paginationState.hasMore = !!data.data.pagination.has_more;
                    }
                    
                    // Update Load More button based on pagination
                    updateLoadMoreButton(container, data.data.pagination || {
                        has_more: paginationState.hasMore
                    });
                }
            } else {
                // Hide button, show "no more" message
                button.parentElement.style.display = 'none';
                const resultsList = container.querySelector('.hybrid-search-results-list');
                if (resultsList) {
                    resultsList.insertAdjacentHTML('afterend', '<div class="hybrid-search-no-more">No more results to load</div>');
                }
            }
            // Reset loading state
            if (button) {
                const loadMoreText = button.querySelector('.load-more-text');
                const loadingText = button.querySelector('.load-more-loading');
                if (loadMoreText) loadMoreText.style.display = 'inline';
                if (loadingText) loadingText.style.display = 'none';
                button.disabled = false;
            }
            isLoadingMore = false;
        })
        .catch(error => {
            if (button) {
                const loadMoreText = button.querySelector('.load-more-text');
                const loadingText = button.querySelector('.load-more-loading');
                if (loadMoreText) loadMoreText.style.display = 'inline';
                if (loadingText) loadingText.style.display = 'none';
                button.disabled = false;
            }
            isLoadingMore = false;
            alert('Error loading more results. Please try again.');
        });
    };
    
    function updateLoadMoreButton(container, pagination) {
        const loadMoreContainer = container.querySelector('.hybrid-search-load-more-container');
        if (loadMoreContainer) {
            if (pagination && pagination.has_more) {
                // Show button and reset state
                loadMoreContainer.style.display = 'block';
                const button = loadMoreContainer.querySelector('.hybrid-search-load-more-btn');
                if (button) {
                    button.disabled = false;
                    const loadMoreText = button.querySelector('.load-more-text');
                    const loadingText = button.querySelector('.load-more-loading');
                    if (loadMoreText) loadMoreText.style.display = 'inline';
                    if (loadingText) loadingText.style.display = 'none';
                }
            } else {
                // Hide button and show "no more" message
                loadMoreContainer.style.display = 'none';
                const noMoreDiv = container.querySelector('.hybrid-search-no-more');
                if (!noMoreDiv) {
                    const resultsList = container.querySelector('.hybrid-search-results-list');
                    if (resultsList) {
                        resultsList.insertAdjacentHTML('afterend', '<div class="hybrid-search-no-more">No more results to load</div>');
                    }
                }
            }
        }
    }
    
    // =========================================================================
    // UTILITY FUNCTIONS (from inline script)
    // =========================================================================
    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    function getPostTypeDisplayName(postTypeSlug) {
        // Convert post type slug to human-readable display name
        const displayNames = {
            'post': 'Blog Post',
            'page': 'Page',
            'scs-professional': 'SCS Professional',
            'scs_professional': 'SCS Professional',
            'scs-professionals': 'SCS Professional',
            'scs_professionals': 'SCS Professional',
            'professional': 'Professional',
            'professionals': 'Professional',
            'team': 'Team Member',
            'staff': 'Staff Member',
            'product': 'Product',
            'products': 'Product',
            'event': 'Event',
            'events': 'Event',
            'case-study': 'Case Study',
            'case_study': 'Case Study',
            'case-studies': 'Case Study',
            'case_studies': 'Case Study',
            'news': 'News',
            'article': 'Article',
            'articles': 'Article',
            'service': 'Service',
            'services': 'Service',
            'project': 'Project',
            'projects': 'Project',
            'testimonial': 'Testimonial',
            'testimonials': 'Testimonial',
            'faq': 'FAQ',
            'faqs': 'FAQ',
            'gallery': 'Gallery',
            'galleries': 'Gallery',
            'portfolio': 'Portfolio',
            'portfolios': 'Portfolio'
        };
        
        // Return display name or format the slug nicely
        if (displayNames[postTypeSlug.toLowerCase()]) {
            return displayNames[postTypeSlug.toLowerCase()];
        }
        
        // Fallback: format slug nicely (replace dashes/underscores with spaces, capitalize)
        return postTypeSlug
            .toLowerCase()
            .replace(/[-_]/g, ' ')
            .replace(/\b\w/g, l => l.toUpperCase());
    }
    
    function tryConstructImageUrl(mediaId, baseUrl) {
        if (!mediaId || mediaId === 0) return '';
        
        // Try common image extensions
        const extensions = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
        const potentialUrls = extensions.map(ext => 
            `${baseUrl}/wp-content/uploads/${mediaId}.${ext}`
        );
        
        // Return the first potential URL - the browser will handle 404s
        return potentialUrls[0];
    }
    
    function getArchiveUrl(postType) {
        // Generate archive URL based on post type
        const baseUrl = window.location.origin;
        switch (postType.toLowerCase()) {
            case 'post':
                return baseUrl + '/blog/';
            case 'page':
                return baseUrl + '/pages/';
            case 'scs-professional':
            case 'scs_professional':
            case 'professional':
                return baseUrl + '/professionals/';
            case 'product':
                return baseUrl + '/products/';
            case 'event':
                return baseUrl + '/events/';
            case 'case-study':
                return baseUrl + '/case-studies/';
            default:
                return baseUrl + '/' + postType.toLowerCase() + '/';
        }
    }
    
    function openContactModal(staffId) {
        // 1) New popup API variants
        if (window.contactFormPopup && typeof window.contactFormPopup.open === 'function') {
            try { window.contactFormPopup.open({ staffId: staffId }); return; } catch (e) {}
        }
        if (window.ContactFormPopup && typeof window.ContactFormPopup.open === 'function') {
            try { window.ContactFormPopup.open(staffId); return; } catch (e) {}
        }
        if (typeof window.openContactPopup === 'function') {
            try { window.openContactPopup(staffId); return; } catch (e) {}
        }
        // 2) Dispatch a custom event for any popup listeners
        try {
            const evt = new CustomEvent('contact-form:open', { detail: { staffId: staffId } });
            document.dispatchEvent(evt);
            return;
        } catch (e) {}
        // 3) Fallback: redirect to contact page
        window.location.href = '/contact/?staff_id=' + staffId;
    }
    
    function cleanExcerptText(excerpt) {
        if (!excerpt) return '';
        
        // Remove HTML tags
        let cleanText = excerpt.replace(/<[^>]*>/g, '');
        
        // Remove "Continue reading" and everything after it
        cleanText = cleanText.replace(/\s*Continue reading.*$/i, '');
        
        // Remove text after dots (...) but keep the dots
        cleanText = cleanText.replace(/\s*\.{3,}\s*.*$/g, '...');
        
        // Remove any remaining trailing dots if they're at the end
        cleanText = cleanText.replace(/\.{3,}\s*$/, '...');
        
        // Clean up extra whitespace
        cleanText = cleanText.replace(/\s+/g, ' ').trim();
        
        // Ensure it ends with proper punctuation
        if (cleanText && !cleanText.match(/[.!?]$/)) {
            cleanText += '...';
        }
        
        return cleanText;
    }
    
    function getSessionId() {
        let sessionId = sessionStorage.getItem('hybrid_search_session');
        if (!sessionId) {
            sessionId = 'session_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            sessionStorage.setItem('hybrid_search_session', sessionId);
        }
        return sessionId;
    }
    
    function shouldTrackSearch(query) {
        return query && query.trim().length >= 3 && !query.match(/^(test|debug|admin)$/i);
    }
    
    function trackSearchAnalytics(query, results, timeTaken) {
        // Skip if analytics tracking is disabled
        if (!hybridSearch || !hybridSearch.ajaxUrl) {
            return;
        }
        
        // Prepare analytics data
        const analyticsData = {
            query: query,
            results: results,
            time_taken: timeTaken, // Backend expects 'time_taken', not 'response_time'
            response_time: timeTaken, // Keep both for compatibility
            result_count: results ? results.length : 0,
            has_results: results && results.length > 0,
            timestamp: new Date().toISOString(),
            session_id: getSessionId()
        };
        
        // Send analytics via AJAX (non-blocking)
        console.log('Hybrid Search Analytics: Sending analytics data:', analyticsData);
        $.ajax({
            url: hybridSearch.ajaxUrl,
            type: 'POST',
            data: {
                action: 'track_search_analytics',
                analytics: analyticsData
            },
            timeout: 5000, // 5 second timeout
            success: function(response) {
                console.log('Hybrid Search Analytics: AJAX response:', response);
                if (response.success) {
                    console.debug('Analytics tracked successfully');
                } else {
                    console.warn('Analytics tracking failed:', response.message);
                }
            },
            error: function(xhr, status, error) {
                // Silently fail - don't break search functionality
                console.debug('Analytics tracking error (non-critical):', error);
            }
        });
    }
    
    function showLoading() {
        const container = $('.hybrid-search-results');
        if (container.length) {
            container.html('<div class="hybrid-search-loading">Searching...</div>');
        }
    }
    
    function hideLoading() {
        $('.hybrid-search-loading').remove();
    }
    
    function hideLoadMoreIndicator() {
        $('.hybrid-search-load-more-btn').removeClass('loading');
    }
    
    function showError(message) {
        const container = $('.hybrid-search-results');
        if (container.length) {
            container.html('<div class="hybrid-search-error">' + escapeHtml(message) + '</div>');
        }
    }
    
    function displayNoResults(container) {
        container.innerHTML = `
            <div class="hybrid-search-empty">
                <div class="hybrid-search-empty-icon">🔍</div>
                <h3 class="hybrid-search-empty-title">No results found</h3>
                <p class="hybrid-search-empty-description">
                    Try adjusting your search terms or check the spelling.
                </p>
            </div>
        `;
    }
    
    function initializeResultInteractions() {
        // CTR click tracking: delegate on result links
        const container = document.querySelector('.hybrid-search-results');
        if (!container) return;
        container.addEventListener('click', function(evt) {
            const link = evt.target.closest('.hybrid-search-result a');
            if (!link) return;
            // Build CTR payload
            const article = link.closest('.hybrid-search-result');
            const resultId = link.getAttribute('data-result-id') || '';
            const title = link.getAttribute('data-title') || link.textContent || '';
            const url = link.getAttribute('data-url') || link.href || '';
            const position = parseInt(link.getAttribute('data-position') || article?.getAttribute('data-position') || '0', 10) || 0;
            const score = parseFloat(link.getAttribute('data-score') || '0') || 0;
            const query = getCurrentSearchQuery() || '';
            const payload = {
                action: 'hybrid_search_ctr',
                ctr_data: {
                    result_id: resultId,
                    result_title: title,
                    result_url: url,
                    result_position: position,
                    result_score: score,
                    query: query,
                    session_id: getSessionId()
                }
            };
            // Fire and forget
            try {
                navigator.sendBeacon && navigator.sendBeacon(hybridSearch.ajaxUrl, new URLSearchParams(payload));
            } catch (e) {
                // Fallback to async fetch without blocking navigation
                setTimeout(() => {
                    fetch(hybridSearch.ajaxUrl, { method: 'POST', headers: { 'Content-Type': 'application/x-www-form-urlencoded' }, body: new URLSearchParams(payload) });
                }, 0);
            }
        }, { capture: true });
    }
    
    // =========================================================================
    // FETCH MISSING IMAGES FROM REST API
    // =========================================================================
    function fetchMissingImages(container) {
        // Find all thumbnail divs that have a media ID but no image
        const thumbnails = container.querySelectorAll('.hybrid-search-result-thumbnail[data-media-id]');
        
        thumbnails.forEach(thumbnailDiv => {
            const mediaId = thumbnailDiv.getAttribute('data-media-id');
            if (!mediaId || mediaId === '0' || mediaId === '') return;
            
            // Check if already has an image
            if (thumbnailDiv.querySelector('img')) return;
            
            // Fetch media details from REST API
            const apiUrl = window.location.origin + '/wp-json/wp/v2/media/' + mediaId;
            
            fetch(apiUrl)
                .then(response => {
                    if (!response.ok) {
                        throw new Error('Media not found');
                    }
                    return response.json();
                })
                .then(data => {
                    // Try different image sizes in order of preference
                    let imageUrl = null;
                    
                    if (data.media_details && data.media_details.sizes) {
                        const sizes = data.media_details.sizes;
                        // Try medium_large first (good balance), then medium, then full
                        imageUrl = sizes.medium_large?.source_url || 
                                  sizes.medium?.source_url || 
                                  sizes.full?.source_url || 
                                  sizes.thumbnail?.source_url ||
                                  null;
                    }
                    
                    // Fallback to direct source_url
                    if (!imageUrl && data.source_url) {
                        imageUrl = data.source_url;
                    }
                    
                    if (imageUrl) {
                        // Create and insert image
                        const img = document.createElement('img');
                        img.src = imageUrl;
                        img.alt = thumbnailDiv.closest('.hybrid-search-result')?.querySelector('.hybrid-search-result-title a')?.textContent || '';
                        img.loading = 'lazy';
                        img.onerror = function() {
                            // If image still fails, show placeholder
                            thumbnailDiv.classList.add('no-image');
                            thumbnailDiv.innerHTML = '<div class="no-image-placeholder">📄</div>';
                        };
                        img.onload = function() {
                            thumbnailDiv.classList.remove('no-image');
                        };
                        
                        // Replace loading placeholder with image
                        thumbnailDiv.innerHTML = '';
                        thumbnailDiv.appendChild(img);
                    } else {
                        // No image URL found - show placeholder
                        thumbnailDiv.classList.add('no-image');
                        thumbnailDiv.innerHTML = '<div class="no-image-placeholder">📄</div>';
                    }
                })
                .catch(error => {
                    // API fetch failed - show placeholder
                    console.debug('Image fetch failed for media ID ' + mediaId + ':', error);
                    thumbnailDiv.classList.add('no-image');
                    thumbnailDiv.innerHTML = '<div class="no-image-placeholder">📄</div>';
                });
        });
    }
    
    // =========================================================================
    // RANKING TOOLTIP FUNCTIONS (Admin Only)
    // =========================================================================
    function createRankingTooltip(rankingData, position) {
        if (!rankingData) {
            console.warn('createRankingTooltip: No rankingData provided');
            return '';
        }
        
        const {
            tfidf_score = 0,
            ai_score = null,
            ai_score_raw = null,
            hybrid_score = 0,
            tfidf_weight = 1.0,
            ai_weight = 0.0,
            ai_reason = '',
            post_type = 'unknown',
            post_type_priority = null,
            priority_order = []
        } = rankingData;
        
        const hasAiScore = ai_score !== null && ai_score !== undefined;
        
        // Safely format numbers
        const formatScore = (val) => {
            if (val === null || val === undefined) return '0.0000';
            const num = typeof val === 'number' ? val : parseFloat(val);
            return isNaN(num) ? '0.0000' : num.toFixed(4);
        };
        
        const formatWeight = (val) => {
            if (val === null || val === undefined) return '0.0';
            const num = typeof val === 'number' ? val : parseFloat(val);
            return isNaN(num) ? '0.0' : num.toFixed(1);
        };
        
        const scoreBreakdown = hasAiScore 
            ? `(${formatScore(tfidf_score)} × ${formatWeight(tfidf_weight)} + ${formatScore(ai_score)} × ${formatWeight(ai_weight)})`
            : '';
        
        return `
            <div class="ranking-tooltip" data-position="${position}">
                <div class="ranking-tooltip-header">
                    <span class="ranking-position">#${position}</span>
                    <span class="ranking-final-score">Final Score: ${formatScore(hybrid_score)}</span>
                </div>
                <div class="ranking-tooltip-body">
                    <div class="ranking-section">
                        <strong>Score Breakdown:</strong>
                        <div class="ranking-score-item">
                            <span class="score-label">TF-IDF Score:</span>
                            <span class="score-value">${formatScore(tfidf_score)}</span>
                            <span class="score-weight">(${(parseFloat(formatWeight(tfidf_weight)) * 100).toFixed(0)}% weight)</span>
                        </div>
                        ${hasAiScore ? `
                        <div class="ranking-score-item">
                            <span class="score-label">AI Score:</span>
                            <span class="score-value">${formatScore(ai_score)}</span>
                            <span class="score-weight">(${(parseFloat(formatWeight(ai_weight)) * 100).toFixed(0)}% weight)</span>
                            ${ai_score_raw !== null && ai_score_raw !== undefined ? `<span class="score-raw">(${ai_score_raw}/100)</span>` : ''}
                        </div>
                        <div class="ranking-score-item">
                            <span class="score-label">Hybrid Score:</span>
                            <span class="score-value">${formatScore(hybrid_score)}</span>
                            <span class="score-formula">${scoreBreakdown}</span>
                        </div>
                        ` : `
                        <div class="ranking-score-item">
                            <span class="score-label">Final Score:</span>
                            <span class="score-value">${formatScore(hybrid_score)}</span>
                            <span class="score-note">(TF-IDF only, AI reranking not used)</span>
                        </div>
                        ${ai_reason && ai_reason !== 'No AI scoring available' ? `
                        <div class="ranking-score-item" style="margin-top: 8px; padding-top: 8px; border-top: 1px solid #e2e8f0;">
                            <span class="score-label" style="color: #dc2626;">⚠️ Reason:</span>
                            <span class="score-note" style="color: #dc2626; font-weight: 500;">${escapeHtml(ai_reason)}</span>
                        </div>
                        ` : ''}
                        `}
                    </div>
                    
                    ${hasAiScore && ai_reason ? `
                    <div class="ranking-section">
                        <strong>AI Reasoning:</strong>
                        <div class="ranking-reason">${escapeHtml(ai_reason)}</div>
                    </div>
                    ` : ''}
                    
                    <div class="ranking-section">
                        <strong>Post Type Priority:</strong>
                        <div class="ranking-priority">
                            <span class="post-type">${escapeHtml(post_type)}</span>
                            ${priority_order && priority_order.length > 0 ? `
                                <span class="priority-order">
                                    Priority: ${priority_order.indexOf(post_type) !== -1 ? priority_order.indexOf(post_type) + 1 : 'N/A'} 
                                    (${priority_order.map(escapeHtml).join(' > ')})
                                </span>
                            ` : ''}
                        </div>
                    </div>
                </div>
            </div>
        `;
    }
    
    function initRankingTooltips(container) {
        if (!container) {
            console.warn('initRankingTooltips: No container provided');
            return;
        }
        
        // Check both isAdmin and showRankingTooltips to be safe
        // Also check the global hybridSearch variable (from PHP wp_localize_script)
        // PHP sends strings ('1'/'0'), not booleans, so check for truthy values
        const hybridSearchObj = typeof hybridSearch !== 'undefined' ? hybridSearch : (typeof window !== 'undefined' && window.hybridSearch ? window.hybridSearch : {});
        const isAdmin = hybridSearchObj && (
            hybridSearchObj.isAdmin === true || 
            hybridSearchObj.isAdmin === '1' || 
            hybridSearchObj.isAdmin === 1 ||
            hybridSearchObj.showRankingTooltips === true || 
            hybridSearchObj.showRankingTooltips === '1' || 
            hybridSearchObj.showRankingTooltips === 1
        );
        
        if (!isAdmin) {
            // Silent return - no need to log for non-admin users
            return;
        }
        
        // Debug: log if we're trying to initialize tooltips
        console.debug('Admin tooltips: Initializing ranking tooltips', {
            isAdmin: hybridSearchObj.isAdmin,
            showRankingTooltips: hybridSearchObj.showRankingTooltips,
            triggersFound: container.querySelectorAll('.ranking-tooltip-trigger').length,
            resultsCount: window.currentSearchResults?.length || 0,
            hybridSearchObj: hybridSearchObj
        });
        
        const triggers = container.querySelectorAll('.ranking-tooltip-trigger');
        if (triggers.length === 0) {
            console.debug('Admin tooltips: No tooltip triggers found in container');
            return;
        }
        
        triggers.forEach(trigger => {
            // Remove any existing event listeners to prevent duplicates
            const newTrigger = trigger.cloneNode(true);
            trigger.parentNode.replaceChild(newTrigger, trigger);
            
            newTrigger.addEventListener('click', function(e) {
                e.preventDefault();
                e.stopPropagation();
                
                const position = parseInt(this.getAttribute('data-result-position'));
                const resultData = window.currentSearchResults?.[position - 1];
                
                console.debug('Admin tooltips: Clicked trigger', {
                    position: position,
                    hasResultData: !!resultData,
                    hasRankingExpl: !!resultData?.ranking_explanation
                });
                
                if (!resultData || !resultData.ranking_explanation) {
                    console.warn('Admin tooltips: No ranking_explanation found for result', {
                        position: position,
                        resultData: resultData
                    });
                    return;
                }
                
                // Remove existing tooltip
                const existingTooltip = document.querySelector('.ranking-tooltip-active');
                if (existingTooltip) {
                    existingTooltip.remove();
                }
                
                // Create and show tooltip
                const tooltip = document.createElement('div');
                tooltip.className = 'ranking-tooltip-active';
                tooltip.innerHTML = createRankingTooltip(resultData.ranking_explanation, position);
                
                // Position tooltip near the trigger
                const rect = this.getBoundingClientRect();
                tooltip.style.position = 'fixed';
                
                // Calculate optimal position
                const tooltipWidth = 400; // max-width from CSS
                const tooltipHeight = 300; // estimated height
                const spacing = 5;
                
                let left = rect.left;
                let top = rect.bottom + spacing;
                
                // Check if tooltip would go off-screen to the right
                if (left + tooltipWidth > window.innerWidth) {
                    left = window.innerWidth - tooltipWidth - 20; // 20px padding from edge
                }
                
                // Check if tooltip would go off-screen to the left
                if (left < 20) {
                    left = 20;
                }
                
                // Check if tooltip would go off-screen at the bottom
                if (top + tooltipHeight > window.innerHeight) {
                    // Position above the trigger instead
                    top = rect.top - tooltipHeight - spacing;
                    // If still off-screen, position at top of viewport
                    if (top < 20) {
                        top = 20;
                    }
                }
                
                tooltip.style.top = `${top}px`;
                tooltip.style.left = `${left}px`;
                tooltip.style.zIndex = '9999';
                
                document.body.appendChild(tooltip);
                
                // Close tooltip on click outside or ESC
                const closeTooltip = (e) => {
                    if (!tooltip.contains(e.target) && e.target !== newTrigger) {
                        tooltip.remove();
                        document.removeEventListener('click', closeTooltip);
                        document.removeEventListener('keydown', closeEsc);
                    }
                };
                
                const closeEsc = (e) => {
                    if (e.key === 'Escape') {
                        tooltip.remove();
                        document.removeEventListener('click', closeTooltip);
                        document.removeEventListener('keydown', closeEsc);
                    }
                };
                
                setTimeout(() => {
                    document.addEventListener('click', closeTooltip);
                    document.addEventListener('keydown', closeEsc);
                }, 100);
            });
        });
    }
    
    // =========================================================================
    // IMAGE HANDLING (from inline script)
    // =========================================================================
    window.handleImageError = function(img) {
        const container = img.parentElement;
        const resultElement = img.closest('.hybrid-search-result');
        
        // Try to fetch image from WordPress REST API BEFORE showing placeholder
        if (resultElement) {
            const mediaId = resultElement.getAttribute('data-media-id');
            if (mediaId && mediaId !== '0' && mediaId !== '') {
                const apiUrl = window.location.origin + '/wp-json/wp/v2/media/' + mediaId;
                
                // Fetch media details from REST API
                fetch(apiUrl)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error('Media not found');
                        }
                        return response.json();
                    })
                    .then(data => {
                        // Try different image sizes in order of preference
                        let imageUrl = null;
                        
                        if (data.media_details && data.media_details.sizes) {
                            const sizes = data.media_details.sizes;
                            // Try medium_large first (good balance), then medium, then full
                            imageUrl = sizes.medium_large?.source_url || 
                                      sizes.medium?.source_url || 
                                      sizes.full?.source_url || 
                                      sizes.thumbnail?.source_url ||
                                      null;
                        }
                        
                        // Fallback to direct source_url
                        if (!imageUrl && data.source_url) {
                            imageUrl = data.source_url;
                        }
                        
                        if (imageUrl) {
                            // Update image source
                            img.src = imageUrl;
                            img.onerror = null; // Remove error handler to prevent infinite loop
                            container.classList.remove('no-image');
                            return; // Success - don't show placeholder
                        }
                        
                        // If we get here, no image URL found
                        throw new Error('No image URL in media data');
                    })
                    .catch(error => {
                        // API fetch failed or no image URL - show placeholder
                        console.debug('Image fetch failed for media ID ' + mediaId + ':', error);
                        container.classList.add('no-image');
                        container.innerHTML = '<div class="no-image-placeholder">📄</div>';
                    });
                
                // Return early - don't show placeholder yet, wait for API response
                return;
            }
        }
        
        // No media ID available - show placeholder immediately
        container.classList.add('no-image');
        container.innerHTML = '<div class="no-image-placeholder">📄</div>';
    };
    
    window.handleImageLoad = function(img) {
        const container = img.parentElement;
        container.classList.remove('no-image');
    };
    
    // =========================================================================
    // AI ANSWER FUNCTIONALITY
    // =========================================================================
    window.toggleAIAnswer = function(button) {
        const answerDiv = button.closest('.hybrid-search-ai-answer');
        if (!answerDiv) return;

        const content = answerDiv.querySelector('.hybrid-search-ai-answer-content');
        if (!content) return;

        const toggleText = button.querySelector('span:first-child');
        const toggleIcon = button.querySelector('.hybrid-search-ai-answer-toggle-icon');
        const answerContainer = content.querySelector('.hybrid-search-ai-answer-body');
        const fullAttr = content.getAttribute('data-full');
        const previewAttr = content.getAttribute('data-preview');

        const isCollapsed = content.classList.contains('collapsed');

        if (isCollapsed) {
            content.classList.remove('collapsed');
            button.classList.add('expanded');
            button.setAttribute('aria-expanded', 'true');
            if (toggleText) toggleText.textContent = 'Show less';
            if (toggleIcon) toggleIcon.textContent = '▲';
            if (answerContainer && fullAttr) {
                answerContainer.innerHTML = decodeURIComponent(fullAttr);
            }
        } else {
            content.classList.add('collapsed');
            button.classList.remove('expanded');
            button.setAttribute('aria-expanded', 'false');
            if (toggleText) toggleText.textContent = 'Show more';
            if (toggleIcon) toggleIcon.textContent = '▼';
            if (answerContainer) {
                if (previewAttr) {
                    answerContainer.innerHTML = decodeURIComponent(previewAttr);
                } else if (fullAttr) {
                    // Generate preview on the fly if attribute missing
                    const previewData = createAIAnswerPreview(decodeURIComponent(fullAttr));
                    content.setAttribute('data-preview', encodeURIComponent(previewData.preview));
                    answerContainer.innerHTML = previewData.preview;
                }
            }
        }
    };
    
    // =========================================================================
    // FILTER FUNCTIONALITY
    // =========================================================================
    function initializeFilters() {
        // Filter functionality would go here
        // This is a placeholder for future filter implementation
    }
    
    window.toggleSearchFilters = function() {
        const filtersContainer = document.querySelector('.hybrid-search-filters');
        const toggleButton = document.querySelector('.hybrid-search-filters-toggle');
        
        if (filtersContainer && toggleButton) {
            // Toggle the 'closed' class instead of inline styles
            const isClosed = filtersContainer.classList.contains('closed');
            
            if (isClosed) {
                // Show filters
                filtersContainer.classList.remove('closed');
                toggleButton.textContent = 'Hide Filters';
                toggleButton.setAttribute('aria-expanded', 'true');
            } else {
                // Hide filters
                filtersContainer.classList.add('closed');
                toggleButton.textContent = 'Show Filters';
                toggleButton.setAttribute('aria-expanded', 'false');
            }
        }
    };
    
    function getFilterValues() {
        return {
            type: (document.querySelector('.hybrid-search-filter-type')?.value || document.getElementById('filter-type')?.value || '').trim(),
            date: (document.getElementById('filter-date')?.value || '').trim(),
            sort: (document.getElementById('filter-sort')?.value || 'relevance').trim(),
            limit: (document.getElementById('filter-limit')?.value || hybridSearch.maxResults || 10)
        };
    }
    
    function updateActiveFilters(filters) {
        const activeFiltersContainer = document.getElementById('active-filters');
        if (!activeFiltersContainer) return;
        
        // Clear existing active filters
        activeFiltersContainer.innerHTML = '';
        
        const activeFilters = [];
        
        if (filters.type) {
            activeFilters.push({
                label: 'Type: ' + filters.type,
                key: 'type',
                value: filters.type
            });
        }
        
        if (filters.date) {
            const dateLabels = {
                'day': 'Last 24 hours',
                'week': 'Last week',
                'month': 'Last month',
                'year': 'Last year'
            };
            activeFilters.push({
                label: 'Date: ' + (dateLabels[filters.date] || filters.date),
                key: 'date',
                value: filters.date
            });
        }
        
        if (filters.sort && filters.sort !== 'relevance') {
            const sortLabels = {
                'date-desc': 'Date: Newest First',
                'date-asc': 'Date: Oldest First',
                'title-asc': 'Title: A-Z'
            };
            activeFilters.push({
                label: 'Sort: ' + (sortLabels[filters.sort] || filters.sort),
                key: 'sort',
                value: filters.sort
            });
        }
        
        if (activeFilters.length > 0) {
            activeFilters.forEach(filter => {
                const filterTag = document.createElement('span');
                filterTag.className = 'hybrid-search-active-filter';
                filterTag.innerHTML = filter.label + ' <button type="button" class="hybrid-search-remove-filter" data-filter-key="' + escapeHtml(filter.key) + '" onclick="removeFilter(\'' + escapeHtml(filter.key) + '\')">×</button>';
                activeFiltersContainer.appendChild(filterTag);
            });
            activeFiltersContainer.style.display = 'block';
        } else {
            activeFiltersContainer.style.display = 'none';
        }
    }
    
    window.applySearchFilters = function() {
        const query = getCurrentSearchQuery();
        if (!query || query.trim().length < 3) {
            alert('Please enter a search query (at least 3 characters)');
            return;
        }
        
        const filters = getFilterValues();
        updateActiveFilters(filters);
        
        // Reset to page 1 and perform new search with filters
        currentPage = 1;
        performSearch(query, 1, filters);
    };
    
    window.resetSearchFilters = function() {
        // Reset all filter inputs (check both class and ID selectors)
        const typeSelect = document.querySelector('.hybrid-search-filter-type') || document.getElementById('filter-type');
        const dateSelect = document.querySelector('.hybrid-search-filter-date') || document.getElementById('filter-date');
        const sortSelect = document.querySelector('.hybrid-search-filter-sort') || document.getElementById('filter-sort');
        
        if (typeSelect) typeSelect.value = '';
        if (dateSelect) dateSelect.value = '';
        if (sortSelect) sortSelect.value = 'relevance';
        
        // Clear active filters display
        const activeFiltersContainer = document.getElementById('active-filters');
        if (activeFiltersContainer) {
            activeFiltersContainer.innerHTML = '';
            activeFiltersContainer.style.display = 'none';
        }
        
        // Re-run search without filters
        const query = getCurrentSearchQuery();
        if (query && query.trim().length >= 3) {
            currentPage = 1;
            performSearch(query, 1, { type: '', date: '', sort: 'relevance' });
        }
    };
    
    window.removeFilter = function(filterKey) {
        // Remove specific filter (check both class and ID selectors)
        if (filterKey === 'type') {
            const typeSelect = document.querySelector('.hybrid-search-filter-type') || document.getElementById('filter-type');
            if (typeSelect) typeSelect.value = '';
        } else if (filterKey === 'date') {
            const dateSelect = document.querySelector('.hybrid-search-filter-date') || document.getElementById('filter-date');
            if (dateSelect) dateSelect.value = '';
        } else if (filterKey === 'sort') {
            const sortSelect = document.querySelector('.hybrid-search-filter-sort') || document.getElementById('filter-sort');
            if (sortSelect) sortSelect.value = 'relevance';
        }
        
        // Update active filters and re-run search
        const filters = getFilterValues();
        updateActiveFilters(filters);
        
        const query = getCurrentSearchQuery();
        if (query && query.trim().length >= 3) {
            currentPage = 1;
            performSearch(query, 1, filters);
        }
    };
    
    // =========================================================================
    // KEYBOARD SHORTCUTS
    // =========================================================================
    function initializeKeyboardShortcuts() {
        if (!hybridSearch.enableKeyboardShortcuts) return;
        
        document.addEventListener('keydown', function(e) {
            // Ctrl/Cmd + K to focus search
            if ((e.ctrlKey || e.metaKey) && e.key === 'k') {
                e.preventDefault();
                const searchInput = document.querySelector('.hybrid-search-input');
                if (searchInput) {
                    searchInput.focus();
                }
            }
            
            // Common shortcut: '/' to focus search when not typing
            if (!e.ctrlKey && !e.metaKey && e.key === '/') {
                const activeEl = document.activeElement;
                const isInInput = activeEl && (activeEl.tagName === 'INPUT' || activeEl.tagName === 'TEXTAREA');
                if (!isInInput) {
                    e.preventDefault();
                    const searchInput = document.querySelector('.hybrid-search-input');
                    if (searchInput) searchInput.focus();
                }
            }
            
            // Escape to clear search
            if (e.key === 'Escape') {
                const searchInput = document.querySelector('.hybrid-search-input');
                if (searchInput && document.activeElement === searchInput) {
                    searchInput.value = '';
                    searchInput.blur();
                }
            }
        });
    }
    
    // =========================================================================
    // DEBUGGING FUNCTIONS (only in debug mode)
    // =========================================================================
    window.testHybridSearch = function() {
        // Testing Hybrid Search...
        if (window.hybridSearchInstance) {
            window.hybridSearchInstance.performSearch('test query');
        } else {
            // Hybrid Search instance not found
        }
    };
    
})(jQuery);