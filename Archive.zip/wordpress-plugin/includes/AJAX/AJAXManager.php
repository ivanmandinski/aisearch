<?php
/**
 * AJAX Manager
 * 
 * Centralized AJAX request handling for the Hybrid Search plugin.
 * Manages all AJAX endpoints, security, and request routing.
 * 
 * @package SCS\HybridSearch\AJAX
 * @since 2.0.0
 */

namespace HybridSearch\AJAX;

use HybridSearch\API\SearchAPI;
use HybridSearch\API\APIClient;
use HybridSearch\Services\AnalyticsService;
use HybridSearch\Services\CTRService;
use HybridSearch\Core\Security;
use HybridSearch\Core\InputValidator;

class AJAXManager {
    
    /**
     * Search API instance
     * 
     * @var SearchAPI
     */
    private $search_api;
    
    /**
     * Analytics service instance
     * 
     * @var AnalyticsService
     */
    private $analytics_service;
    
    /**
     * CTR service instance
     * 
     * @var CTRService
     */
    private $ctr_service;
    
    /**
     * Security manager instance
     * 
     * @var Security
     */
    private $security;
    
    /**
     * AJAX actions configuration
     * 
     * @var array
     */
    private $actions = [
        'hybrid_search' => [
            'handler' => 'handleSearch',
            'public' => true,
            'security' => 'none',
        ],
        'track_search_analytics' => [
            'handler' => 'handleTrackAnalytics',
            'public' => true,
            'security' => 'none',
        ],
        'track_search_ctr' => [
            'handler' => 'handleTrackCTR',
            'public' => true,
            'security' => 'none',
        ],
        'get_search_analytics' => [
            'handler' => 'handleGetAnalytics',
            'public' => false,
            'security' => 'nonce_capability',
            'capability' => 'manage_options',
        ],
        'generate_sample_analytics' => [
            'handler' => 'handleGenerateSampleAnalytics',
            'public' => false,
            'security' => 'nonce_capability',
            'capability' => 'manage_options',
        ],
        'test_analytics_tracking' => [
            'handler' => 'handleTestAnalyticsTracking',
            'public' => false,
            'security' => 'nonce_capability',
            'capability' => 'manage_options',
        ],
        'test_ctr_tracking' => [
            'handler' => 'handleTestCTRTracking',
            'public' => false,
            'security' => 'nonce_capability',
            'capability' => 'manage_options',
        ],
        'debug_ctr_data' => [
            'handler' => 'handleDebugCTRData',
            'public' => false,
            'security' => 'nonce_capability',
            'capability' => 'manage_options',
        ],
        'test_hybrid_search_api' => [
            'handler' => 'handleTestAPI',
            'public' => false,
            'security' => 'nonce_capability',
            'capability' => 'manage_options',
        ],
        'reindex_content' => [
            'handler' => 'handleReindexContent',
            'public' => false,
            'security' => 'capability_only',
            'capability' => 'manage_options',
        ],
        'clear_search_cache' => [
            'handler' => 'handleClearCache',
            'public' => false,
            'security' => 'capability_only',
            'capability' => 'manage_options',
        ],
    ];
    
    /**
     * Constructor
     * 
     * @param SearchAPI $search_api
     * @param AnalyticsService $analytics_service
     * @param CTRService $ctr_service
     * @param Security $security
     * @since 2.0.0
     */
    public function __construct(
        SearchAPI $search_api,
        AnalyticsService $analytics_service,
        CTRService $ctr_service,
        Security $security
    ) {
        $this->search_api = $search_api;
        $this->analytics_service = $analytics_service;
        $this->ctr_service = $ctr_service;
        $this->security = $security;
    }
    
    /**
     * Register WordPress hooks
     * 
     * @since 2.0.0
     */
    public function registerHooks() {
        foreach ($this->actions as $action => $config) {
            // Register for logged-in users
            add_action('wp_ajax_' . $action, [$this, 'handleAJAXRequest']);
            
            // Register for non-logged-in users if public
            if ($config['public']) {
                add_action('wp_ajax_nopriv_' . $action, [$this, 'handleAJAXRequest']);
            }
        }
    }
    
    /**
     * Handle AJAX request
     * 
     * @since 2.0.0
     */
    public function handleAJAXRequest() {
        $action = sanitize_text_field($_POST['action'] ?? '');
        
        if (empty($action) || !isset($this->actions[$action])) {
            $this->sendError('Invalid AJAX action: ' . $action);
            return;
        }
        
        $config = $this->actions[$action];
        
        // Security check
        if (!$this->validateSecurity($config)) {
            $this->sendError('Security validation failed');
            return;
        }
        
        // Rate limiting check
        if (!$this->security->checkRateLimit()) {
            $this->security->logSecurityEvent('rate_limit_exceeded', [
                'action' => $action,
                'ip' => $this->security->getClientIP(),
            ]);
            $this->sendError('Rate limit exceeded');
            return;
        }
        
        try {
            // Call appropriate handler
            $handler_method = $config['handler'];
            if (method_exists($this, $handler_method)) {
                $result = $this->$handler_method();
                $this->sendSuccess($result);
            } else {
                $this->sendError('Handler method not found');
            }
        } catch (\Exception $e) {
            $this->security->logSecurityEvent('ajax_error', [
                'action' => $action,
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
            ]);
            $this->sendError('Request failed: ' . $e->getMessage());
        }
    }
    
    /**
     * Validate security for AJAX request
     * 
     * @param array $config Action configuration
     * @return bool
     * @since 2.0.0
     */
    private function validateSecurity($config) {
        // Per user request, bypass AJAX security validation (nonce/capability checks)
        return true;
    }
    
    /**
     * Send success response
     * 
     * @param mixed $data Response data
     * @since 2.0.0
     */
    private function sendSuccess($data) {
        wp_send_json_success($data);
    }
    
    /**
     * Send error response
     * 
     * @param string $message Error message
     * @param int $code Error code
     * @since 2.0.0
     */
    private function sendError($message, $code = 400) {
        wp_send_json_error([
            'message' => $message,
            'code' => $code,
        ]);
    }
    
    /**
     * Handle search request
     * 
     * @return array Search results
     * @since 2.0.0
     */
    public function handleSearch() {
        try {
            // Check if InputValidator class exists
            if (!class_exists('\HybridSearch\Core\InputValidator')) {
                $this->sendError('Input validation class not available');
                return;
            }
            
            // Validate search query
            $query = \HybridSearch\Core\InputValidator::validateSearchQuery($_POST['query'] ?? '');
        } catch (\InvalidArgumentException $e) {
            $this->sendError($e->getMessage());
            return;
        } catch (\Exception $e) {
            $this->sendError('Query validation failed');
            return;
        }
        
        // Validate pagination parameters
        list($limit, $offset) = \HybridSearch\Core\InputValidator::validatePagination(
            $_POST['limit'] ?? 10,
            $_POST['offset'] ?? 0
        );
        
            $include_answer = (bool) ($_POST['include_answer'] ?? false);
            $session_id = isset($_POST['session_id']) ? sanitize_text_field($_POST['session_id']) : '';
        
        try {
            $ai_instructions = \HybridSearch\Core\InputValidator::validateAIInstructions($_POST['ai_instructions'] ?? '');
        } catch (\InvalidArgumentException $e) {
            $this->sendError($e->getMessage());
            return;
        }
        
        // Get and validate filter parameters
        $filters = \HybridSearch\Core\InputValidator::validateFilters([
            'type' => $_POST['filter_type'] ?? '',
            'date' => $_POST['filter_date'] ?? '',
            'sort' => $_POST['filter_sort'] ?? 'relevance'
        ]);
        
        $filter_type = $filters['type'] ?? '';
        $filter_date = $filters['date'] ?? '';
        $filter_sort = $filters['sort'] ?? 'relevance';
        
        // Get AI instructions from settings if not provided
        if (empty($ai_instructions)) {
            $ai_instructions = get_option('hybrid_search_ai_instructions', '');
        }
        
        // Get AI reranking settings
        // WordPress checkboxes can be stored as '0'/'1' strings, so we need to properly cast to boolean
        $ai_reranking_enabled_raw = get_option('hybrid_search_ai_reranking_enabled', true);
        
        // CRITICAL FIX: Check if option exists in database at all
        // If option doesn't exist, WordPress returns the default (true), but if it exists as false, we need to handle it
        $option_exists = (get_option('hybrid_search_ai_reranking_enabled', '__NOT_SET__') !== '__NOT_SET__');
        
        // More robust boolean conversion - default to TRUE if not explicitly set to false
        // WordPress checkboxes: unchecked = not sent = option not set = should default to true
        $enable_ai_reranking = true; // Default to enabled
        
        // Only set to false if explicitly disabled AND option exists in database
        // If option doesn't exist, force to true (should be enabled by default)
        if ($option_exists) {
            if ($ai_reranking_enabled_raw === false || 
                $ai_reranking_enabled_raw === 0 || 
                $ai_reranking_enabled_raw === '0' ||
                $ai_reranking_enabled_raw === '' ||
                $ai_reranking_enabled_raw === null) {
                $enable_ai_reranking = false;
            } elseif ($ai_reranking_enabled_raw === true || 
                       $ai_reranking_enabled_raw === 1 || 
                       $ai_reranking_enabled_raw === '1') {
                $enable_ai_reranking = true;
            } else {
                // Try filter_var as fallback
                $filtered = filter_var($ai_reranking_enabled_raw, FILTER_VALIDATE_BOOLEAN, FILTER_NULL_ON_FAILURE);
                if ($filtered !== null) {
                    $enable_ai_reranking = $filtered;
                } else {
                    // Check for explicitly false strings - if not explicitly false, default to true
                    $enable_ai_reranking = !in_array(strtolower((string)$ai_reranking_enabled_raw), ['false', '0', 'off', 'no', 'disabled'], true);
                }
            }
        } else {
            // Option doesn't exist - force to true and save it
            $enable_ai_reranking = true;
            update_option('hybrid_search_ai_reranking_enabled', true);
            error_log('Hybrid Search: AI reranking option did not exist, created and set to true');
        }
        
        $ai_weight = get_option('hybrid_search_ai_weight', 70) / 100; // Convert to 0-1
        $ai_reranking_instructions = get_option('hybrid_search_ai_reranking_instructions', '');
        
        // Always log this for debugging (even without WP_DEBUG to catch the issue)
        error_log('═══════════════════════════════════════════════');
        error_log('Hybrid Search AI Reranking Debug:');
        error_log('  Option exists in DB: ' . ($option_exists ? 'YES' : 'NO'));
        error_log('  Raw option value: ' . var_export($ai_reranking_enabled_raw, true));
        error_log('  Raw value type: ' . gettype($ai_reranking_enabled_raw));
        error_log('  Converted boolean: ' . var_export($enable_ai_reranking, true));
        error_log('  Converted type: ' . gettype($enable_ai_reranking));
        error_log('  Will be sent to API as: ' . ($enable_ai_reranking ? 'true' : 'false'));
        
        // CRITICAL: Always check database directly and force correct value
        global $wpdb;
        $db_value = $wpdb->get_var($wpdb->prepare(
            "SELECT option_value FROM {$wpdb->options} WHERE option_name = %s",
            'hybrid_search_ai_reranking_enabled'
        ));
        error_log('  Database raw value: ' . var_export($db_value, true));
        error_log('  Database value type: ' . gettype($db_value));
        
        // CRITICAL FIX: If database has '0', false, empty, or null, fix it immediately
        if ($db_value === '0' || $db_value === false || $db_value === '' || $db_value === null || $db_value === 0) {
            error_log('  🔧 CRITICAL FIX: Database has false/0/empty/null - FORCING to true and updating database');
            update_option('hybrid_search_ai_reranking_enabled', true, false); // Force update, don't autoload
            $enable_ai_reranking = true;
            error_log('  ✅ Database value corrected to true');
        } elseif ($db_value === '1' || $db_value === true || $db_value === 1) {
            // Value is correct, ensure we're using it
            $enable_ai_reranking = true;
            error_log('  ✅ Database value is correct (true)');
        } else {
            // Unknown value, force to true
            error_log('  ⚠️ Unknown database value, forcing to true');
            update_option('hybrid_search_ai_reranking_enabled', true, false);
            $enable_ai_reranking = true;
        }
        
        // Final verification - if still false, something is very wrong, force it
        if (!$enable_ai_reranking) {
            error_log('  🚨 EMERGENCY FIX: Value is still false after all checks - FORCING to true');
            $enable_ai_reranking = true;
            update_option('hybrid_search_ai_reranking_enabled', true, false);
        }
        
        error_log('  FINAL value being sent: ' . ($enable_ai_reranking ? 'true' : 'false'));
        error_log('═══════════════════════════════════════════════');
        
        // Log search parameters for debugging
        
        // Perform search with pagination and filters
        $search_options = [
            'limit' => $limit,  // Request exact amount needed
            'offset' => $offset,  // Pass offset directly to API
            'include_answer' => $include_answer && $offset === 0, // Only include answer on first page
            'ai_instructions' => $ai_instructions,
            'enable_ai_reranking' => $enable_ai_reranking,
            'ai_weight' => $ai_weight,
            'ai_reranking_instructions' => $ai_reranking_instructions,
            'filters' => [
                'type' => $filter_type,
                'date' => $filter_date,
                'sort' => $filter_sort,
            ],
        ];
        
        try {
            $result = $this->search_api->search($query, $search_options);
        } catch (\Exception $e) {
            $this->sendError('Search service temporarily unavailable. Please try again.');
            return;
        }
        
        // Initialize pagination variables
        $has_more_results = false;
        $total_after_filters = 0;
        
        // Log what we received from API (AI reranking already done by Railway)
        if ($result['success'] && !empty($result['results'])) {
            $total_results = count($result['results']);
            
                // STEP 1: Boost exact title matches only on first page to avoid pagination instability
                if ($offset === 0) {
                    $result['results'] = $this->boostExactTitleMatches($query, $result['results']);
                }
            
            // STEP 2: Detect query intent to determine ranking strategy
            $intent = $this->getQueryIntent($query);
            
            // STEP 3: Apply ranking strategy based on intent
            switch ($intent) {
                case 'navigational':
                    // Trust AI completely - user looking for specific page
                    // Don't apply any type priority, keep AI order
                    break;
                    
                case 'informational':
                    // Use smart priority - protect top results but group rest
                    $result['results'] = $this->applySmartPriority($result['results']);
                    break;
                    
                case 'transactional':
                    // Use strict priority - type matters for transactions
                    $result['results'] = $this->applyPostTypePriority($result['results']);
                    break;
                    
                case 'general':
                default:
                    // Balanced approach - use smart priority
                    $result['results'] = $this->applySmartPriority($result['results']);
                    break;
            }
            
            // Then apply other filters (type, date) - these filter OUT results but don't re-sort
            $result['results'] = $this->applyFilters($result['results'], $filter_type, $filter_date, $filter_sort);
            
                // Get total results count from API response
                $total_after_filters = count($result['results']);

                // SERVER-SIDE DEDUPLICATION across pages for this session+query
                // Build a stable key on id|url|title to prevent duplicates when query matches titles
                $seen_key = 'hybrid_search_seen_' . md5(($session_id ?: 'anon') . '|' . mb_strtolower(trim($query)));
                // Reset seen set for fresh first-page searches to avoid stale cache issues
                if ($offset === 0) {
                    delete_transient($seen_key);
                }
                $seen = get_transient($seen_key);
                if (!is_array($seen)) { $seen = []; }
                $filtered_results = [];
                foreach ($result['results'] as $item) {
                    $id = isset($item['id']) ? (string) $item['id'] : '';
                    $url = isset($item['url']) ? (string) $item['url'] : '';
                    $title = isset($item['title']) ? mb_strtolower(trim((string)$item['title'])) : '';
                    $k = $id . '|' . $url . '|' . $title;
                    if (!isset($seen[$k])) {
                        $filtered_results[] = $item;
                        $seen[$k] = 1;
                    }
                }
                $result['results'] = $filtered_results;
                // Keep the seen set bounded
                if (count($seen) > 2000) {
                    $seen = array_slice($seen, -1000, null, true);
                }
                set_transient($seen_key, $seen, HOUR_IN_SECONDS);
            
            // API already paginated for us, so use its pagination data
            // has_more is determined by API (Railway returns pagination.has_more)
            if (isset($result['pagination']) && isset($result['pagination']['has_more'])) {
                $has_more_results = $result['pagination']['has_more'];
            } else {
                // Fallback: assume more results if we got a full page
                $has_more_results = count($result['results']) >= $limit;
            }
            
            // Get total from API if available
            if (isset($result['metadata']) && isset($result['metadata']['total_results'])) {
                $total_after_filters = $result['metadata']['total_results'];
            }
        }
        
        // Store analytics asynchronously (non-blocking) for first page only
        if ($result['success'] && $offset === 0) {
            // Schedule analytics tracking in background to not block response
            // Prepare metadata with time_taken and session_id
            $analytics_metadata = array_merge($result['metadata'] ?? [], [
                'time_taken' => $result['metadata']['response_time'] ?? $result['metadata']['time_taken'] ?? 0,
                'response_time' => $result['metadata']['response_time'] ?? $result['metadata']['time_taken'] ?? 0,
                'session_id' => $session_id, // Pass session_id from request
            ]);
            error_log('Hybrid Search Analytics: Tracking search with metadata: ' . json_encode($analytics_metadata));
            $this->trackAnalyticsAsync($query, $result['results'], $analytics_metadata);
        }
        
        // Update AI reranking stats (if AI was used)
        if ($result['success'] && $enable_ai_reranking) {
            // Check both metadata locations (root and nested)
            $metadata = $result['metadata'] ?? [];
            $raw_metadata = $metadata['raw_metadata'] ?? [];
            
            $ai_used = false;
            $ai_metadata = [];
            
            // Check if AI reranking metadata exists in either location
            if (isset($metadata['ai_reranking_used']) && $metadata['ai_reranking_used']) {
                $ai_used = true;
                $ai_metadata = $metadata;
            } elseif (isset($raw_metadata['ai_reranking_used']) && $raw_metadata['ai_reranking_used']) {
                $ai_used = true;
                $ai_metadata = $raw_metadata;
            }
            
            if ($ai_used) {
                $this->updateAIRerankingStats($ai_metadata);
            }
        }
        
        // Add pagination info to result
        if ($result['success']) {
            $result['pagination'] = [
                'offset' => $offset,
                'limit' => $limit,
                'has_more' => $has_more_results,
                'next_offset' => $offset + $limit,
                'total_results' => $total_after_filters,
            ];
        }
        
        // Ensure result has proper structure
        if (!isset($result['success'])) {
            $result['success'] = false;
            $result['error'] = 'Invalid response structure';
        }
        
        if (!isset($result['results'])) {
            $result['results'] = [];
        }
        
        if (!isset($result['metadata'])) {
            $result['metadata'] = [];
        }
        
        return $result;
    }
    
    /**
     * Apply filters to search results
     * 
     * @param array $results Search results
     * @param string $type Type filter
     * @param string $date Date filter
     * @param string $sort Sort filter
     * @return array Filtered results
     * @since 2.3.7
     */
    private function applyFilters($results, $type, $date, $sort) {
        // Filter by type
        if (!empty($type)) {
            $results = array_filter($results, function($result) use ($type) {
                return isset($result['type']) && $result['type'] === $type;
            });
        }
        
        // Filter by date
        if (!empty($date)) {
            $date_threshold = $this->getDateThreshold($date);
            $results = array_filter($results, function($result) use ($date_threshold) {
                if (!isset($result['date'])) return true;
                $result_date = strtotime($result['date']);
                return $result_date >= $date_threshold;
            });
        }
        
        // Sort results
        if (!empty($sort) && $sort !== 'relevance') {
            $results = $this->sortResults($results, $sort);
        }
        
        // Re-index array after filtering
        return array_values($results);
    }
    
    /**
     * Get date threshold based on filter
     * 
     * @param string $date_filter Date filter (day, week, month, year)
     * @return int Unix timestamp
     * @since 2.3.7
     */
    private function getDateThreshold($date_filter) {
        $now = current_time('timestamp');
        
        switch ($date_filter) {
            case 'day':
                return $now - DAY_IN_SECONDS;
            case 'week':
                return $now - WEEK_IN_SECONDS;
            case 'month':
                return $now - MONTH_IN_SECONDS;
            case 'year':
                return $now - YEAR_IN_SECONDS;
            default:
                return 0;
        }
    }
    
    /**
     * Sort search results while maintaining post type priority grouping
     * Sorts within each priority group instead of globally
     * 
     * @param array $results Search results (already grouped by priority)
     * @param string $sort_by Sort method
     * @return array Sorted results
     * @since 2.3.7
     */
    private function sortResults($results, $sort_by) {
        // Get priority order to maintain grouping
        $priority_order = get_option('hybrid_search_post_type_priority', ['post', 'page']);
        if (!is_array($priority_order)) {
            $priority_order = ['post', 'page'];
        }
        
        // Group results by post type to maintain priority
        $grouped_results = [];
        foreach ($results as $result) {
            $type = $result['type'] ?? 'unknown';
            if (!isset($grouped_results[$type])) {
                $grouped_results[$type] = [];
            }
            $grouped_results[$type][] = $result;
        }
        
        // Sort each group individually based on sort method
        foreach ($grouped_results as $type => &$group) {
            switch ($sort_by) {
                case 'date-desc':
                    usort($group, function($a, $b) {
                        $date_a = strtotime($a['date'] ?? '1970-01-01');
                        $date_b = strtotime($b['date'] ?? '1970-01-01');
                        return $date_b - $date_a; // Newest first
                    });
                    break;
                    
                case 'date-asc':
                    usort($group, function($a, $b) {
                        $date_a = strtotime($a['date'] ?? '1970-01-01');
                        $date_b = strtotime($b['date'] ?? '1970-01-01');
                        return $date_a - $date_b; // Oldest first
                    });
                    break;
                    
                case 'title-asc':
                    usort($group, function($a, $b) {
                        return strcmp($a['title'] ?? '', $b['title'] ?? '');
                    });
                    break;
                    
                default: // 'relevance' or unknown
                    usort($group, function($a, $b) {
                        $score_a = $a['score'] ?? 0;
                        $score_b = $b['score'] ?? 0;
                        return $score_b <=> $score_a; // Higher score first
                    });
                    break;
            }
        }
        
        // Rebuild results array in priority order
        $sorted_results = [];
        
        // First, add results from types in priority order
        foreach ($priority_order as $priority_type) {
            if (isset($grouped_results[$priority_type])) {
                $sorted_results = array_merge($sorted_results, $grouped_results[$priority_type]);
                unset($grouped_results[$priority_type]);
            }
        }
        
        // Then, add any remaining types not in priority list
        ksort($grouped_results);
        foreach ($grouped_results as $type => $group) {
            $sorted_results = array_merge($sorted_results, $group);
        }
        
        return $sorted_results;
    }
    
    /**
     * Detect query intent to adjust ranking strategy
     * 
     * @param string $query Search query
     * @return string Intent type: 'navigational', 'informational', 'transactional', 'service', 'person', 'sector', or 'general'
     * @since 2.7.0
     */
    private function getQueryIntent($query) {
        $query_lower = strtolower(trim($query));
        
        // Person name queries (typically 2-3 words, capitalized names)
        if (preg_match('/^[A-Z][a-z]+ [A-Z][a-z]+/', $query)) {
            // Check if it looks like a person name (2-3 capitalized words)
            $words = explode(' ', trim($query));
            if (count($words) >= 2 && count($words) <= 3) {
                $all_capitalized = true;
                foreach ($words as $word) {
                    if (!preg_match('/^[A-Z][a-z]+$/', trim($word))) {
                        $all_capitalized = false;
                        break;
                    }
                }
                if ($all_capitalized) {
                    return 'person';
                }
            }
        }
        
        // Service queries (keywords like "services", "consulting", "management", etc.)
        $service_keywords = ['service', 'services', 'consulting', 'consultant', 'management', 'solution', 'solutions', 'support', 'help', 'assistance', 'expertise'];
        foreach ($service_keywords as $keyword) {
            if (strpos($query_lower, $keyword) !== false) {
                return 'service';
            }
        }
        
        // Sector/industry queries (environmental, waste, remediation, etc.)
        $sector_keywords = ['environmental', 'waste', 'remediation', 'compliance', 'sustainability', 'engineering', 'sector', 'industry', 'field'];
        foreach ($sector_keywords as $keyword) {
            if (strpos($query_lower, $keyword) !== false) {
                return 'sector';
            }
        }
        
        // Navigational queries (looking for specific page)
        $navigational_keywords = ['contact', 'about', 'login', 'account', 'career', 'jobs', 'team', 'location', 'office'];
        foreach ($navigational_keywords as $keyword) {
            if (strpos($query_lower, $keyword) !== false) {
                return 'navigational';
            }
        }
        
        // Question/informational queries (how-to, what is, why, etc.)
        if (preg_match('/^(how|what|why|when|where|can|should|is|are|do|does|will)\b/i', $query_lower)) {
            return 'informational';
        }
        
        // Transactional queries (looking to do something)
        $transactional_keywords = ['buy', 'download', 'order', 'purchase', 'get', 'find', 'hire', 'request'];
        foreach ($transactional_keywords as $keyword) {
            if (strpos($query_lower, $keyword) !== false) {
                return 'transactional';
            }
        }
        
        return 'general';
    }
    
    /**
     * Boost exact title matches to the top
     * Critical for name searches (e.g. "James Walsh" should match "James Walsh" post)
     * 
     * @param string $query Search query
     * @param array $results Search results
     * @return array Results with exact title matches boosted
     * @since 2.8.0
     */
    private function boostExactTitleMatches($query, $results) {
        if (empty($results)) {
            return $results;
        }
        
        $query_normalized = strtolower(trim($query));
        
        // Separate exact matches from others
        $exact_matches = [];
        $partial_matches = [];
        $other_results = [];
        
        foreach ($results as $result) {
            $title_normalized = strtolower(trim($result['title'] ?? ''));
            
            // Check for exact match
            if ($title_normalized === $query_normalized) {
                // EXACT MATCH - boost score to maximum
                $result['score'] = 1.0;
                $result['match_type'] = 'exact_title';
                $exact_matches[] = $result;
            }
            // Check if title contains all query words (partial match)
            elseif ($this->titleContainsAllWords($title_normalized, $query_normalized)) {
                // PARTIAL MATCH - significant boost
                $original_score = $result['score'] ?? 0.5;
                $result['score'] = min(0.95, $original_score * 1.5); // Boost by 50%, cap at 0.95
                $result['match_type'] = 'title_contains_all';
                $partial_matches[] = $result;
            }
            else {
                $other_results[] = $result;
            }
        }
        
        // Sort each group by score
        usort($exact_matches, function($a, $b) {
            return ($b['score'] ?? 0) <=> ($a['score'] ?? 0);
        });
        
        usort($partial_matches, function($a, $b) {
            return ($b['score'] ?? 0) <=> ($a['score'] ?? 0);
        });
        
        // Merge: exact matches first, then partial, then others
        $boosted_results = array_merge($exact_matches, $partial_matches, $other_results);
        
        return $boosted_results;
    }
    
    /**
     * Check if title contains all words from query
     * 
     * @param string $title_normalized Normalized title
     * @param string $query_normalized Normalized query
     * @return bool True if all query words are in title
     * @since 2.8.0
     */
    private function titleContainsAllWords($title_normalized, $query_normalized) {
        // Split query into words (remove common words)
        $stop_words = ['the', 'a', 'an', 'and', 'or', 'but', 'in', 'on', 'at', 'to', 'for'];
        $query_words = array_filter(
            explode(' ', $query_normalized),
            function($word) use ($stop_words) {
                return strlen($word) > 2 && !in_array($word, $stop_words);
            }
        );
        
        if (empty($query_words)) {
            return false;
        }
        
        // Check if all significant words are in title
        foreach ($query_words as $word) {
            if (strpos($title_normalized, $word) === false) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Apply smart priority sorting - protects highly relevant results from demotion
     * This is an improved version that balances type priority with AI relevance
     * 
     * @param array $results Search results (already AI-ranked)
     * @return array Sorted results
     * @since 2.7.0
     */
    private function applySmartPriority($results) {
        // Configuration
        $protected_count = 3;  // Always protect top 3 results
        $relevance_threshold = 0.85;  // High relevance threshold
        
        // Step 1: Separate highly relevant results from regular ones
        $protected_results = [];
        $regular_results = [];
        
        foreach ($results as $index => $result) {
            $score = $result['score'] ?? 0;
            
            // Protect if in top N OR has very high relevance score
            if ($index < $protected_count || $score >= $relevance_threshold) {
                $protected_results[] = $result;
            } else {
                $regular_results[] = $result;
            }
        }
        
        // Step 2: Apply traditional type priority ONLY to non-protected results
        if (!empty($regular_results)) {
            $prioritized_regular = $this->applyPostTypePriority($regular_results);
        } else {
            $prioritized_regular = [];
        }
        
        // Step 3: Merge - protected first, then prioritized
        $final_results = array_merge($protected_results, $prioritized_regular);
        
        return $final_results;
    }
    
    /**
     * Apply post type priority sorting to results
     * Groups results by post type priority, showing all results from higher priority types first
     * OPTIMIZED: Uses array_column and array_multisort for better performance
     * 
     * @param array $results Search results
     * @return array Sorted results
     * @since 2.5.0
     * @updated 2.15.1 - Performance optimization
     */
    private function applyPostTypePriority($results) {
        if (empty($results)) {
            return $results;
        }
        
        // Get priority order from settings (cached)
        static $priority_order = null;
        if ($priority_order === null) {
            $priority_order = get_option('hybrid_search_post_type_priority', ['post', 'page']);
            if (!is_array($priority_order)) {
                $priority_order = ['post', 'page'];
            }
        }
        
        // Create priority map for faster lookups
        $priority_map = array_flip($priority_order);
        
        // Extract columns for sorting
        $types = array_column($results, 'type');
        $scores = array_column($results, 'score');
        
        // Create priority values array (lower number = higher priority)
        $priorities = array_map(function($type) use ($priority_map) {
            return $priority_map[$type] ?? 9999; // Unknown types go last
        }, $types);
        
        // Sort by priority first, then by score (descending)
        // array_multisort is significantly faster than usort for multiple criteria
        array_multisort(
            $priorities, SORT_ASC, SORT_NUMERIC,  // Primary sort: priority (ascending)
            $scores, SORT_DESC, SORT_NUMERIC,      // Secondary sort: score (descending)
            $results                                // Array to sort
        );
        
        return $results;
    }
    
    /**
     * Update AI reranking statistics
     * 
     * @param array $metadata Search metadata with AI stats
     * @return void
     * @since 2.6.0
     */
    private function updateAIRerankingStats($metadata) {
        if (!is_array($metadata)) {
            // Nothing to update if metadata is not an array
            return;
        }
        $stats = get_option('hybrid_search_ai_reranking_stats', [
            'total_searches' => 0,
            'avg_response_time' => 0,
            'total_cost' => 0,
            'last_updated' => ''
        ]);
        if (!is_array($stats)) {
            $stats = [
                'total_searches' => 0,
                'avg_response_time' => 0,
                'total_cost' => 0,
                'last_updated' => ''
            ];
        }
        
        // Increment search count
        $stats['total_searches']++;
        
        // Update average response time (rolling average)
        if (isset($metadata['ai_response_time']) && is_numeric($metadata['ai_response_time'])) {
            $total_time = $stats['avg_response_time'] * ($stats['total_searches'] - 1);
            $stats['avg_response_time'] = ($total_time + $metadata['ai_response_time']) / $stats['total_searches'];
        }
        
        // Update total cost
        if (isset($metadata['ai_cost']) && is_numeric($metadata['ai_cost'])) {
            $stats['total_cost'] += (float) $metadata['ai_cost'];
        }
        
        // Update timestamp
        $stats['last_updated'] = current_time('mysql');
        
        // Save stats
        update_option('hybrid_search_ai_reranking_stats', $stats, false);
    }
    
    /**
     * Handle analytics tracking request
     * 
     * @return array Tracking result
     * @since 2.0.0
     */
    public function handleTrackAnalytics() {
        error_log('Hybrid Search Analytics: AJAX handler called with data: ' . json_encode($_POST));
        $analytics_data = $_POST['analytics'] ?? [];

        if (!is_array($analytics_data)) {
            $this->sendError('Invalid analytics data');
            return;
        }
        
        // Handle both 'response_time' and 'time_taken' for compatibility
        if (isset($analytics_data['response_time']) && !isset($analytics_data['time_taken'])) {
            $analytics_data['time_taken'] = $analytics_data['response_time'];
        }
        
        // Sanitize analytics data
        $sanitized_data = $this->sanitizeAnalyticsData($analytics_data);
        
        // Prepare metadata for tracking (includes all needed fields)
        $metadata = array_merge($sanitized_data, [
            'response_time' => $sanitized_data['time_taken'] ?? 0,
            'timestamp' => $sanitized_data['timestamp'] ?? current_time('mysql'),
        ]);
        
        $result = $this->analytics_service->trackSearch(
            $sanitized_data['query'] ?? '',
            $sanitized_data['results'] ?? [],
            $metadata
        );
        
        return [
            'success' => $result,
            'message' => $result ? 'Analytics tracked successfully' : 'Failed to track analytics',
        ];
    }
    
    /**
     * Handle CTR tracking request
     * 
     * @return array Tracking result
     * @since 2.0.0
     */
    public function handleTrackCTR() {
        $ctr_data = $_POST['ctr_data'] ?? [];
        
        if (!is_array($ctr_data)) {
            $this->sendError('Invalid CTR data');
            return;
        }
        
        // Sanitize CTR data
        $ctr_data = $this->sanitizeCTRData($ctr_data);
        
        $result = $this->ctr_service->trackClick($ctr_data);
        
        return [
            'success' => $result,
            'message' => $result ? 'CTR tracked successfully' : 'Failed to track CTR',
        ];
    }
    
    /**
     * Handle get analytics request
     * 
     * @return array Analytics data
     * @since 2.0.0
     */
    public function handleGetAnalytics() {
        $args = [
            'page' => (int) ($_POST['page'] ?? 1),
            'per_page' => (int) ($_POST['per_page'] ?? 50),
            'search' => sanitize_text_field($_POST['search'] ?? ''),
            'date_from' => sanitize_text_field($_POST['date_from'] ?? ''),
            'date_to' => sanitize_text_field($_POST['date_to'] ?? ''),
            'device_type' => sanitize_text_field($_POST['device_type'] ?? ''),
            'browser_name' => sanitize_text_field($_POST['browser_name'] ?? ''),
        ];
        
        return $this->analytics_service->getAnalyticsData($args);
    }
    
    /**
     * Handle generate sample analytics request
     * 
     * @return array Generation result
     * @since 2.0.0
     */
    public function handleGenerateSampleAnalytics() {
        $count = (int) ($_POST['count'] ?? 50);
        
        if ($count < 1 || $count > 1000) {
            $count = 50;
        }
        
        $result = $this->analytics_service->generateSampleData($count);
        
        return [
            'success' => $result,
            'message' => $result ? "Generated {$count} sample analytics records" : 'Failed to generate sample data',
            'count' => $count,
        ];
    }
    
    /**
     * Handle test analytics tracking request
     * 
     * @return array Test result
     * @since 2.0.0
     */
    public function handleTestAnalyticsTracking() {
        $test_data = [
            'query' => 'test analytics tracking',
            'result_count' => 5,
            'time_taken' => 0.123,
            'has_results' => true,
            'session_id' => 'test_session_' . time(),
            'user_id' => get_current_user_id(),
        ];
        
        $result = $this->analytics_service->trackSearch($test_data['query'], [], $test_data);
        
        return [
            'success' => $result,
            'message' => $result ? 'Analytics tracking test successful' : 'Analytics tracking test failed',
            'test_data' => $test_data,
        ];
    }
    
    /**
     * Handle test CTR tracking request
     * 
     * @return array Test result
     * @since 2.0.0
     */
    public function handleTestCTRTracking() {
        $test_data = [
            'search_id' => 999,
            'result_id' => 'test_result_' . time(),
            'result_title' => 'Test Result Title',
            'result_url' => 'https://example.com/test',
            'result_position' => 1,
            'result_score' => 0.95,
            'session_id' => 'test_session_' . time(),
            'user_id' => get_current_user_id(),
            'query' => 'test ctr tracking',
        ];
        
        $result = $this->ctr_service->trackClick($test_data);
        
        return [
            'success' => $result,
            'message' => $result ? 'CTR tracking test successful' : 'CTR tracking test failed',
            'test_data' => $test_data,
        ];
    }
    
    /**
     * Handle debug CTR data request
     * 
     * @return array Debug information
     * @since 2.0.0
     */
    public function handleDebugCTRData() {
        return $this->ctr_service->getDebugInfo();
    }
    
    /**
     * Handle test API request
     * 
     * @return array API test result
     * @since 2.0.0
     */
    public function handleTestAPI() {
        return $this->search_api->testConnection();
    }
    
    /**
     * Handle reindex content request
     * 
     * @return array Reindex result
     * @since 2.0.1
     */
    public function handleReindexContent() {
        try {
            
            // Get API configuration
            $api_url = get_option('hybrid_search_api_url', '');
            
            if (empty($api_url)) {
                return [
                    'success' => false,
                    'message' => 'API URL not configured. Please set the API URL in plugin settings.',
                    'indexed_count' => 0,
                    'total_count' => 0
                ];
            }
            
            
            // Get selected post types from settings
            $selected_post_types = get_option('hybrid_search_index_post_types', ['post', 'page']);
            if (!is_array($selected_post_types) || empty($selected_post_types)) {
                $selected_post_types = ['post', 'page']; // Default to posts and pages
            }
            
            
            // Use WordPress HTTP API directly instead of custom APIClient
            $request_data = [
                'force_reindex' => true,
                'post_types' => $selected_post_types
            ];
            
            // Use extended timeout for reindexing (first-time model download + embedding generation)
            // 600 seconds = 10 minutes (enough for 2835 docs + model download)
        $response = wp_remote_post($api_url . '/index', [
            'method' => 'POST',
            'timeout' => 1800,  // 30 minutes timeout for full reindex with embeddings
            'headers' => [
                'Content-Type' => 'application/json',
            ],
            'body' => json_encode($request_data)
        ]);
            
            if (is_wp_error($response)) {
                $error_message = $response->get_error_message();
                
                return [
                    'success' => false,
                    'message' => 'API request failed: ' . $error_message,
                    'indexed_count' => 0,
                    'total_count' => 0
                ];
            }
            
            $status_code = wp_remote_retrieve_response_code($response);
            $body = wp_remote_retrieve_body($response);
            $data = json_decode($body, true);
            
            
            if ($status_code >= 200 && $status_code < 300) {
                $message = isset($data['message']) ? $data['message'] : 'Content reindexed successfully';
                $documents_indexed = isset($data['documents_indexed']) ? $data['documents_indexed'] : 0;
                $processing_time = isset($data['processing_time']) ? $data['processing_time'] : 0;
                
                return [
                    'success' => true,
                    'message' => $message,
                    'indexed_count' => $documents_indexed,
                    'total_count' => $documents_indexed,
                    'processing_time' => $processing_time,
                    'api_response' => $data
                ];
            } else {
                $error_message = isset($data['message']) ? $data['message'] : 'API returned error status ' . $status_code;
                
                return [
                    'success' => false,
                    'message' => 'Railway API error: ' . $error_message,
                    'indexed_count' => 0,
                    'total_count' => 0,
                    'status_code' => $status_code
                ];
            }
            
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'Reindexing failed: ' . $e->getMessage(),
                'indexed_count' => 0,
                'total_count' => 0
            ];
        }
    }
    
    /**
     * Sanitize analytics data
     * 
     * @param array $data
     * @return array
     * @since 2.0.0
     */
    private function sanitizeAnalyticsData($data) {
        // Handle timestamp conversion from ISO string to MySQL format if needed
        $timestamp = $data['timestamp'] ?? current_time('mysql');
        if (strpos($timestamp, 'T') !== false) {
            // Convert ISO 8601 to MySQL datetime
            $date = new \DateTime($timestamp);
            $timestamp = $date->format('Y-m-d H:i:s');
        }
        
        return [
            'query' => sanitize_text_field($data['query'] ?? ''),
            'result_count' => (int) ($data['result_count'] ?? 0),
            'time_taken' => (float) ($data['time_taken'] ?? 0),
            'has_results' => (bool) ($data['has_results'] ?? false),
            'user_agent' => sanitize_text_field($data['user_agent'] ?? ''),
            'language' => sanitize_text_field($data['language'] ?? ''),
            'screen_resolution' => sanitize_text_field($data['screen_resolution'] ?? ''),
            'viewport_size' => sanitize_text_field($data['viewport_size'] ?? ''),
            'referrer' => esc_url_raw($data['referrer'] ?? ''),
            'session_id' => sanitize_text_field($data['session_id'] ?? ''),
            'user_id' => (int) ($data['user_id'] ?? 0),
            'device_type' => sanitize_text_field($data['device_type'] ?? ''),
            'browser_name' => sanitize_text_field($data['browser_name'] ?? ''),
            'browser_version' => sanitize_text_field($data['browser_version'] ?? ''),
            'search_method' => sanitize_text_field($data['search_method'] ?? 'ajax'),
            'filters' => sanitize_text_field($data['filters'] ?? ''),
            'sort_method' => sanitize_text_field($data['sort_method'] ?? 'relevance'),
            'timestamp' => $timestamp,
            'results' => is_array($data['results']) ? $data['results'] : [],
        ];
    }
    
    /**
     * Sanitize CTR data
     * 
     * @param array $data
     * @return array
     * @since 2.0.0
     */
    private function sanitizeCTRData($data) {
        return [
            'search_id' => (int) ($data['search_id'] ?? 0),
            'result_id' => sanitize_text_field($data['result_id'] ?? ''),
            'result_title' => sanitize_text_field($data['result_title'] ?? ''),
            'result_url' => esc_url_raw($data['result_url'] ?? ''),
            'result_position' => (int) ($data['result_position'] ?? 0),
            'result_score' => (float) ($data['result_score'] ?? 0),
            'session_id' => sanitize_text_field($data['session_id'] ?? ''),
            'user_id' => (int) ($data['user_id'] ?? 0),
            'query' => sanitize_text_field($data['query'] ?? ''),
        ];
    }
    
    /**
     * Track analytics asynchronously (non-blocking)
     * 
     * @param string $query Search query
     * @param array $results Search results
     * @param array $metadata Search metadata
     * @since 2.17.4
     */
    private function trackAnalyticsAsync($query, $results, $metadata) {
        // Process analytics immediately instead of queuing to ensure data is saved
        // This is non-blocking as it's called after the response is sent
        try {
            // Add time_taken if not present
            if (!isset($metadata['time_taken']) && isset($metadata['response_time'])) {
                $metadata['time_taken'] = $metadata['response_time'];
            }
            
            // Track analytics directly
            $this->analytics_service->trackSearch($query, $results, $metadata);
        } catch (\Exception $e) {
            // Silently fail analytics tracking to not break search
            error_log('Analytics tracking failed: ' . $e->getMessage());
        }
    }
    
    /**
     * Process analytics queue
     * 
     * @since 2.17.4
     */
    private function processAnalyticsQueue() {
        $queue_key = 'hybrid_search_analytics_queue';
        $queue = get_transient($queue_key) ?: [];
        
        if (empty($queue)) {
            return;
        }
        
        // Process up to 10 items at a time to avoid timeout
        $to_process = array_slice($queue, 0, 10);
        $remaining = array_slice($queue, 10);
        
        foreach ($to_process as $item) {
            try {
                $this->analytics_service->trackSearch(
                    $item['query'],
                    $item['results'],
                    $item['metadata']
                );
            } catch (\Exception $e) {
                // Silently fail analytics tracking to not break search
                error_log('Analytics tracking failed: ' . $e->getMessage());
            }
        }
        
        // Update queue with remaining items
        if (!empty($remaining)) {
            set_transient($queue_key, $remaining, 3600);
        } else {
            delete_transient($queue_key);
        }
    }
    
    /**
     * Handle clear cache request
     * 
     * @return array Result
     * @since 2.8.1
     */
    public function handleClearCache() {
        global $wpdb;
        
        try {
            
            // Clear all hybrid search transients
            $wpdb->query(
                "DELETE FROM {$wpdb->options} 
                 WHERE option_name LIKE '_transient_hybrid_search_%' 
                 OR option_name LIKE '_transient_timeout_hybrid_search_%'"
            );
            
            $deleted = $wpdb->rows_affected;
            
            // Reset cache stats
            update_option('hybrid_search_cache_hits', 0, false);
            update_option('hybrid_search_cache_misses', 0, false);
            
            
            return [
                'success' => true,
                'message' => 'Search cache cleared successfully! Deleted ' . $deleted . ' cached items.',
                'deleted_count' => $deleted
            ];
            
        } catch (\Exception $e) {
            return [
                'success' => false,
                'message' => 'Failed to clear cache: ' . $e->getMessage()
            ];
        }
    }
}
