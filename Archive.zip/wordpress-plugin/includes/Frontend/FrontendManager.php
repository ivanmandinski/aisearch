<?php
/**
 * Frontend Manager
 * 
 * Handles frontend functionality including search form rendering and asset management.
 * 
 * @package HybridSearch\Frontend
 * @since 2.0.0
 */

namespace HybridSearch\Frontend;

use HybridSearch\API\SearchAPI;

class FrontendManager {
    
    /**
     * Search API
     * 
     * @var SearchAPI
     */
    private $search_api;
    
    /**
     * Constructor
     * 
     * @param SearchAPI $search_api
     */
    public function __construct(SearchAPI $search_api) {
        $this->search_api = $search_api;
    }
    
    /**
     * Register WordPress hooks
     * 
     * @since 2.0.0
     */
    public function registerHooks() {
        add_action('wp_enqueue_scripts', [$this, 'enqueueAssets']);
        add_action('wp_footer', [$this, 'addInlineScripts']);
        add_filter('get_search_form', [$this, 'customSearchForm']);
        add_shortcode('hybrid_search_form', [$this, 'searchFormShortcode']);
        
        // Intercept search requests when hybrid search is enabled
        add_action('template_redirect', [$this, 'interceptSearchRequest']);
        add_filter('posts_results', [$this, 'replaceSearchResults'], 10, 2);
        
        // More aggressive form replacement
        add_action('wp_head', [$this, 'injectSearchFormCSS']);
        add_action('wp_footer', [$this, 'injectSearchFormJS']);
    }
    
    /**
     * Enqueue frontend assets
     * 
     * @since 2.0.0
     */
    public function enqueueAssets() {
        // Only load on pages that might have search
        if (!$this->shouldLoadAssets()) {
            return;
        }
        
        // Enqueue consolidated CSS
        wp_enqueue_style(
            'hybrid-search-consolidated',
            HYBRID_SEARCH_PLUGIN_URL . 'assets/hybrid-search-consolidated.css',
            [],
            HYBRID_SEARCH_VERSION
        );
        
        // Enqueue consolidated JavaScript
        wp_enqueue_script(
            'hybrid-search-consolidated',
            HYBRID_SEARCH_PLUGIN_URL . 'assets/hybrid-search-consolidated.js',
            ['jquery'],
            HYBRID_SEARCH_VERSION,
            true
        );
        
        // Pass configuration to JavaScript
        wp_localize_script('hybrid-search-consolidated', 'hybridSearch', array(
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'apiUrl' => get_option('hybrid_search_api_url', ''),
            'maxResults' => (int) get_option('hybrid_search_max_results', 10),
            'includeAnswer' => (bool) get_option('hybrid_search_include_answer', false),
            'aiInstructions' => get_option('hybrid_search_ai_instructions', ''),
            'nonce' => wp_create_nonce('hybrid_search_nonce'),
            'enableVoiceSearch' => true,
            'enableKeyboardShortcuts' => true,
            'isAdmin' => (bool) current_user_can('manage_options'),
            'showRankingTooltips' => (bool) current_user_can('manage_options')
        ));
    }
    
    /**
     * Add inline scripts
     * 
     * @since 2.0.0
     */
    public function addInlineScripts() {
        if (!$this->shouldLoadAssets()) {
            return;
        }
        
        ?>
        <!-- Inline JavaScript has been moved to hybrid-search-consolidated.js -->
        <?php
    }
    
    /**
     * Custom search form
     * 
     * @param string $form Original search form
     * @return string Modified search form
     * @since 2.0.0
     */
    public function customSearchForm($form) {
        // Always return custom form for now - we'll handle enabling/disabling in the search logic
        return $this->renderSearchForm();
    }
    
    /**
     * Search form shortcode
     * 
     * @param array $atts Shortcode attributes
     * @return string Search form HTML
     * @since 2.0.0
     */
    public function searchFormShortcode($atts) {
        $atts = shortcode_atts([
            'placeholder' => 'Search...',
            'button_text' => 'Search',
            'show_clear' => 'true',
            'class' => '',
        ], $atts);
        
        return $this->renderSearchForm($atts);
    }
    
    /**
     * Render search form
     * 
     * @param array $options Form options
     * @return string Search form HTML
     * @since 2.0.0
     */
    public function renderSearchForm($options = []) {
        $defaults = [
            'placeholder' => 'Search...',
            'button_text' => 'Search',
            'show_clear' => true,
            'class' => '',
        ];
        
        $options = wp_parse_args($options, $defaults);
        
        ob_start();
        ?>
        <div class="hybrid-search-container <?php echo esc_attr($options['class']); ?>">
            <form class="hybrid-search-form" method="get" role="search" aria-label="Site Search" action="<?php echo esc_url(home_url('/')); ?>">
                <?php
                // Get search query from multiple sources
                $search_value = '';
                if (isset($_GET['s']) && !empty($_GET['s'])) {
                    $search_value = sanitize_text_field($_GET['s']);
                } elseif (isset($_GET['query']) && !empty($_GET['query'])) {
                    $search_value = sanitize_text_field($_GET['query']);
                } elseif (get_search_query()) {
                    $search_value = get_search_query();
                }
                ?>
                <input type="text" 
                       id="hybrid-search-input"
                       name="s" 
                       class="hybrid-search-input" 
                       placeholder="<?php echo esc_attr($options['placeholder']); ?>"
                       value="<?php echo esc_attr($search_value); ?>"
                       autocomplete="off"
                       spellcheck="false">
                
                <?php if ($options['show_clear']): ?>
                    <button type="button" class="hybrid-search-clear" aria-label="Clear search">×</button>
                <?php endif; ?>
                
                <button type="submit" class="hybrid-search-button hybrid-search-button--search">
                    <?php echo esc_html($options['button_text']); ?>
                </button>
                
                <input type="hidden" name="hybrid_search" value="1">
            </form>
            
            <div class="hybrid-search-suggestions" id="hybrid-search-suggestions" aria-live="polite"></div>
            
            <!-- Search Filters -->
            <div class="hybrid-search-filters open" aria-expanded="true">
                <div class="hybrid-search-filters-header">
                    <div class="hybrid-search-filters-title">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <line x1="4" y1="6" x2="20" y2="6"></line>
                            <line x1="8" y1="12" x2="16" y2="12"></line>
                            <line x1="10" y1="18" x2="14" y2="18"></line>
                        </svg>
                        <span>Filters</span>
                    </div>
                    <button type="button" class="hybrid-search-filters-toggle" aria-expanded="true" onclick="toggleSearchFilters()">
                        Hide Filters
                    </button>
                </div>
                
                <div class="hybrid-search-filters-content" id="hybrid-search-filters-content">
                    <div class="hybrid-search-filter-group">
                        <label class="hybrid-search-filter-label">Date Range</label>
                        <select class="hybrid-search-filter-select" id="filter-date">
                            <option value="">Any Time</option>
                            <option value="day">Last 24 Hours</option>
                            <option value="week">Last Week</option>
                            <option value="month">Last Month</option>
                            <option value="year">Last Year</option>
                        </select>
                    </div>
                    
                    <div class="hybrid-search-filter-group">
                        <label class="hybrid-search-filter-label">Sort By</label>
                        <select class="hybrid-search-filter-select" id="filter-sort">
                            <option value="relevance">Relevance</option>
                            <option value="date-desc">Newest First</option>
                            <option value="date-asc">Oldest First</option>
                            <option value="title-asc">Title A-Z</option>
                        </select>
                    </div>
                    
                    <div class="hybrid-search-filter-group">
                        <label class="hybrid-search-filter-label">Results Per Page</label>
                        <select class="hybrid-search-filter-select" id="filter-limit">
                            <option value="10">10 Results</option>
                            <option value="25">25 Results</option>
                            <option value="50">50 Results</option>
                        </select>
                    </div>
                    
                    <div class="hybrid-search-filters-actions">
                        <button type="button" class="hybrid-search-filter-apply" onclick="applySearchFilters()">
                            Apply Filters
                        </button>
                        <button type="button" class="hybrid-search-filter-reset" onclick="resetSearchFilters()">
                            Reset All
                        </button>
                    </div>
                    
                    <div class="hybrid-search-active-filters" id="active-filters"></div>
                </div>
            </div>
            
            <div class="hybrid-search-results"></div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Check if assets should be loaded
     * 
     * @return bool True if assets should be loaded
     * @since 2.0.0
     */
    private function shouldLoadAssets() {
        // Don't load if hybrid search is disabled
        if (!get_option('hybrid_search_enabled', false)) {
            return false;
        }
        
        // Load on search pages
        if (is_search()) {
            return true;
        }
        
        // Load on home page
        if (is_home() || is_front_page()) {
            return true;
        }
        
        // Load on pages with any hybrid search shortcode
        global $post;
        if ($post && (
            has_shortcode($post->post_content, 'hybrid_search') ||
            has_shortcode($post->post_content, 'hybrid_search_form') ||
            has_shortcode($post->post_content, 'hybrid_search_results')
        )) {
            return true;
        }
        
        // Load on pages with search form in sidebar/widgets
        if (is_active_sidebar('sidebar-1') || is_active_sidebar('sidebar-2')) {
            return true;
        }
        
        // Load by default for maximum compatibility
        return true;
    }
    
    /**
     * Check if custom form should be used
     * 
     * @return bool True if custom form should be used
     * @since 2.0.0
     */
    private function shouldUseCustomForm() {
        // Don't replace forms in admin or other specific contexts
        if (is_admin() || is_feed() || is_trackback()) {
            return false;
        }
        
        // Replace form on all frontend pages when plugin is enabled
        return apply_filters('hybrid_search_use_custom_form', true);
    }
    
    /**
     * Get search results template
     * 
     * @param array $results Search results
     * @return string Results HTML
     * @since 2.0.0
     */
    public function renderSearchResults($results, $ai_answer = null, $query = '') {
        if (empty($results)) {
            return $this->renderNoResults();
        }
        
        ob_start();
        ?>
        <div class="hybrid-search-results">
            <?php if (!empty($ai_answer) && get_option('hybrid_search_show_ai_answer', false)): ?>
                <?php echo $this->renderAIAnswer($ai_answer); ?>
            <?php endif; ?>
            
            <div class="hybrid-search-results-header">
                <div class="hybrid-search-results-count">
                    Found <?php echo count($results); ?> result<?php echo count($results) !== 1 ? 's' : ''; ?>
                </div>
            </div>
            
            <div class="hybrid-search-results-list">
                <?php foreach ($results as $index => $result): ?>
                    <?php echo $this->renderSearchResult($result, $index + 1); ?>
                <?php endforeach; ?>
            </div>
            
            <?php echo $this->renderExpertCTA($query); ?>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Check if "Talk to an Expert?" CTA should be shown
     * 
     * @param string $query Search query
     * @return bool True if CTA should be shown
     * @since 2.18.0
     */
    private function shouldShowExpertCTA($query) {
        if (empty($query)) {
            return false;
        }
        
        $query_lower = strtolower(trim($query));
        
        // Person name queries (typically 2-3 words, capitalized names)
        if (preg_match('/^[A-Z][a-z]+ [A-Z][a-z]+/', $query)) {
            $words = explode(' ', trim($query));
            if (count($words) >= 2 && count($words) <= 3) {
                $all_capitalized = true;
                foreach ($words as $word) {
                    if (!preg_match('/^[A-Z][a-z]+$/', trim($word))) {
                        $all_capitalized = false;
                        break;
                    }
                }
                if ($all_capitalized) {
                    return true;
                }
            }
        }
        
        // Service queries
        $service_keywords = ['service', 'services', 'consulting', 'consultant', 'management', 'solution', 'solutions', 'support', 'help', 'assistance', 'expertise'];
        foreach ($service_keywords as $keyword) {
            if (strpos($query_lower, $keyword) !== false) {
                return true;
            }
        }
        
        // Sector/industry queries
        $sector_keywords = ['environmental', 'waste', 'remediation', 'compliance', 'sustainability', 'engineering', 'sector', 'industry', 'field'];
        foreach ($sector_keywords as $keyword) {
            if (strpos($query_lower, $keyword) !== false) {
                return true;
            }
        }
        
        return false;
    }
    
    /**
     * Render "Talk to an Expert?" CTA
     * 
     * @param string $query Search query
     * @return string CTA HTML
     * @since 2.18.0
     */
    private function renderExpertCTA($query) {
        $query_text = trim((string) $query);
        $has_query = $query_text !== '';
        ob_start();
        ?>
        <div class="hybrid-search-expert-cta">
            <div class="hybrid-search-expert-cta-content">
                <h3 class="hybrid-search-expert-cta-title">Need More Help?</h3>
                <p class="hybrid-search-expert-cta-text">
                    <?php if ($has_query): ?>
                        Our experts are ready to assist you with <?php echo esc_html($query_text); ?>. Get personalized guidance and answers to your specific questions.
                    <?php else: ?>
                        Our experts are ready to assist you. Get personalized guidance and answers tailored to your needs.
                    <?php endif; ?>
                </p>
                <a href="/contact/" class="hybrid-search-expert-cta-button">
                    Talk to an Expert
                </a>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render AI answer
     * 
     * @param string $ai_answer AI generated answer
     * @return string AI answer HTML
     * @since 2.2.1
     */
    public function renderAIAnswer($ai_answer) {
        if (empty($ai_answer)) {
            return '';
        }
        
        $sanitized_answer = wp_kses_post($ai_answer);
        $plain_text = wp_strip_all_tags($sanitized_answer);
        $preview_length = (int) apply_filters('hybrid_search_ai_answer_preview_length', 400);
        if ($preview_length < 100) {
            $preview_length = 100;
        }
        
        $needs_truncation = strlen($plain_text) > $preview_length;
        $preview = $sanitized_answer;
        if ($needs_truncation) {
            $preview = wp_html_excerpt($sanitized_answer, $preview_length, '&hellip;');
        }
        
        $answer_id = 'hybrid-search-ai-answer-' . uniqid();
        $title_id = $answer_id . '-title';
        $full_encoded = rawurlencode($sanitized_answer);
        $preview_encoded = $needs_truncation ? rawurlencode($preview) : '';
        
        ob_start();
        ?>
        <section class="hybrid-search-ai-answer" role="region" aria-live="polite" aria-labelledby="<?php echo esc_attr($title_id); ?>">
            <header class="hybrid-search-ai-answer-header">
                <h3 id="<?php echo esc_attr($title_id); ?>" class="hybrid-search-ai-answer-title">
                    <span class="hybrid-search-ai-answer-icon">🤖</span>
                    <span><?php esc_html_e('AI Answer', 'hybrid-search'); ?></span>
                </h3>
            </header>
            <div id="<?php echo esc_attr($answer_id); ?>"
                 class="hybrid-search-ai-answer-content<?php echo $needs_truncation ? ' collapsed' : ''; ?>"
                 <?php if ($needs_truncation): ?>
                     data-full="<?php echo esc_attr($full_encoded); ?>"
                     data-preview="<?php echo esc_attr($preview_encoded); ?>"
                 <?php endif; ?>>
                <div class="hybrid-search-ai-answer-body" aria-live="polite"><?php echo wp_kses_post($needs_truncation ? $preview : $sanitized_answer); ?></div>
            </div>
            
            <?php if ($needs_truncation): ?>
            <footer class="hybrid-search-ai-answer-footer">
                <button type="button"
                        class="hybrid-search-ai-answer-toggle"
                        onclick="toggleAIAnswer(this)"
                        aria-expanded="false"
                        aria-controls="<?php echo esc_attr($answer_id); ?>">
                    <span><?php esc_html_e('Show more', 'hybrid-search'); ?></span>
                    <span class="hybrid-search-ai-answer-toggle-icon">▼</span>
                </button>
            </footer>
            <?php endif; ?>
        </section>
        <?php
        return ob_get_clean();
    }

    /**
     * Render single search result
     * 
     * @param array $result Search result data
     * @param int $position Result position
     * @return string Result HTML
     * @since 2.0.0
     */
    public function renderSearchResult($result, $position = 1) {
        ob_start();
        ?>
        <article class="hybrid-search-result" data-result-id="<?php echo esc_attr($result['id']); ?>" data-position="<?php echo esc_attr($position); ?>">
            <h3 class="hybrid-search-result-title">
                <a href="<?php echo esc_url($result['url']); ?>" 
                   data-result-id="<?php echo esc_attr($result['id']); ?>"
                   data-title="<?php echo esc_attr($result['title']); ?>"
                   data-url="<?php echo esc_url($result['url']); ?>"
                   data-position="<?php echo esc_attr($position); ?>"
                   data-score="<?php echo esc_attr($result['score'] ?? 0); ?>">
                    <?php echo esc_html($result['title']); ?>
                </a>
            </h3>
            
            <?php if (!empty($result['excerpt'])): ?>
                <div class="hybrid-search-result-excerpt">
                    <?php echo esc_html($this->cleanExcerptText($result['excerpt'])); ?>
                </div>
            <?php endif; ?>
            
            <div class="hybrid-search-result-meta">
                <?php
                // Priority 1: Primary Category
                if (!empty($result['categories']) && is_array($result['categories'])) {
                    $primary_category = reset($result['categories']);
                    ?>
                    <span class="meta-category">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <path d="M20.59 13.41l-7.17 7.17a2 2 0 0 1-2.83 0L2 12V2h10l8.59 8.59a2 2 0 0 1 0 2.82z"></path>
                            <line x1="7" y1="7" x2="7.01" y2="7"></line>
                        </svg>
                        <?php echo esc_html($primary_category); ?>
                    </span>
                    <?php
                }
                
                // Priority 1: Last Updated
                $modified_date = !empty($result['modified']) ? $result['modified'] : $result['date'];
                if ($modified_date) {
                    $modified_timestamp = strtotime($modified_date);
                    $days_ago = floor((time() - $modified_timestamp) / (60 * 60 * 24));
                    
                    if ($days_ago < 7) {
                        $updated_text = $days_ago == 0 ? 'Today' : ($days_ago == 1 ? 'Yesterday' : $days_ago . ' days ago');
                    } elseif ($days_ago < 30) {
                        $weeks_ago = floor($days_ago / 7);
                        $updated_text = $weeks_ago == 1 ? '1 week ago' : $weeks_ago . ' weeks ago';
                    } else {
                        $updated_text = date('M Y', $modified_timestamp);
                    }
                    ?>
                    <span class="meta-updated">
                        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                            <circle cx="12" cy="12" r="10"></circle>
                            <polyline points="12 6 12 12 16 14"></polyline>
                        </svg>
                        Updated <?php echo esc_html($updated_text); ?>
                    </span>
                    <?php
                }
                ?>
            </div>
            
            <?php
            // Contact button for SCS Professionals
            // Check multiple variations of the post type
            $post_type = strtolower($result['type'] ?? '');
            $is_professional = in_array($post_type, [
                'scs-professional', 
                'scs_professional',
                'professional',
                'scs-professionals',
                'scs_professionals',
                'team',
                'staff'
            ]);
            
            error_log('Hybrid Search: Checking contact button - Type: "' . $post_type . '", Is Professional? ' . ($is_professional ? 'YES' : 'NO'));
            
            if ($is_professional) {
                $staff_id = !empty($result['staff_id']) ? $result['staff_id'] : '505748';
                $contact_name = !empty($result['title']) ? $result['title'] : 'Expert';
                error_log('Hybrid Search: Showing contact button for: ' . $contact_name . ' (staff_id: ' . $staff_id . ')');
                ?>
                <div class="hybrid-search-result-actions">
                    <a href="#" class="contact-popup btninfo" data-staffid="<?php echo esc_attr($staff_id); ?>">
                        Contact <?php echo esc_html($contact_name); ?>
                    </a>
                </div>
                <?php
            }
            ?>
        </article>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Render no results message
     * 
     * @return string No results HTML
     * @since 2.0.0
     */
    public function renderNoResults() {
        ob_start();
        ?>
        <div class="hybrid-search-empty">
            <div class="hybrid-search-empty-icon">🔍</div>
            <h3 class="hybrid-search-empty-title">No results found</h3>
            <p class="hybrid-search-empty-description">
                Try adjusting your search terms or check the spelling.
            </p>
        </div>
        <?php
        return ob_get_clean();
    }
    
    /**
     * Inject search form CSS (moved to consolidated CSS file)
     * 
     * @since 2.1.2
     */
    public function injectSearchFormCSS() {
        // CSS has been moved to hybrid-search-consolidated.css
        // This function is kept for compatibility but no longer injects inline CSS
    }
    
    /**
     * Inject search form JavaScript
     * 
     * @since 2.1.2
     */
    public function injectSearchFormJS() {
        // All JavaScript functionality has been moved to hybrid-search-consolidated.js
        // This function is kept for compatibility but no longer injects inline JavaScript
    }
    
    /**
     * Intercept search requests
     * 
     * @since 2.1.0
     */
    public function interceptSearchRequest() {
        // Intercept all search requests for now - we'll check API URL in the search method
        if (!is_search()) {
            return;
        }
        
        $search_query = get_search_query();
        if (empty($search_query)) {
            return;
        }
        
        // Store the search query for later use
        global $hybrid_search_query;
        $hybrid_search_query = $search_query;
        
        // Add action to replace search results
        add_filter('the_posts', [$this, 'replaceSearchResultsWithHybrid'], 10, 2);
    }
    
    /**
     * Replace search results with hybrid search results
     * 
     * @param array $posts Original posts
     * @param WP_Query $query WordPress query object
     * @return array Modified posts
     * @since 2.1.0
     */
    public function replaceSearchResultsWithHybrid($posts, $query) {
        // Only replace search query results
        if (!$query->is_search()) {
            return $posts;
        }
        
        global $hybrid_search_query;
        if (empty($hybrid_search_query)) {
            return $posts;
        }
        
        // Check if API URL is configured
        $api_url = get_option('hybrid_search_api_url', '');
        if (empty($api_url)) {
            error_log('Hybrid Search: API URL not configured');
            return $posts; // Return original posts if no API URL
        }
        
        error_log('Hybrid Search: Performing search for: ' . $hybrid_search_query . ' with API URL: ' . $api_url);
        
        // Perform hybrid search
        // Only request AI answer if we're going to show it
        $show_ai_answer = get_option('hybrid_search_show_ai_answer', false);
        $search_result = $this->search_api->search($hybrid_search_query, [
            'limit' => get_option('hybrid_search_max_results', 10),
            'include_answer' => $show_ai_answer, // Use show_ai_answer setting for API request
        ]);
        
        error_log('Hybrid Search: Search result: ' . json_encode($search_result));
        
        // Store results globally for JavaScript to display
        global $hybrid_search_results;
        $hybrid_search_results = $search_result;
        
        if (!$search_result['success'] || empty($search_result['results'])) {
            // Return empty results if hybrid search fails
            return [];
        }
        
        // Add a hook to inject results into the page content
        add_action('wp_footer', function() use ($search_result) {
            ?>
            <script type="text/javascript">
            document.addEventListener('DOMContentLoaded', function() {
                // Replace the default search results with hybrid search results
                const defaultResults = document.querySelector('.search-results, .page-content, .entry-content, .content-area');
                if (defaultResults && window.hybridSearchResults) {
                    defaultResults.innerHTML = window.hybridSearchResults;
                }
            });
            </script>
            <?php
        });
        
        // Store results for JavaScript
        global $hybrid_search_results_html;
        $ai_answer = $search_result['metadata']['answer'] ?? '';
        $hybrid_search_results_html = $this->renderSearchResults($search_result['results'], $ai_answer, $hybrid_search_query);
        
        // Convert hybrid search results to WordPress post format
        $hybrid_posts = $this->convertResultsToPosts($search_result['results']);
        
        // Update the query to reflect the new results
        $query->found_posts = count($hybrid_posts);
        $query->max_num_pages = 1;
        
        return $hybrid_posts;
    }
    
    /**
     * Clean excerpt text by removing unwanted content
     * 
     * @param string $excerpt Raw excerpt text
     * @return string Cleaned excerpt text
     * @since 2.2.0
     */
    private function cleanExcerptText($excerpt) {
        if (empty($excerpt)) {
            return '';
        }
        
        // Remove HTML tags
        $clean_text = strip_tags($excerpt);
        
        // Remove "Continue reading" and everything after it
        $clean_text = preg_replace('/\s*Continue reading.*$/i', '', $clean_text);
        
        // Remove text after dots (...) but keep the dots
        $clean_text = preg_replace('/\s*\.{3,}\s*.*$/g', '...', $clean_text);
        
        // Remove any remaining trailing dots if they're at the end
        $clean_text = preg_replace('/\.{3,}\s*$/', '...', $clean_text);
        
        // Clean up extra whitespace
        $clean_text = preg_replace('/\s+/', ' ', $clean_text);
        $clean_text = trim($clean_text);
        
        // Ensure it ends with proper punctuation
        if (!empty($clean_text) && !preg_match('/[.!?]$/', $clean_text)) {
            $clean_text .= '...';
        }
        
        return $clean_text;
    }

    /**
     * Convert hybrid search results to WordPress post objects
     * 
     * @param array $results Hybrid search results
     * @return array WordPress post objects
     * @since 2.1.0
     */
    private function convertResultsToPosts($results) {
        $posts = [];
        
        foreach ($results as $result) {
            // Create a fake post object
            $post = new \stdClass();
            $post->ID = $result['id'] ?? 0;
            $post->post_title = $result['title'] ?? '';
            $post->post_content = $result['excerpt'] ?? '';
            $post->post_excerpt = $result['excerpt'] ?? '';
            $post->post_type = $result['type'] ?? 'post';
            $post->post_status = 'publish';
            $post->post_date = $result['date'] ?? current_time('mysql');
            $post->post_author = 1;
            $post->post_name = sanitize_title($result['title'] ?? '');
            $post->post_parent = 0;
            $post->menu_order = 0;
            $post->post_mime_type = '';
            $post->comment_count = 0;
            $post->filter = 'raw';
            
            // Add custom fields
            $post->hybrid_search_score = $result['score'] ?? 0;
            $post->hybrid_search_url = $result['url'] ?? '';
            $post->hybrid_search_type = $result['type'] ?? 'post';
            
            // Make it behave like a post
            $post->post_type = 'hybrid_search_result';
            $post->is_search_result = true;
            
            $posts[] = $post;
        }
        
        return $posts;
    }
    
    /**
     * Replace search results (alternative method)
     * 
     * @param array $posts Original posts
     * @param WP_Query $query WordPress query object
     * @return array Modified posts
     * @since 2.1.0
     */
    public function replaceSearchResults($posts, $query) {
        // This is a fallback method - the main logic is in replaceSearchResultsWithHybrid
        return $posts;
    }
}
