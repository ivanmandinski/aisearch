/**
 * Hybrid Search Analytics Dashboard - Modern JavaScript
 * Interactive dashboard with real-time updates, charts, and advanced features
 * Version: 2.26.0
 */

(function($) {
    'use strict';

    class AnalyticsDashboard {
    constructor() {
        this.ajaxUrl = hybridSearchAnalytics.ajaxUrl;
        this.nonce = hybridSearchAnalytics.nonce;
        this.strings = hybridSearchAnalytics.strings;
        this.settings = {
            autoRefresh: true,
            refreshInterval: 30000
        };

            // State management
            this.currentFilters = {};
            this.currentPage = 1;
            this.currentSort = { by: 'timestamp', order: 'desc' };
            this.autoRefreshTimer = null;
            this.isLoading = false;
            this.charts = {};

            // DOM elements cache
            this.elements = {};

            this.init();
        }

        init() {
            this.cacheElements();
            this.bindEvents();
            this.initializeCharts();
            this.loadDashboardData();

            // Start auto-refresh if enabled
            if (this.settings.autoRefresh) {
                this.startAutoRefresh();
            }

            // Update status indicator
            this.updateConnectionStatus(true);

            // Initialize date picker toggle
            this.handleDateRangeToggle();
        }

        cacheElements() {
            this.elements = {
                // Header elements
                dashboardTitle: $('.hs-dashboard-title'),
                exportAnalyticsBtn: $('#export-analytics-btn'),
                clearAnalyticsBtn: $('#clear-analytics-btn'),

                // Filter elements
                dateRange: $('#date-range'),
                dateFrom: $('#date-from'),
                dateTo: $('#date-to'),
                searchQueryFilter: $('#search-query-filter'),
                deviceFilter: $('#device-filter'),
                customDateRange: $('.custom-date-range'),

                // Refresh controls
                autoRefreshAnalytics: $('#auto-refresh-analytics'),
                refreshInterval: $('#refresh-interval'),
                refreshNowBtn: $('#refresh-now-btn'),
                lastRefreshTime: $('#last-refresh-time'),

                // Loading/Error states
                analyticsLoading: $('#analytics-loading'),
                analyticsError: $('#analytics-error'),
                analyticsErrorMessage: $('#analytics-error-message'),
                analyticsDashboardContent: $('#analytics-dashboard-content'),

                // Stats elements
                totalSearches: $('#total-searches'),
                avgResponseTime: $('#avg-response-time'),
                successRate: $('#success-rate'),
                uniqueUsers: $('#unique-users'),

                // Charts
                searchVolumeChart: $('#search-volume-chart'),
                deviceChart: $('#device-chart'),

                // Table
                analyticsTable: $('.analytics-table')
            };
        }

        bindEvents() {
            // Date range events
            this.elements.dateRange.on('change', this.handleDateRangeChange.bind(this));
            this.elements.dateFrom.on('change', this.handleDateChange.bind(this));
            this.elements.dateTo.on('change', this.handleDateChange.bind(this));

            // Filter events
            this.elements.searchQueryFilter.on('input', this.handleFilterChange.bind(this));
            this.elements.deviceFilter.on('change', this.handleFilterChange.bind(this));

            // Export events
            this.elements.exportAnalyticsBtn.on('click', this.handleExport.bind(this));
            this.elements.clearAnalyticsBtn.on('click', this.handleClearAnalytics.bind(this));

            // Refresh events
            this.elements.autoRefreshAnalytics.on('change', this.handleAutoRefreshToggle.bind(this));
            this.elements.refreshNowBtn.on('click', this.handleManualRefresh.bind(this));

            // Chart events
            this.elements.chartToggles.on('click', this.handleChartToggle.bind(this));

            // Table events
            this.elements.searchInput.on('input', this.handleTableSearch.bind(this));
            this.elements.sortSelect.on('change', this.handleTableSort.bind(this));

            // Pagination events (delegated)
            this.elements.pagination.on('click', 'button:not(:disabled)', this.handlePagination.bind(this));

            // Window events
            $(window).on('beforeunload', this.cleanup.bind(this));
        }

        // ============================================================================
        // DATA LOADING
        // ============================================================================

        async loadDashboardData() {
            if (this.isLoading) return;

            try {
                this.isLoading = true;
                this.showLoadingState();

                const filters = this.getCurrentFilters();

                // For now, we'll use the existing analytics endpoint
                // In the future, this could be updated to use a dedicated dashboard endpoint
                const response = await this.makeAjaxRequest('hybrid_search_get_analytics', {
                    date_range: filters.date_range,
                    date_from: filters.date_from,
                    date_to: filters.date_to
                });

                if (response.success) {
                    this.updateStats(response.data);
                    this.updateCharts(response.data);
                    this.updateLastRefreshTime();
                    this.hideLoading();
                } else {
                    this.showError(response.data?.message || 'Failed to load analytics data');
                }

            } catch (error) {
                console.error('Dashboard data loading error:', error);
                this.showError('Failed to load analytics data');
            } finally {
                this.isLoading = false;
            }
        }

        async loadTableData() {
            try {
                const dateRange = this.getCurrentDateRange();
                const filters = this.getCurrentFilters();

                const response = await this.makeAjaxRequest('hybrid_search_analytics_data', {
                    date_range: dateRange.type,
                    date_from: dateRange.from,
                    date_to: dateRange.to,
                    filters: JSON.stringify(filters),
                    type: 'table',
                    page: this.currentPage,
                    sort_by: this.currentSort.by,
                    sort_order: this.currentSort.order,
                    search: this.elements.searchInput.val()
                });

                if (response.success) {
                    this.updateDataTable(response.data);
                    this.updatePagination(response.data.pagination);
                }

            } catch (error) {
                console.error('Table data loading error:', error);
                this.showTableError();
            }
        }

        async loadRealtimeData() {
            try {
                const dateRange = this.getCurrentDateRange();

                const response = await this.makeAjaxRequest('hybrid_search_realtime_analytics', {
                    date_range: dateRange.type,
                    date_from: dateRange.from,
                    date_to: dateRange.to
                });

                if (response.success && response.data) {
                    this.updateMetrics(response.data.metrics);
                    this.updateLastUpdated(response.data.last_updated);
                }

            } catch (error) {
                console.warn('Real-time data loading failed:', error);
            }
        }

        makeAjaxRequest(action, data = {}) {
            return new Promise((resolve, reject) => {
                $.ajax({
                    url: this.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: action,
                        nonce: this.nonce,
                        ...data
                    },
                    success: resolve,
                    error: (xhr, status, error) => {
                        reject(new Error(`${status}: ${error}`));
                    }
                });
            });
        }

        // ============================================================================
        // UI UPDATES
        // ============================================================================

        updateMetrics(metrics) {
            if (!metrics) return;

            const metricsHtml = this.generateMetricsHtml(metrics);
            this.elements.metricsGrid.html(metricsHtml);
        }

        updateCharts(charts) {
            if (!charts) return;

            // Default to volume chart
            this.renderVolumeChart(charts.search_volume || []);
        }

        updateInsights(insights) {
            if (!insights) return;

            const insightsHtml = this.generateInsightsHtml(insights);
            this.elements.insightsContainer.html(insightsHtml);
        }

        updateDataTable(data) {
            const tableHtml = this.generateTableHtml(data.records || []);
            this.elements.tableContainer.html(`
                <table class="hs-data-table">
                    <thead>
                        <tr>
                            <th>Query</th>
                            <th>Results</th>
                            <th>Response Time</th>
                            <th>Device</th>
                            <th>Browser</th>
                            <th>Date</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>${tableHtml}</tbody>
                </table>
            `);
        }

        updatePagination(pagination) {
            if (!pagination) return;

            const paginationHtml = this.generatePaginationHtml(pagination);
            this.elements.pagination.html(paginationHtml);
        }

        updateLastUpdated(timestamp = null) {
            const now = timestamp || new Date().toLocaleString();
            this.elements.lastUpdated.text(this.formatLastUpdated(now));
        }

        updateStats(data) {
            // Update the stats cards
            if (data.pagination) {
                this.elements.totalSearches.text(this.numberFormat(data.pagination.total_count || 0));
            }

            if (data.data && data.data.length > 0) {
                // Calculate average response time
                const times = data.data.map(item => parseFloat(item.time_taken || 0));
                const avgTime = times.length > 0 ? times.reduce((a, b) => a + b, 0) / times.length : 0;
                this.elements.avgResponseTime.text(this.numberFormat(avgTime, 2) + 's');

                // Calculate success rate
                const withResults = data.data.filter(item => item.has_results).length;
                const successRate = data.data.length > 0 ? (withResults / data.data.length) * 100 : 0;
                this.elements.successRate.text(this.numberFormat(successRate, 1) + '%');

                // Calculate unique users
                const uniqueUsers = [...new Set(data.data.map(item => item.user_id))].length;
                this.elements.uniqueUsers.text(this.numberFormat(uniqueUsers));
            } else {
                this.elements.avgResponseTime.text('0.00s');
                this.elements.successRate.text('0%');
                this.elements.uniqueUsers.text('0');
            }
        }

        updateCharts(data) {
            // Initialize Chart.js if available
            if (typeof Chart === 'undefined') {
                console.warn('Chart.js not loaded');
                return;
            }

            // Update search volume chart
            if (this.charts.searchVolumeChart) {
                this.charts.searchVolumeChart.destroy();
            }

            // Create search volume chart (simplified example)
            const ctx = this.elements.searchVolumeChart[0].getContext('2d');
            this.charts.searchVolumeChart = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: ['Day 1', 'Day 2', 'Day 3', 'Day 4', 'Day 5', 'Day 6', 'Day 7'],
                    datasets: [{
                        label: 'Searches',
                        data: [12, 19, 3, 5, 2, 3, 9],
                        borderColor: '#3b82f6',
                        backgroundColor: 'rgba(59, 130, 246, 0.1)',
                        tension: 0.4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            display: false
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true
                        }
                    }
                }
            });

            // Update device chart
            if (this.charts.deviceChart) {
                this.charts.deviceChart.destroy();
            }

            const deviceCtx = this.elements.deviceChart[0].getContext('2d');
            this.charts.deviceChart = new Chart(deviceCtx, {
                type: 'doughnut',
                data: {
                    labels: ['Desktop', 'Mobile', 'Tablet'],
                    datasets: [{
                        data: [65, 25, 10],
                        backgroundColor: ['#3b82f6', '#10b981', '#f59e0b'],
                        borderWidth: 0
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        }

        updateLastRefreshTime() {
            const now = new Date();
            const timeString = now.toLocaleTimeString();
            this.elements.lastRefreshTime.text(`Last refreshed: ${timeString}`);
        }

        numberFormat(number, decimals = 0) {
            return new Intl.NumberFormat().format(number);
        }

        updateConnectionStatus(connected) {
            const statusDot = this.elements.statusDot;
            const statusText = this.elements.statusText;

            if (connected) {
                statusDot.removeClass('disconnected').addClass('connected');
                statusText.text('Connected');
            } else {
                statusDot.removeClass('connected').addClass('disconnected');
                statusText.text('Disconnected');
            }
        }

        // ============================================================================
        // HTML GENERATION
        // ============================================================================

        generateMetricsHtml(metrics) {
            const metricCards = [
                {
                    key: 'total_searches',
                    label: 'Total Searches',
                    icon: 'dashicons-search',
                    value: metrics.total_searches || 0,
                    change: metrics.total_searches_change,
                    format: 'number'
                },
                {
                    key: 'successful_searches',
                    label: 'Successful Searches',
                    icon: 'dashicons-yes-alt',
                    value: metrics.successful_searches || 0,
                    change: metrics.successful_searches_change,
                    format: 'number'
                },
                {
                    key: 'zero_results',
                    label: 'Zero Results',
                    icon: 'dashicons-no-alt',
                    value: metrics.zero_results || 0,
                    change: metrics.zero_results_change,
                    format: 'number'
                },
                {
                    key: 'avg_response_time',
                    label: 'Avg Response Time',
                    icon: 'dashicons-clock',
                    value: metrics.avg_response_time || 0,
                    change: metrics.avg_response_time_change,
                    format: 'time'
                },
                {
                    key: 'ctr',
                    label: 'Click-Through Rate',
                    icon: 'dashicons-external',
                    value: metrics.ctr || 0,
                    change: metrics.ctr_change,
                    format: 'percentage'
                },
                {
                    key: 'unique_users',
                    label: 'Unique Users',
                    icon: 'dashicons-admin-users',
                    value: metrics.unique_users || 0,
                    change: metrics.unique_users_change,
                    format: 'number'
                }
            ];

            return metricCards.map(card => this.generateMetricCardHtml(card)).join('');
        }

        generateMetricCardHtml(card) {
            const formattedValue = this.formatMetricValue(card.value, card.format);
            const changeHtml = card.change ? this.generateChangeHtml(card.change) : '';

            return `
                <div class="hs-metric-card" data-metric="${card.key}">
                    <div class="hs-metric-icon">
                        <span class="dashicons ${card.icon}"></span>
                    </div>
                    <div class="hs-metric-value">${formattedValue}</div>
                    <div class="hs-metric-label">${card.label}</div>
                    ${changeHtml}
                </div>
            `;
        }

        generateChangeHtml(change) {
            const { value, type } = change;
            const formattedChange = this.formatChangeValue(value, type);
            const changeClass = value > 0 ? 'positive' : value < 0 ? 'negative' : 'neutral';
            const arrow = value > 0 ? '↗' : value < 0 ? '↘' : '→';

            return `<div class="hs-metric-change ${changeClass}">${arrow} ${formattedChange}</div>`;
        }

        generateInsightsHtml(insights) {
            if (!insights || insights.length === 0) {
                return `
                    <div class="hs-empty-state">
                        <div class="hs-empty-icon">
                            <span class="dashicons dashicons-lightbulb"></span>
                        </div>
                        <h3 class="hs-empty-title">No Insights Available</h3>
                        <p class="hs-empty-description">Collect more data to see performance insights and recommendations.</p>
                    </div>
                `;
            }

            return insights.map(insight => this.generateInsightCardHtml(insight)).join('');
        }

        generateInsightCardHtml(insight) {
            const type = insight.type || 'info';
            const icon = this.getInsightIcon(type);

            return `
                <div class="hs-insight-card ${type}">
                    <div class="hs-insight-icon">
                        <span class="dashicons ${icon}"></span>
                    </div>
                    <h4 class="hs-insight-title">${insight.title}</h4>
                    <p class="hs-insight-description">${insight.description}</p>
                </div>
            `;
        }

        generateTableHtml(records) {
            if (!records || records.length === 0) {
                return `
                    <tr>
                        <td colspan="7" class="hs-empty-table">
                            <div class="hs-empty-state">
                                <div class="hs-empty-icon">
                                    <span class="dashicons dashicons-search"></span>
                                </div>
                                <h3 class="hs-empty-title">No Search Data</h3>
                                <p class="hs-empty-description">No search queries found for the selected time period.</p>
                            </div>
                        </td>
                    </tr>
                `;
            }

            return records.map(record => this.generateTableRowHtml(record)).join('');
        }

        generateTableRowHtml(record) {
            const responseTimeClass = this.getResponseTimeClass(record.time_taken);
            const deviceBadgeClass = this.getDeviceBadgeClass(record.device_type);

            return `
                <tr>
                    <td><span class="hs-query-text" title="${this.escapeHtml(record.query)}">${this.escapeHtml(record.query)}</span></td>
                    <td><span class="hs-result-count">${record.result_count || 0}</span></td>
                    <td><span class="hs-response-time ${responseTimeClass}">${this.formatResponseTime(record.time_taken || 0)}</span></td>
                    <td><span class="hs-device-badge ${deviceBadgeClass}"><span class="dashicons ${this.getDeviceIcon(record.device_type)}"></span> ${record.device_type || 'unknown'}</span></td>
                    <td>${this.escapeHtml(record.browser_name || 'Unknown')}</td>
                    <td><span class="hs-timestamp">${this.formatTimestamp(record.timestamp)}</span></td>
                    <td>
                        <button type="button" class="hs-btn hs-btn-outline" onclick="viewQueryDetails('${this.escapeHtml(record.query)}')">
                            <span class="dashicons dashicons-visibility"></span>
                        </button>
                    </td>
                </tr>
            `;
        }

        generatePaginationHtml(pagination) {
            const { current_page, total_pages, has_next, has_prev, total_records } = pagination;

            if (total_pages <= 1) return '';

            let html = '<div class="hs-pagination-controls">';

            // Previous button
            html += `<button type="button" class="hs-pagination-btn" ${!has_prev ? 'disabled' : ''} data-page="${current_page - 1}">
                <span class="dashicons dashicons-arrow-left-alt"></span>
                Previous
            </button>`;

            // Page numbers
            const startPage = Math.max(1, current_page - 2);
            const endPage = Math.min(total_pages, current_page + 2);

            if (startPage > 1) {
                html += `<button type="button" class="hs-pagination-btn" data-page="1">1</button>`;
                if (startPage > 2) {
                    html += '<span class="hs-pagination-ellipsis">...</span>';
                }
            }

            for (let i = startPage; i <= endPage; i++) {
                const isCurrent = i === current_page;
                html += `<button type="button" class="hs-pagination-btn ${isCurrent ? 'hs-page-current' : ''}" data-page="${i}">${i}</button>`;
            }

            if (endPage < total_pages) {
                if (endPage < total_pages - 1) {
                    html += '<span class="hs-pagination-ellipsis">...</span>';
                }
                html += `<button type="button" class="hs-pagination-btn" data-page="${total_pages}">${total_pages}</button>`;
            }

            // Next button
            html += `<button type="button" class="hs-pagination-btn" ${!has_next ? 'disabled' : ''} data-page="${current_page + 1}">
                Next
                <span class="dashicons dashicons-arrow-right-alt"></span>
            </button>`;

            html += '</div>';

            // Info text
            html += `<div class="hs-pagination-info">
                Showing ${this.formatNumber((current_page - 1) * 20 + 1)} - ${this.formatNumber(Math.min(current_page * 20, total_records))} of ${this.formatNumber(total_records)} results
            </div>`;

            return html;
        }

        // ============================================================================
        // CHART RENDERING
        // ============================================================================

        initializeCharts() {
            // Chart.js will be loaded via CDN
            if (typeof Chart === 'undefined') {
                console.warn('Chart.js not loaded');
                return;
            }

            // Set default chart options
            Chart.defaults.font.family = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
            Chart.defaults.font.size = 12;
            Chart.defaults.plugins.legend.display = false;
        }

        renderVolumeChart(data) {
            this.destroyCurrentChart();

            if (!data || data.length === 0) {
                this.elements.chartContainer.html(`
                    <div class="hs-empty-state">
                        <div class="hs-empty-icon">
                            <span class="dashicons dashicons-chart-line"></span>
                        </div>
                        <h3 class="hs-empty-title">No Chart Data</h3>
                        <p class="hs-empty-description">No search volume data available for the selected time period.</p>
                    </div>
                `);
                return;
            }

            const ctx = document.createElement('canvas');
            this.elements.chartContainer.html(ctx);

            this.charts.current = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.map(d => this.formatChartLabel(d.date)),
                    datasets: [{
                        label: 'Search Volume',
                        data: data.map(d => d.count),
                        borderColor: 'var(--hs-primary)',
                        backgroundColor: 'rgba(124, 0, 42, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.4,
                        pointRadius: 4,
                        pointHoverRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: {
                        intersect: false,
                        mode: 'index'
                    },
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: (context) => `Searches: ${this.formatNumber(context.parsed.y)}`
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: (value) => this.formatNumber(value)
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }

        destroyCurrentChart() {
            if (this.charts.current) {
                this.charts.current.destroy();
                this.charts.current = null;
            }
        }

        // ============================================================================
        // EVENT HANDLERS
        // ============================================================================

        handleDateRangeChange() {
            const value = this.elements.dateRangeSelector.val();

            if (value === 'custom') {
                this.elements.customDateRange.addClass('show');
            } else {
                this.elements.customDateRange.removeClass('show');
                this.loadDashboardData();
                this.loadTableData();
            }
        }

        handleDateChange() {
            const from = this.elements.dateFrom.val();
            const to = this.elements.dateTo.val();

            if (from && to && new Date(from) <= new Date(to)) {
                this.loadDashboardData();
                this.loadTableData();
            }
        }

        handleFilterClick(event) {
            const button = $(event.currentTarget);
            const filter = button.data('filter');

            if (button.hasClass('hs-filter-reset')) {
                // Reset all filters
                this.elements.filterTags.removeClass('active');
                this.currentFilters = {};
            } else {
                // Toggle filter
                button.toggleClass('active');
                if (button.hasClass('active')) {
                    this.currentFilters[filter] = true;
                } else {
                    delete this.currentFilters[filter];
                }
            }

            this.loadDashboardData();
            this.loadTableData();
        }

        handleExport(event) {
            const button = $(event.currentTarget);
            const format = button.attr('id').replace('export-', '');

            this.exportData(format);
        }

        handleAutoRefreshToggle() {
            if (this.elements.autoRefreshToggle.is(':checked')) {
                this.startAutoRefresh();
            } else {
                this.stopAutoRefresh();
            }
        }

        handleManualRefresh() {
            this.loadDashboardData();
            this.loadTableData();
        }

        handleChartToggle(event) {
            const button = $(event.currentTarget);
            const chartType = button.data('chart');

            // Update active state
            this.elements.chartToggles.removeClass('active');
            button.addClass('active');

            // Switch chart
            this.switchChart(chartType);
        }

        handleTableSearch() {
            clearTimeout(this.searchTimeout);
            this.searchTimeout = setTimeout(() => {
                this.currentPage = 1;
                this.loadTableData();
            }, 300);
        }

        handleTableSort() {
            const value = this.elements.sortSelect.val();
            const [by, order] = value.split('_');

            this.currentSort = { by, order: order || 'desc' };
            this.currentPage = 1;
            this.loadTableData();
        }

        handlePagination(event) {
            const button = $(event.currentTarget);
            const page = parseInt(button.data('page'));

            if (page && page !== this.currentPage) {
                this.currentPage = page;
                this.loadTableData();
            }
        }

        // ============================================================================
        // UTILITY FUNCTIONS
        // ============================================================================

        getCurrentDateRange() {
            const type = this.elements.dateRangeSelector.val();
            const from = this.elements.dateFrom.val();
            const to = this.elements.dateTo.val();

            return {
                type: type,
                from: type === 'custom' ? from : null,
                to: type === 'custom' ? to : null
            };
        }

        getCurrentFilters() {
            return { ...this.currentFilters };
        }

        startAutoRefresh() {
            this.stopAutoRefresh(); // Clear any existing timer
            this.autoRefreshTimer = setInterval(() => {
                this.loadRealtimeData();
            }, this.settings.refreshInterval);
        }

        stopAutoRefresh() {
            if (this.autoRefreshTimer) {
                clearInterval(this.autoRefreshTimer);
                this.autoRefreshTimer = null;
            }
        }

        showLoadingState() {
            // Add loading indicators to various sections
            this.elements.metricsGrid.addClass('loading');
            this.elements.chartContainer.addClass('loading');
            this.elements.insightsContainer.addClass('loading');
        }

        hideLoadingState() {
            this.elements.metricsGrid.removeClass('loading');
            this.elements.chartContainer.removeClass('loading');
            this.elements.insightsContainer.removeClass('loading');
        }

        showErrorState(message) {
            const errorHtml = `
                <div class="hs-error-state">
                    <div class="hs-error-icon">
                        <span class="dashicons dashicons-warning"></span>
                    </div>
                    <h3 class="hs-error-title">Unable to Load Data</h3>
                    <p class="hs-error-description">${message}</p>
                    <button type="button" class="hs-error-action" onclick="location.reload()">
                        Try Again
                    </button>
                </div>
            `;

            this.elements.metricsGrid.html(errorHtml);
        }

        showTableError() {
            const errorHtml = `
                <div class="hs-error-state">
                    <p>Failed to load table data. Please try refreshing the page.</p>
                </div>
            `;

            this.elements.tableContainer.html(errorHtml);
        }

        formatMetricValue(value, format) {
            switch (format) {
                case 'time':
                    return `${value}ms`;
                case 'percentage':
                    return `${value}%`;
                case 'number':
                default:
                    return this.formatNumber(value);
            }
        }

        formatChangeValue(value, type) {
            const formatted = Math.abs(value);
            switch (type) {
                case 'percentage':
                    return `${formatted}%`;
                case 'time':
                    return `${formatted}ms`;
                default:
                    return formatted.toString();
            }
        }

        formatNumber(num) {
            return new Intl.NumberFormat().format(num);
        }

        formatResponseTime(ms) {
            if (ms < 500) return `${ms}ms`;
            return `${(ms / 1000).toFixed(2)}s`;
        }

        getResponseTimeClass(ms) {
            if (ms < 500) return 'fast';
            if (ms < 2000) return 'medium';
            return 'slow';
        }

        getDeviceBadgeClass(device) {
            return device || 'unknown';
        }

        getDeviceIcon(device) {
            switch (device) {
                case 'mobile':
                    return 'dashicons-smartphone';
                case 'tablet':
                    return 'dashicons-tablet';
                case 'desktop':
                default:
                    return 'dashicons-desktop';
            }
        }

        formatTimestamp(timestamp) {
            return new Date(timestamp).toLocaleString();
        }

        formatChartLabel(date) {
            return new Date(date).toLocaleDateString();
        }

        formatLastUpdated(timestamp) {
            const now = new Date();
            const updated = new Date(timestamp);
            const diffMs = now - updated;
            const diffMins = Math.floor(diffMs / 60000);
            const diffHours = Math.floor(diffMins / 60);
            const diffDays = Math.floor(diffHours / 24);

            if (diffMins < 1) return this.strings.justNow;
            if (diffMins < 60) return sprintf(this.strings.minutesAgo, diffMins);
            if (diffHours < 24) return sprintf(this.strings.hoursAgo, diffHours);
            return sprintf(this.strings.daysAgo, diffDays);
        }

        getInsightIcon(type) {
            switch (type) {
                case 'success':
                    return 'dashicons-yes-alt';
                case 'warning':
                    return 'dashicons-warning';
                case 'error':
                    return 'dashicons-no-alt';
                case 'info':
                default:
                    return 'dashicons-info';
            }
        }

        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        async exportData(format) {
            try {
                const dateRange = this.getCurrentDateRange();
                const filters = this.getCurrentFilters();

                // Create form for export
                const form = $('<form>', {
                    method: 'POST',
                    action: this.ajaxUrl,
                    target: '_blank'
                });

                form.append($('<input>', {
                    type: 'hidden',
                    name: 'action',
                    value: 'hybrid_search_export_analytics'
                }));

                form.append($('<input>', {
                    type: 'hidden',
                    name: 'format',
                    value: format
                }));

                form.append($('<input>', {
                    type: 'hidden',
                    name: 'date_range',
                    value: dateRange.type
                }));

                form.append($('<input>', {
                    type: 'hidden',
                    name: 'date_from',
                    value: dateRange.from
                }));

                form.append($('<input>', {
                    type: 'hidden',
                    name: 'date_to',
                    value: dateRange.to
                }));

                form.append($('<input>', {
                    type: 'hidden',
                    name: 'nonce',
                    value: hybridSearchAnalytics.exportNonce
                }));

                $('body').append(form);
                form.submit();
                form.remove();

            } catch (error) {
                console.error('Export failed:', error);
                alert('Export failed. Please try again.');
            }
        }

        handleDateRangeToggle() {
            const selectedValue = this.elements.dateRange.val();
            if (selectedValue === 'custom') {
                this.elements.customDateRange.show();
            } else {
                this.elements.customDateRange.hide();
            }
        }

        handleFilterChange() {
            // Debounce filter changes
            clearTimeout(this.filterTimeout);
            this.filterTimeout = setTimeout(() => {
                this.loadDashboardData();
            }, 300);
        }

        handleExport() {
            const filters = this.getCurrentFilters();
            const url = `${this.ajaxUrl}?action=hybrid_search_export_analytics&nonce=${this.nonce}&${$.param(filters)}`;
            window.open(url, '_blank');
        }

        handleClearAnalytics() {
            if (!confirm('Are you sure you want to clear all analytics data? This action cannot be undone.')) {
                return;
            }

            this.showLoadingState();

            $.ajax({
                url: this.ajaxUrl,
                type: 'POST',
                data: {
                    action: 'hybrid_search_clear_analytics',
                    nonce: this.nonce
                },
                success: (response) => {
                    if (response.success) {
                        this.loadDashboardData();
                    } else {
                        this.showError('Failed to clear analytics data');
                    }
                },
                error: () => {
                    this.showError('Failed to clear analytics data');
                }
            });
        }

        getCurrentFilters() {
            return {
                date_range: this.elements.dateRange.val(),
                date_from: this.elements.dateFrom.val(),
                date_to: this.elements.dateTo.val(),
                search_query: this.elements.searchQueryFilter.val(),
                device: this.elements.deviceFilter.val()
            };
        }

        showLoadingState() {
            this.elements.analyticsLoading.show();
            this.elements.analyticsError.hide();
            this.elements.analyticsDashboardContent.hide();
        }

        showError(message) {
            this.elements.analyticsLoading.hide();
            this.elements.analyticsErrorMessage.text(message);
            this.elements.analyticsError.show();
            this.elements.analyticsDashboardContent.hide();
        }

        hideLoading() {
            this.elements.analyticsLoading.hide();
            this.elements.analyticsError.hide();
            this.elements.analyticsDashboardContent.show();
        }

        switchChart(chartType) {
            // This would be implemented to switch between different chart types
            console.log('Switching to chart:', chartType);
        }

        cleanup() {
            this.stopAutoRefresh();
            this.destroyCurrentChart();
        }
    }

    // Initialize dashboard when DOM is ready
    $(document).ready(function() {
        if ($('#analytics-dashboard-content').length) {
            window.hybridSearchAnalytics = new AnalyticsDashboard();
        }
    });

    // Global function for query details (can be called from table rows)
    window.viewQueryDetails = function(query) {
        // Open a modal or navigate to query details page
        console.log('View details for query:', query);
        // This would be implemented to show query-specific analytics
    };

})(jQuery);
