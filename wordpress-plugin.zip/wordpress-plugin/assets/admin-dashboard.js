/**
 * Hybrid Search Admin Dashboard - Modern JavaScript
 * Interactive admin dashboard with real-time updates and advanced features
 * Version: 2.26.0
 */

(function($) {
    'use strict';

    class AdminDashboard {
        constructor() {
            this.ajaxUrl = hybridSearchAdmin.ajaxUrl;
            this.nonce = hybridSearchAdmin.nonce;
            this.apiUrl = hybridSearchAdmin.apiUrl;
            this.settings = hybridSearchAdmin.settings || {};
            this.strings = hybridSearchAdmin.strings;

            // State management
            this.isLoading = false;
            this.charts = {};
            this.lastUpdated = new Date();
            this.noticeTimeout = null;
            this.chartData = null;

            // DOM elements cache
            this.elements = {};

            this.init();
        }

        init() {
            this.cacheElements();
            this.bindEvents();
            this.initializeCharts();
            this.loadDashboardData();
            this.startRealTimeUpdates();

            // Test API connection on load
            this.testAPIConnection();
        }

        cacheElements() {
            this.elements = {
                // Header elements
                apiStatusDot: $('#api-status-dot'),
                apiStatusText: $('#api-status-text'),
                lastUpdatedTime: $('#last-updated-time'),
                rankIndexContainer: $('#rank-index-status'),
                rankIndexBar: $('#rank-index-progress'),
                rankIndexText: $('#rank-index-text'),
                rankIndexMeta: $('#rank-index-meta'),

                // Stats elements
                quickStats: $('#quick-stats'),

                // Chart elements
                performanceChart: $('#performance-chart'),
                chartToggles: $('.hs-chart-toggle'),

                // Action elements
                testApiConnection: $('#test-api-connection'),
                reindexContent: $('#reindex-content'),
                clearCache: $('#clear-cache'),
                apiTestStatus: $('#api-test-status'),

                // Activity elements
                recentActivity: $('#recent-activity'),

                // Health elements
                systemHealth: $('#system-health')
            };
        }

        bindEvents() {
            // Chart toggle events
            this.elements.chartToggles.on('click', this.handleChartToggle.bind(this));

            // Action button events
            this.elements.testApiConnection.on('click', this.handleTestAPIConnection.bind(this));
            this.elements.reindexContent.on('click', this.handleReindexContent.bind(this));
            this.elements.clearCache.on('click', this.handleClearCache.bind(this));

            // Window events
            $(window).on('beforeunload', this.cleanup.bind(this));
        }

        // ============================================================================
        // DATA LOADING
        // ============================================================================

        async loadDashboardData() {
            if (this.isLoading) return;

            try {
                this.isLoading = true;
                this.showLoadingStates();
                this.updateRankIndexStatus({ loading: true });

                // Load all dashboard data in parallel
                const [stats, activity, health, rankIndex] = await Promise.allSettled([
                    this.loadQuickStats(),
                    this.loadRecentActivity(),
                    this.loadSystemHealth(),
                    this.fetchRankIndexStatus()
                ]);

                // Update UI with loaded data
                if (stats.status === 'fulfilled') {
                    this.updateQuickStats(stats.value);
                }

                if (activity.status === 'fulfilled') {
                    this.updateRecentActivity(activity.value);
                }

                if (health.status === 'fulfilled') {
                    this.updateSystemHealth(health.value);
                }

                if (rankIndex.status === 'fulfilled') {
                    this.updateRankIndexStatus(rankIndex.value);
                } else {
                    const reason = rankIndex.reason ? rankIndex.reason.message : null;
                    this.updateRankIndexStatus({
                        available: false,
                        message: reason || this.strings.rankIndexUnavailable
                    });
                }

                // Load chart data
                const activeChart = this.elements.chartToggles.filter('.active').data('chart') || 'searches';
                await this.loadChartData(activeChart);

                this.updateLastUpdated();

            } catch (error) {
                console.error('Dashboard data loading error:', error);
                this.showErrorState(error.message);
            } finally {
                this.isLoading = false;
                this.hideLoadingStates();
            }
        }

        async loadQuickStats() {
            const days = this.settings.defaultRangeDays || 30;

            try {
                const response = await this.makeAjaxRequest('hybrid_search_dashboard_data', {
                    section: 'stats',
                    days
                });

                if (!response.success) {
                    throw new Error(response.data?.message || this.strings.error);
                }

                return response.data;
            } catch (error) {
                console.error('Failed to load quick stats:', error);
                throw error;
            }
        }

        async loadRecentActivity() {
            const limit = this.settings.activityLimit || 10;

            try {
                const response = await this.makeAjaxRequest('hybrid_search_dashboard_data', {
                    section: 'activity',
                    limit
                });

                if (!response.success) {
                    throw new Error(response.data?.message || this.strings.error);
                }

                return response.data;
            } catch (error) {
                console.error('Failed to load recent activity:', error);
                throw error;
            }
        }

        async loadSystemHealth() {
            try {
                const response = await this.makeAjaxRequest('hybrid_search_dashboard_data', {
                    section: 'health'
                });

                if (!response.success) {
                    throw new Error(response.data?.message || this.strings.error);
                }

                return response.data;
            } catch (error) {
                console.error('Failed to load system health:', error);
                throw error;
            }
        }

        async fetchRankIndexStatus() {
            try {
                const response = await this.makeAjaxRequest('hybrid_search_dashboard_data', {
                    section: 'rank_index'
                });

                if (!response.success) {
                    throw new Error(response.data?.message || this.strings.error);
                }

                return response.data;
            } catch (error) {
                console.error('Failed to load rank index status:', error);
                throw error;
            }
        }

        async loadChartData(chartType = 'searches') {
            const days = this.settings.defaultRangeDays || 30;

            try {
                const response = await this.makeAjaxRequest('hybrid_search_dashboard_data', {
                    section: 'charts',
                    days
                });

                if (!response.success) {
                    throw new Error(response.data?.message || this.strings.error);
                }

                this.chartData = response.data;
                this.updateChart(this.chartData, chartType);
            } catch (error) {
                console.error('Failed to load chart data:', error);
                throw error;
            }
        }

        async checkAPIHealth() {
            try {
                const response = await this.makeAjaxRequest('hybrid_search_test_connection');
                return {
                    connected: response.success === true,
                    message: response.data?.message || ''
                };
            } catch (error) {
                console.warn('API health check failed:', error);
                return {
                    connected: false,
                    message: error.message || ''
                };
            }
        }

        // ============================================================================
        // UI UPDATES
        // ============================================================================

        updateQuickStats(stats) {
            const statsHtml = this.generateStatsHtml(stats);
            this.elements.quickStats.html(statsHtml);
        }

        updateRecentActivity(activities) {
            const activityHtml = this.generateActivityHtml(activities);
            this.elements.recentActivity.html(activityHtml);
        }

        updateSystemHealth(healthData) {
            const healthHtml = this.generateHealthHtml(healthData);
            this.elements.systemHealth.html(healthHtml);
        }

        updateRankIndexStatus(data) {
            const container = this.elements.rankIndexContainer;
            if (!container || !container.length) {
                return;
            }

            const bar = this.elements.rankIndexBar;
            const progress = bar && bar.length ? bar.closest('.hs-rank-progress') : null;
            const text = this.elements.rankIndexText;
            const meta = this.elements.rankIndexMeta;

            container.removeClass('status-healthy status-warning status-error status-complete is-loading');

            if (data && data.loading) {
                container.addClass('is-loading');
                if (bar && bar.length) {
                    bar.css('width', '25%').removeClass('complete');
                }
                if (progress && progress.length) {
                    progress.attr('aria-valuenow', 0);
                }
                if (text && text.length) {
                    text.text(this.strings.rankIndexLoading || 'Calculating rank index...');
                }
                if (meta && meta.length) {
                    meta.text('');
                }
                return;
            }

            if (bar && bar.length) {
                bar.removeClass('complete');
            }

            if (!data || data.available === false) {
                container.addClass('status-error');
                if (bar && bar.length) {
                    bar.css('width', '0%');
                }
                if (progress && progress.length) {
                    progress.attr('aria-valuenow', 0);
                }
                if (text && text.length) {
                    text.text((data && data.message) || this.strings.rankIndexUnavailable || 'Rank index unavailable');
                }
                if (meta && meta.length) {
                    meta.text('');
                }
                return;
            }

            let percent = parseFloat(data.percent);
            if (!Number.isFinite(percent)) {
                percent = 0;
            }
            percent = Math.max(0, Math.min(100, percent));

            const status = (data.status || 'healthy').toLowerCase();
            if (status === 'warning' || status === 'caution' || status === 'degraded') {
                container.addClass('status-warning');
            } else if (status === 'error' || status === 'offline' || status === 'unavailable') {
                container.addClass('status-error');
            } else {
                container.addClass('status-healthy');
            }

            if (percent >= 99.5) {
                container.addClass('status-complete');
            }

            if (bar && bar.length) {
                bar.css('width', `${percent}%`);
                bar.toggleClass('complete', percent >= 99.5);
            }
            if (progress && progress.length) {
                progress.attr('aria-valuenow', percent.toFixed(1));
            }

            if (text && text.length) {
                text.text(data.message || this.strings.rankIndexReady || 'Rank index ready');
            }

            if (meta && meta.length) {
                const pieces = [];

                if (typeof data.indexed === 'number') {
                    if (typeof data.expected === 'number' && data.expected > 0) {
                        pieces.push(`${this.formatNumber(data.indexed)} / ${this.formatNumber(data.expected)} · ${percent.toFixed(1)}%`);
                    } else {
                        const label = this.strings.indexedLabel || 'indexed';
                        pieces.push(`${this.formatNumber(data.indexed)} ${label}`);
                    }
                }

                if (typeof data.vectors === 'number' && data.vectors > 0 && data.vectors !== data.indexed) {
                    const vLabel = this.strings.vectorsLabel || 'vectors';
                    pieces.push(`${this.formatNumber(data.vectors)} ${vLabel}`);
                }

                if (data.collection) {
                    pieces.push(data.collection);
                }

                if (data.api_version) {
                    pieces.push(`v${data.api_version}`);
                }

                meta.text(pieces.join(' · '));
            }
        }

        updateChart(chartData = this.chartData, chartType = null) {
            if (!chartData) {
                return;
            }

            const activeChart = chartType || this.elements.chartToggles.filter('.active').data('chart') || 'searches';

            if (activeChart === 'performance') {
                this.renderPerformanceChart(chartData);
            } else {
                this.renderSearchesChart(chartData);
            }
        }

        updateLastUpdated() {
            this.lastUpdated = new Date();
            this.elements.lastUpdatedTime.text(this.formatLastUpdated(this.lastUpdated));
        }

        updateAPIStatus(connected, message = '') {
            const statusDot = this.elements.apiStatusDot;
            const statusText = this.elements.apiStatusText;

            if (connected) {
                statusDot.removeClass('disconnected').addClass('connected');
                statusText.text(message || this.strings.connected);
            } else {
                statusDot.removeClass('connected').addClass('disconnected');
                statusText.text(message || this.strings.disconnected);
            }
        }

        // ============================================================================
        // HTML GENERATION
        // ============================================================================

        generateStatsHtml(stats) {
            const statCards = [
                {
                    key: 'total_searches',
                    label: 'Total Searches',
                    icon: 'dashicons-search',
                    value: stats.total_searches,
                    change: stats.total_searches_change,
                    format: 'number'
                },
                {
                    key: 'successful_searches',
                    label: 'Successful Searches',
                    icon: 'dashicons-yes-alt',
                    value: stats.successful_searches,
                    change: stats.successful_searches_change,
                    format: 'number'
                },
                {
                    key: 'avg_response_time',
                    label: 'Avg Response Time',
                    icon: 'dashicons-clock',
                    value: stats.avg_response_time,
                    change: stats.avg_response_time_change,
                    format: 'time'
                },
                {
                    key: 'ctr',
                    label: 'Click-Through Rate',
                    icon: 'dashicons-external',
                    value: stats.ctr,
                    change: stats.ctr_change,
                    format: 'percentage'
                }
            ];

            return statCards.map(card => this.generateStatCardHtml(card)).join('');
        }

        generateStatCardHtml(card) {
            const formattedValue = this.formatStatValue(card.value, card.format);
            const changeHtml = card.change ? this.generateChangeHtml(card.change) : '';

            return `
                <div class="hs-stat-card" data-stat="${card.key}">
                    <div class="hs-stat-icon">
                        <span class="dashicons ${card.icon}"></span>
                    </div>
                    <div class="hs-stat-value">${formattedValue}</div>
                    <div class="hs-stat-label">${card.label}</div>
                    ${changeHtml}
                </div>
            `;
        }

        generateChangeHtml(change) {
            const { value, type } = change;
            const formattedChange = this.formatChangeValue(value, type);
            const changeClass = value > 0 ? 'positive' : value < 0 ? 'negative' : 'neutral';
            const arrow = value > 0 ? '↗' : value < 0 ? '↘' : '→';

            return `<div class="hs-stat-change ${changeClass}">${arrow} ${formattedChange}</div>`;
        }

        generateActivityHtml(activities) {
            if (!activities || activities.length === 0) {
                return `
                    <div class="hs-empty-state">
                        <div class="hs-empty-icon">
                            <span class="dashicons dashicons-clock"></span>
                        </div>
                        <h3 class="hs-empty-title">No Recent Activity</h3>
                        <p class="hs-empty-description">Search activity will appear here as users interact with your site.</p>
                    </div>
                `;
            }

            const activityList = activities.map(activity => this.generateActivityItemHtml(activity)).join('');

            return `<div class="hs-activity-list">${activityList}</div>`;
        }

        generateActivityItemHtml(activity) {
            const timeAgo = this.formatTimeAgo(new Date(activity.timestamp));
            const deviceIcon = this.getDeviceIcon(activity.device_type);

            return `
                <div class="hs-activity-item">
                    <div class="hs-activity-icon">
                        <span class="dashicons dashicons-search"></span>
                    </div>
                    <div class="hs-activity-content">
                        <div class="hs-activity-query">${this.escapeHtml(activity.query)}</div>
                        <div class="hs-activity-meta">
                            <span>${activity.result_count} results</span>
                            <span class="hs-activity-time">
                                <span class="dashicons dashicons-clock"></span>
                                ${timeAgo}
                            </span>
                        </div>
                    </div>
                    <div class="hs-activity-device">
                        <span class="dashicons ${deviceIcon}" title="${activity.device_type}"></span>
                    </div>
                </div>
            `;
        }

        generateHealthHtml(healthData) {
            return healthData.map(health => this.generateHealthCardHtml(health)).join('');
        }

        generateHealthCardHtml(health) {
            const iconClass = this.getHealthIcon(health.status);

            return `
                <div class="hs-health-card ${health.status}">
                    <div class="hs-health-icon">
                        <span class="dashicons ${iconClass}"></span>
                    </div>
                    <div class="hs-health-content">
                        <h3 class="hs-health-title">${health.name}</h3>
                        <p class="hs-health-description">${health.description}</p>
                        <div class="hs-health-metric">${health.metric}</div>
                    </div>
                </div>
            `;
        }

        // ============================================================================
        // CHART RENDERING
        // ============================================================================

        initializeCharts() {
            if (typeof Chart === 'undefined') {
                console.warn('Chart.js not loaded');
                return;
            }

            // Set default chart options
            Chart.defaults.font.family = '-apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
            Chart.defaults.font.size = 12;
            Chart.defaults.plugins.legend.display = false;
        }

        renderSearchesChart(data) {
            this.destroyCurrentChart();

            const ctx = document.createElement('canvas');
            this.elements.performanceChart.html(ctx);

            this.charts.current = new Chart(ctx, {
                type: 'line',
                data: {
                    labels: data.labels,
                    datasets: [{
                        label: 'Daily Searches',
                        data: data.searches,
                        borderColor: 'var(--hs-primary)',
                        backgroundColor: 'rgba(124, 0, 42, 0.1)',
                        borderWidth: 2,
                        fill: true,
                        tension: 0.4,
                        pointRadius: 4,
                        pointHoverRadius: 6
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: {
                        intersect: false,
                        mode: 'index'
                    },
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: (context) => `Searches: ${this.formatNumber(context.parsed.y)}`
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: (value) => this.formatNumber(value)
                            }
                        },
                        x: {
                            grid: {
                                display: false
                            }
                        }
                    }
                }
            });
        }

        renderPerformanceChart(data) {
            this.destroyCurrentChart();

            const ctx = document.createElement('canvas');
            this.elements.performanceChart.html(ctx);

            this.charts.current = new Chart(ctx, {
                type: 'bar',
                data: {
                    labels: data.labels,
                    datasets: [{
                        label: 'Avg Response Time (seconds)',
                        data: data.performance,
                        backgroundColor: 'rgba(59, 130, 246, 0.8)',
                        borderColor: 'var(--hs-info)',
                        borderWidth: 1,
                        borderRadius: 4
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        tooltip: {
                            callbacks: {
                                label: (context) => `Response Time: ${context.parsed.y}s`
                            }
                        }
                    },
                    scales: {
                        y: {
                            beginAtZero: true,
                            ticks: {
                                callback: (value) => `${value}s`
                            }
                        }
                    }
                }
            });
        }

        destroyCurrentChart() {
            if (this.charts.current) {
                this.charts.current.destroy();
                this.charts.current = null;
            }
        }

        // ============================================================================
        // EVENT HANDLERS
        // ============================================================================

        async handleTestAPIConnection() {
            const button = this.elements.testApiConnection;
            const statusElement = this.elements.apiTestStatus;
            const originalIcon = statusElement.html();

            // Update UI to show testing
            button.prop('disabled', true);
            statusElement.html('<span class="dashicons dashicons-update spinning"></span>');

            try {
                const status = await this.checkAPIHealth();
                this.updateAPIStatus(status.connected, status.message);

                if (status.connected) {
                    statusElement.html('<span class="dashicons dashicons-yes-alt"></span>');
                    statusElement.addClass('success');
                    this.showSuccessMessage(status.message || this.strings.connectionOk);
                } else {
                    statusElement.html('<span class="dashicons dashicons-no-alt"></span>');
                    statusElement.addClass('error');
                    this.showErrorMessage(status.message || this.strings.connectionFailed);
                }

                // Reset after 3 seconds
                setTimeout(() => {
                    statusElement.html(originalIcon);
                    statusElement.removeClass('success error');
                    button.prop('disabled', false);
                }, 3000);

            } catch (error) {
                console.error('API test failed:', error);
                statusElement.html('<span class="dashicons dashicons-no-alt"></span>');
                statusElement.addClass('error');
                this.showErrorMessage('API test failed: ' + error.message);

                setTimeout(() => {
                    statusElement.html(originalIcon);
                    statusElement.removeClass('error');
                    button.prop('disabled', false);
                }, 3000);
            }
        }

        async handleReindexContent() {
            if (!confirm('This will reindex all your content. This may take some time. Continue?')) {
                return;
            }

            const button = this.elements.reindexContent;
            const statusElement = button.find('.hs-action-status');
            const originalIcon = statusElement.html();

            button.prop('disabled', true);
            statusElement.html('<span class="dashicons dashicons-update spinning"></span>');

            try {
                const response = await this.makeAjaxRequest('reindex_content');
                if (response.success) {
                    statusElement.html('<span class="dashicons dashicons-yes"></span>');
                    this.showSuccessMessage(response.data?.message || 'Reindexing has started in the background.');
                } else {
                    throw new Error(response.data?.message || 'Reindexing failed');
                }
            } catch (error) {
                console.error('Reindexing failed:', error);
                statusElement.html('<span class="dashicons dashicons-no"></span>');
                this.showErrorMessage('Reindexing failed: ' + error.message);
            }

            // Reset after 3 seconds
            setTimeout(() => {
                statusElement.html(originalIcon);
                button.prop('disabled', false);
            }, 3000);
        }

        async handleClearCache() {
            if (!confirm('This will clear all cached search results. Continue?')) {
                return;
            }

            const button = this.elements.clearCache;
            const statusElement = button.find('.hs-action-status');
            const originalIcon = statusElement.html();

            button.prop('disabled', true);
            statusElement.html('<span class="dashicons dashicons-update spinning"></span>');

            try {
                const response = await this.makeAjaxRequest('clear_search_cache');
                if (response.success) {
                    statusElement.html('<span class="dashicons dashicons-yes"></span>');
                    this.showSuccessMessage('Cache cleared successfully!');
                } else {
                    throw new Error(response.data?.message || 'Cache clearing failed');
                }
            } catch (error) {
                console.error('Cache clearing failed:', error);
                statusElement.html('<span class="dashicons dashicons-no"></span>');
                this.showErrorMessage('Cache clearing failed: ' + error.message);
            }

            // Reset after 3 seconds
            setTimeout(() => {
                statusElement.html(originalIcon);
                button.prop('disabled', false);
            }, 3000);
        }

        handleChartToggle(event) {
            const button = $(event.currentTarget);
            const chartType = button.data('chart') || 'searches';

            // Update active state
            this.elements.chartToggles.removeClass('active');
            button.addClass('active');

            if (this.chartData) {
                this.updateChart(this.chartData, chartType);
            } else {
                this.loadChartData(chartType);
            }
        }

        async testAPIConnection() {
            try {
                const status = await this.checkAPIHealth();
                this.updateAPIStatus(status.connected, status.message);
                if (!status.connected && status.message) {
                    this.showErrorMessage(status.message);
                }
            } catch (error) {
                console.warn('Initial API test failed:', error);
                this.updateAPIStatus(false, this.strings.disconnected);
            }
        }

        startRealTimeUpdates() {
            if (this.settings.autoRefresh) {
                this.realTimeTimer = setInterval(() => {
                    this.loadDashboardData();
                }, this.settings.refreshInterval);
            }
        }

        stopRealTimeUpdates() {
            if (this.realTimeTimer) {
                clearInterval(this.realTimeTimer);
                this.realTimeTimer = null;
            }
        }

        // ============================================================================
        // UTILITY FUNCTIONS
        // ============================================================================

        makeAjaxRequest(action, data = {}) {
            return new Promise((resolve, reject) => {
                $.ajax({
                    url: this.ajaxUrl,
                    type: 'POST',
                    data: {
                        action: action,
                        nonce: this.nonce,
                        ...data
                    },
                    success: resolve,
                    error: (xhr, status, error) => {
                        let message = '';

                        // Prefer structured JSON error responses
                        if (xhr && xhr.responseJSON) {
                            if (xhr.responseJSON.data && xhr.responseJSON.data.message) {
                                message = xhr.responseJSON.data.message;
                            } else if (xhr.responseJSON.message) {
                                message = xhr.responseJSON.message;
                            }
                        }

                        // Fallback to responseText if no JSON message
                        if (!message && xhr && typeof xhr.responseText === 'string' && xhr.responseText.trim().length) {
                            message = xhr.responseText.trim();
                        }

                        // Include HTTP status if available
                        const statusCode = xhr && xhr.status ? `HTTP ${xhr.status}` : '';

                        if (!message) {
                            message = error || status || 'Unknown error';
                        }

                        const finalMessage = statusCode ? `${statusCode}: ${message}` : message;
                        reject(new Error(finalMessage));
                    }
                });
            });
        }

        showLoadingStates() {
            // Add loading indicators to various sections
            this.elements.quickStats.addClass('loading');
            this.elements.performanceChart.addClass('loading');
            this.elements.recentActivity.addClass('loading');
            this.elements.systemHealth.addClass('loading');
        }

        hideLoadingStates() {
            this.elements.quickStats.removeClass('loading');
            this.elements.performanceChart.removeClass('loading');
            this.elements.recentActivity.removeClass('loading');
            this.elements.systemHealth.removeClass('loading');
        }

        showSuccessMessage(message) {
            if (window.wp && wp.a11y && typeof wp.a11y.speak === 'function') {
                wp.a11y.speak(message, 'polite');
            }
            this.renderNotice(message, 'success');
            console.log('Success:', message);
        }

        showErrorMessage(message) {
            if (window.wp && wp.a11y && typeof wp.a11y.speak === 'function') {
                wp.a11y.speak(message, 'assertive');
            }
            this.renderNotice(message, 'error');
            console.error('Error:', message);
        }

        renderNotice(message, type = 'info') {
            const container = $('#hybrid-search-admin-dashboard');
            if (!container.length) {
                console.log(message);
                return;
            }

            let notice = container.find('.hs-dashboard-notice');
            if (!notice.length) {
                notice = $('<div class="hs-dashboard-notice" />');
                container.prepend(notice);
            }

            notice
                .removeClass('success error info')
                .addClass(type)
                .text(message)
                .attr('role', 'status')
                .stop(true, true)
                .hide()
                .fadeIn(150);

            clearTimeout(this.noticeTimeout);
            this.noticeTimeout = setTimeout(() => {
                notice.fadeOut(200, () => notice.remove());
            }, 5000);
        }

        formatStatValue(value, format) {
            switch (format) {
                case 'time':
                    return `${value}s`;
                case 'percentage':
                    return `${value}%`;
                case 'number':
                default:
                    return this.formatNumber(value);
            }
        }

        formatChangeValue(value, type) {
            const formatted = Math.abs(value);
            switch (type) {
                case 'percentage':
                    return `${formatted}%`;
                case 'time':
                    return `${formatted}s`;
                default:
                    return formatted.toString();
            }
        }

        formatNumber(num) {
            return new Intl.NumberFormat().format(num);
        }

        formatTimeAgo(date) {
            const now = new Date();
            const diffMs = now - date;
            const diffMins = Math.floor(diffMs / 60000);
            const diffHours = Math.floor(diffMins / 60);
            const diffDays = Math.floor(diffHours / 24);

            if (diffMins < 1) return 'Just now';
            if (diffMins < 60) return `${diffMins}m ago`;
            if (diffHours < 24) return `${diffHours}h ago`;
            return `${diffDays}d ago`;
        }

        formatLastUpdated(date) {
            const now = new Date();
            const diffMs = now - date;
            const diffMins = Math.floor(diffMs / 60000);
            const diffHours = Math.floor(diffMins / 60);
            const diffDays = Math.floor(diffHours / 24);

            if (diffMins < 1) return this.strings.justNow;
            if (diffMins < 60) return sprintf(this.strings.minutesAgo, diffMins);
            if (diffHours < 24) return sprintf(this.strings.hoursAgo, diffHours);
            return sprintf(this.strings.daysAgo, diffDays);
        }

        getDeviceIcon(device) {
            switch (device) {
                case 'mobile':
                    return 'dashicons-smartphone';
                case 'tablet':
                    return 'dashicons-tablet';
                case 'desktop':
                default:
                    return 'dashicons-desktop';
            }
        }

        getHealthIcon(status) {
            switch (status) {
                case 'healthy':
                    return 'dashicons-yes-alt';
                case 'warning':
                    return 'dashicons-warning';
                case 'error':
                    return 'dashicons-no-alt';
                default:
                    return 'dashicons-info';
            }
        }

        escapeHtml(text) {
            const div = document.createElement('div');
            div.textContent = text;
            return div.innerHTML;
        }

        cleanup() {
            this.stopRealTimeUpdates();
            this.destroyCurrentChart();
        }
    }

    // Initialize dashboard when DOM is ready
    $(document).ready(function() {
        if ($('#hybrid-search-admin-dashboard').length) {
            window.hybridSearchAdmin = new AdminDashboard();
        }
    });

})(jQuery);
