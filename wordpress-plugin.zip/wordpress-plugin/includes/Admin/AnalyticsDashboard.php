<?php
/**
 * Modern Analytics Dashboard
 *
 * Comprehensive, modern analytics dashboard for the Hybrid Search plugin
 * with advanced UI/UX, real-time updates, and interactive features.
 *
 * @package HybridSearch\Admin
 * @since 2.21.0
 */

namespace HybridSearch\Admin;

use HybridSearch\Services\AnalyticsService;
use HybridSearch\Services\CTRService;

class AnalyticsDashboard {

    /**
     * Analytics service
     *
     * @var AnalyticsService
     */
    private $analytics_service;

    /**
     * CTR service
     *
     * @var CTRService
     */
    private $ctr_service;

    /**
     * Constructor
     *
     * @param AnalyticsService $analytics_service
     * @param CTRService $ctr_service
     */
    public function __construct(AnalyticsService $analytics_service, CTRService $ctr_service) {
        $this->analytics_service = $analytics_service;
        $this->ctr_service = $ctr_service;
    }

    /**
     * Register hooks
     */
    public function registerHooks() {
        add_action('admin_menu', [$this, 'addAdminMenu']);
        add_action('wp_ajax_hybrid_search_analytics_data', [$this, 'handleAnalyticsData']);
        add_action('wp_ajax_hybrid_search_export_analytics', [$this, 'handleExportAnalytics']);
        add_action('wp_ajax_hybrid_search_clear_analytics_cache', [$this, 'handleClearCache']);
        add_action('wp_ajax_hybrid_search_realtime_analytics', [$this, 'handleRealtimeAnalytics']);
    }

    /**
     * Add admin menu
     */
    public function addAdminMenu() {
        add_submenu_page(
            'hybrid-search',
            __('Analytics Dashboard', 'hybrid-search'),
            __('Analytics', 'hybrid-search'),
            'manage_options',
            'hybrid-search-analytics',
            [$this, 'renderDashboard']
        );
    }

    /**
     * Render modern analytics dashboard
     */
    public function renderDashboard() {
        // Enqueue required assets
        wp_enqueue_style('hybrid-search-analytics', plugins_url('assets/analytics-dashboard.css', dirname(__FILE__, 2)), [], HYBRID_SEARCH_VERSION);
        wp_enqueue_script('chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', [], '4.4.0', true);
        wp_enqueue_script('hybrid-search-analytics', plugins_url('assets/analytics-dashboard.js', dirname(__FILE__, 2)), ['jquery', 'chart-js'], HYBRID_SEARCH_VERSION, true);

        // Localize script with data
        wp_localize_script('hybrid-search-analytics', 'hybridSearchAnalytics', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('hybrid_search_analytics'),
            'exportNonce' => wp_create_nonce('hybrid_search_export'),
            'strings' => [
                'loading' => __('Loading...', 'hybrid-search'),
                'error' => __('Error loading data', 'hybrid-search'),
                'noData' => __('No data available', 'hybrid-search'),
                'refresh' => __('Refresh', 'hybrid-search'),
                'export' => __('Export', 'hybrid-search'),
                'clearCache' => __('Clear Cache', 'hybrid-search'),
                'realTime' => __('Real-time', 'hybrid-search'),
                'autoRefresh' => __('Auto-refresh', 'hybrid-search'),
                'lastUpdated' => __('Last updated', 'hybrid-search'),
                'justNow' => __('Just now', 'hybrid-search'),
                'minutesAgo' => __('%d minutes ago', 'hybrid-search'),
                'hoursAgo' => __('%d hours ago', 'hybrid-search'),
                'daysAgo' => __('%d days ago', 'hybrid-search'),
            ],
            'settings' => [
                'autoRefresh' => true,
                'refreshInterval' => 30000, // 30 seconds
                'dateRange' => '30',
                'enableRealTime' => true,
            ]
        ]);

        ?>
        <div id="hybrid-search-analytics-dashboard" class="hs-analytics-dashboard">
            <!-- Dashboard Header -->
            <div class="hs-dashboard-header">
                <div class="hs-header-content">
                    <h1 class="hs-dashboard-title">
                        <span class="dashicons dashicons-chart-line"></span>
                        <?php _e('Search Analytics Dashboard', 'hybrid-search'); ?>
                    </h1>
                    <p class="hs-dashboard-subtitle">
                        <?php _e('Monitor search performance, user behavior, and system health', 'hybrid-search'); ?>
                    </p>
                </div>

                <div class="hs-header-actions">
                    <div class="hs-status-indicator">
                        <span class="hs-status-dot" id="connection-status"></span>
                        <span class="hs-status-text"><?php _e('Connected', 'hybrid-search'); ?></span>
                    </div>

                    <div class="hs-refresh-controls">
                        <label class="hs-toggle-switch">
                            <input type="checkbox" id="auto-refresh-toggle" checked>
                            <span class="hs-toggle-slider"></span>
                            <span class="hs-toggle-label"><?php _e('Auto-refresh', 'hybrid-search'); ?></span>
                        </label>

                        <button type="button" class="hs-btn hs-btn-secondary" id="manual-refresh">
                            <span class="dashicons dashicons-update"></span>
                            <span class="hs-btn-text"><?php _e('Refresh', 'hybrid-search'); ?></span>
                        </button>
                    </div>
                </div>
            </div>

            <!-- Dashboard Controls -->
            <div class="hs-dashboard-controls">
                <div class="hs-controls-grid">
                    <!-- Date Range Selector -->
                    <div class="hs-control-group">
                        <label for="date-range-selector" class="hs-control-label">
                            <span class="dashicons dashicons-calendar"></span>
                            <?php _e('Time Period', 'hybrid-search'); ?>
                        </label>
                        <select id="date-range-selector" class="hs-select">
                            <option value="1"><?php _e('Last 24 hours', 'hybrid-search'); ?></option>
                            <option value="7"><?php _e('Last 7 days', 'hybrid-search'); ?></option>
                            <option value="30" selected><?php _e('Last 30 days', 'hybrid-search'); ?></option>
                            <option value="90"><?php _e('Last 90 days', 'hybrid-search'); ?></option>
                            <option value="365"><?php _e('Last year', 'hybrid-search'); ?></option>
                            <option value="custom"><?php _e('Custom range', 'hybrid-search'); ?></option>
                        </select>
                    </div>

                    <!-- Custom Date Range -->
                    <div class="hs-control-group hs-custom-date-range" style="display: none;">
                        <label class="hs-control-label"><?php _e('Custom Dates', 'hybrid-search'); ?></label>
                        <div class="hs-date-inputs">
                            <input type="date" id="date-from" class="hs-date-input" max="<?php echo date('Y-m-d'); ?>">
                            <span class="hs-date-separator"><?php _e('to', 'hybrid-search'); ?></span>
                            <input type="date" id="date-to" class="hs-date-input" max="<?php echo date('Y-m-d'); ?>">
                        </div>
                    </div>

                    <!-- Quick Filters -->
                    <div class="hs-control-group">
                        <label class="hs-control-label">
                            <span class="dashicons dashicons-filter"></span>
                            <?php _e('Filters', 'hybrid-search'); ?>
                        </label>
                        <div class="hs-filter-tags">
                            <button type="button" class="hs-filter-tag" data-filter="successful">
                                <span class="dashicons dashicons-yes"></span>
                                <?php _e('Successful Only', 'hybrid-search'); ?>
                            </button>
                            <button type="button" class="hs-filter-tag" data-filter="failed">
                                <span class="dashicons dashicons-no"></span>
                                <?php _e('Failed Only', 'hybrid-search'); ?>
                            </button>
                            <button type="button" class="hs-filter-tag" data-filter="mobile">
                                <span class="dashicons dashicons-smartphone"></span>
                                <?php _e('Mobile', 'hybrid-search'); ?>
                            </button>
                            <button type="button" class="hs-filter-tag hs-filter-reset">
                                <span class="dashicons dashicons-dismiss"></span>
                                <?php _e('Clear All', 'hybrid-search'); ?>
                            </button>
                        </div>
                    </div>

                    <!-- Export Actions -->
                    <div class="hs-control-group">
                        <label class="hs-control-label">
                            <span class="dashicons dashicons-download"></span>
                            <?php _e('Export', 'hybrid-search'); ?>
                        </label>
                        <div class="hs-export-buttons">
                            <button type="button" class="hs-btn hs-btn-outline" id="export-csv">
                                <span class="dashicons dashicons-media-spreadsheet"></span>
                                CSV
                            </button>
                            <button type="button" class="hs-btn hs-btn-outline" id="export-pdf">
                                <span class="dashicons dashicons-pdf"></span>
                                PDF
                            </button>
                            <button type="button" class="hs-btn hs-btn-outline" id="export-json">
                                <span class="dashicons dashicons-editor-code"></span>
                                JSON
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Dashboard Content -->
            <div class="hs-dashboard-content">
                <!-- Key Metrics Overview -->
                <div class="hs-metrics-overview">
                    <div class="hs-metrics-grid" id="key-metrics">
                        <!-- Metrics will be loaded dynamically -->
                        <div class="hs-loading-state">
                            <div class="hs-loading-spinner"></div>
                            <p><?php _e('Loading metrics...', 'hybrid-search'); ?></p>
                        </div>
                    </div>
                </div>

                <!-- Charts Section -->
                <div class="hs-charts-section">
                    <div class="hs-section-header">
                        <h2><?php _e('Performance Trends', 'hybrid-search'); ?></h2>
                        <div class="hs-chart-controls">
                            <button type="button" class="hs-chart-toggle active" data-chart="volume">
                                <?php _e('Volume', 'hybrid-search'); ?>
                            </button>
                            <button type="button" class="hs-chart-toggle" data-chart="performance">
                                <?php _e('Performance', 'hybrid-search'); ?>
                            </button>
                            <button type="button" class="hs-chart-toggle" data-chart="devices">
                                <?php _e('Devices', 'hybrid-search'); ?>
                            </button>
                        </div>
                    </div>

                    <div class="hs-chart-container" id="main-chart-container">
                        <div class="hs-loading-state">
                            <div class="hs-loading-spinner"></div>
                            <p><?php _e('Loading chart data...', 'hybrid-search'); ?></p>
                        </div>
                    </div>
                </div>

                <!-- Insights & Recommendations -->
                <div class="hs-insights-section">
                    <div class="hs-section-header">
                        <h2><?php _e('Insights & Recommendations', 'hybrid-search'); ?></h2>
                    </div>

                    <div class="hs-insights-grid" id="insights-container">
                        <div class="hs-loading-state">
                            <div class="hs-loading-spinner"></div>
                            <p><?php _e('Analyzing performance...', 'hybrid-search'); ?></p>
                        </div>
                    </div>
                </div>

                <!-- Detailed Data Table -->
                <div class="hs-data-table-section">
                    <div class="hs-section-header">
                        <h2><?php _e('Search Activity Details', 'hybrid-search'); ?></h2>
                        <div class="hs-table-controls">
                            <div class="hs-search-box">
                                <span class="dashicons dashicons-search"></span>
                                <input type="text" id="table-search" placeholder="<?php _e('Search queries...', 'hybrid-search'); ?>">
                            </div>
                            <select id="table-sort" class="hs-select">
                                <option value="timestamp"><?php _e('Most Recent', 'hybrid-search'); ?></option>
                                <option value="response_time"><?php _e('Response Time', 'hybrid-search'); ?></option>
                                <option value="result_count"><?php _e('Result Count', 'hybrid-search'); ?></option>
                                <option value="query"><?php _e('Query (A-Z)', 'hybrid-search'); ?></option>
                            </select>
                        </div>
                    </div>

                    <div class="hs-table-container" id="data-table-container">
                        <div class="hs-loading-state">
                            <div class="hs-loading-spinner"></div>
                            <p><?php _e('Loading search data...', 'hybrid-search'); ?></p>
                        </div>
                    </div>

                    <div class="hs-pagination" id="table-pagination">
                        <!-- Pagination will be loaded dynamically -->
                    </div>
                </div>
            </div>

            <!-- Last Updated Info -->
            <div class="hs-dashboard-footer">
                <div class="hs-last-updated" id="last-updated">
                    <span class="dashicons dashicons-clock"></span>
                    <span><?php _e('Last updated:', 'hybrid-search'); ?> <span id="last-updated-time"><?php _e('Just now', 'hybrid-search'); ?></span></span>
                </div>
            </div>
        </div>
        <?php
    }
        
        <style>
        .hybrid-search-dashboard-controls {
            background: #fff;
            padding: 20px;
            margin: 20px 0;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
        }
        
        .dashboard-filters {
            display: flex;
            align-items: center;
            gap: 15px;
            flex-wrap: wrap;
        }
        
        .hybrid-search-metrics-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        
        .metric-card {
            background: #fff;
            padding: 20px;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
            text-align: center;
        }
        
        .metric-card h3 {
            margin: 0 0 10px 0;
            font-size: 14px;
            color: #666;
        }
        
        .metric-value {
            font-size: 32px;
            font-weight: bold;
            color: #0073aa;
            margin-bottom: 5px;
        }
        
        .metric-change {
            font-size: 12px;
            color: #666;
        }
        
        .metric-change.positive {
            color: #46b450;
        }
        
        .metric-change.negative {
            color: #dc3232;
        }
        
        .hybrid-search-charts {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(400px, 1fr));
            gap: 20px;
            margin: 20px 0;
        }
        
        .chart-container {
            background: #fff;
            padding: 20px;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
        }
        
        .chart-container h3 {
            margin: 0 0 15px 0;
        }
        
        .hybrid-search-analytics-table {
            background: #fff;
            padding: 20px;
            margin: 20px 0;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
        }
        
        .table-controls {
            margin-bottom: 15px;
            display: flex;
            gap: 10px;
            align-items: center;
        }
        
        .table-wrapper {
            overflow-x: auto;
        }
        
        .pagination-controls {
            margin-top: 15px;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .hybrid-search-insights {
            background: #fff;
            padding: 20px;
            margin: 20px 0;
            border: 1px solid #ccd0d4;
            border-radius: 4px;
        }
        
        .insight-item {
            padding: 10px;
            margin: 10px 0;
            border-left: 4px solid #0073aa;
            background: #f9f9f9;
        }
        
        .insight-item.warning {
            border-left-color: #ffb900;
        }
        
        .insight-item.error {
            border-left-color: #dc3232;
        }
        
        .loading {
            text-align: center;
            padding: 20px;
            color: #666;
        }
        
        .error {
            text-align: center;
            padding: 20px;
            color: #dc3232;
            background: #fff;
            border: 1px solid #dc3232;
            border-radius: 4px;
            margin: 10px 0;
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            let currentPage = 1;
            let currentFilters = {};
            
            // Initialize dashboard - load both metrics and table
            loadAnalyticsData();
            loadAnalyticsTable(); // Also load table on initial page load
            
            // Date range change handler
            $('#date-range').on('change', function() {
                if ($(this).val() === 'custom') {
                    $('#custom-date-range').show();
                } else {
                    $('#custom-date-range').hide();
                }
                loadAnalyticsData();
            });
            
            // Custom date range handlers
            $('#date-from, #date-to').on('change', function() {
                loadAnalyticsData();
            });
            
            // Refresh button - clear cache and reload
            $('#refresh-analytics').on('click', function() {
                // Clear any client-side cache if needed
                currentPage = 1;
                currentFilters = {};
                
                // Clear server-side cache via AJAX
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'hybrid_search_clear_analytics_cache',
                        nonce: '<?php echo wp_create_nonce('hybrid_search_analytics'); ?>'
                    },
                    success: function() {
                        console.log('Analytics cache cleared');
                    }
                });
                
                loadAnalyticsData();
                loadAnalyticsTable();
            });
            
            // Export button
            $('#export-analytics').on('click', function() {
                exportAnalytics();
            });
            
            // Table filters
            $('#search-filter').on('input', function() {
                currentFilters.search = $(this).val();
                currentPage = 1;
                loadAnalyticsTable();
            });
            
            $('#device-filter').on('change', function() {
                currentFilters.device = $(this).val();
                currentPage = 1;
                loadAnalyticsTable();
            });
            
            $('#clear-filters').on('click', function() {
                $('#search-filter').val('');
                $('#device-filter').val('');
                currentFilters = {};
                currentPage = 1;
                loadAnalyticsTable();
            });
            
            // Pagination
            $('#prev-page').on('click', function() {
                if (currentPage > 1) {
                    currentPage--;
                    loadAnalyticsTable();
                }
            });
            
            $('#next-page').on('click', function() {
                currentPage++;
                loadAnalyticsTable();
            });
            
            function loadAnalyticsData() {
                console.log('🔍 Analytics Dashboard: Loading analytics data...');
                const dateRange = $('#date-range').val();
                const dateFrom = $('#date-from').val();
                const dateTo = $('#date-to').val();
                
                console.log('🔍 Analytics Dashboard: Request params - range:', dateRange, 'from:', dateFrom, 'to:', dateTo);
                
                // Show loading indicator
                $('#metrics-content').html('<div class="loading">Loading metrics...</div>');
                $('#charts-content').html('<div class="loading">Loading charts...</div>');
                $('#insights-content').html('<div class="loading">Loading insights...</div>');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'hybrid_search_analytics_data',
                        date_range: dateRange,
                        date_from: dateFrom,
                        date_to: dateTo,
                        nonce: '<?php echo wp_create_nonce('hybrid_search_analytics'); ?>'
                    },
                    success: function(response) {
                        console.log('✅ Analytics Dashboard: AJAX success response:', response);
                        
                        if (response.success && response.data) {
                            console.log('✅ Analytics Dashboard: Response data:', response.data);
                            
                            if (response.data.metrics) {
                                console.log('📊 Analytics Dashboard: Updating metrics:', response.data.metrics);
                                updateMetrics(response.data.metrics);
                            } else {
                                console.warn('⚠️ Analytics Dashboard: No metrics in response');
                            }
                            
                            if (response.data.charts) {
                                console.log('📈 Analytics Dashboard: Updating charts:', response.data.charts);
                                updateCharts(response.data.charts);
                            } else {
                                console.warn('⚠️ Analytics Dashboard: No charts in response');
                            }
                            
                            if (response.data.insights) {
                                console.log('💡 Analytics Dashboard: Updating insights:', response.data.insights);
                                updateInsights(response.data.insights);
                            } else {
                                console.warn('⚠️ Analytics Dashboard: No insights in response');
                            }
                        } else {
                            console.error('❌ Analytics Dashboard: Response indicates failure:', response);
                            const errorMsg = response.data?.message || response.data?.debug || 'Unknown error';
                            alert('Failed to load analytics dashboard: ' + errorMsg);
                            $('#metrics-content').html('<div class="error">Error: ' + errorMsg + '</div>');
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('❌ Analytics Dashboard: AJAX error:', {
                            status: status,
                            error: error,
                            responseText: xhr.responseText,
                            statusCode: xhr.status
                        });
                        
                        let errorMsg = 'Failed to load analytics dashboard. ';
                        if (xhr.responseText) {
                            try {
                                const response = JSON.parse(xhr.responseText);
                                errorMsg += response.data?.message || error;
                            } catch (e) {
                                errorMsg += error;
                            }
                        } else {
                            errorMsg += error;
                        }
                        
                        alert(errorMsg);
                        $('#metrics-content').html('<div class="error">Error: ' + errorMsg + '</div>');
                    }
                });
            }
            
            function loadAnalyticsTable() {
                const dateRange = $('#date-range').val();
                const dateFrom = $('#date-from').val();
                const dateTo = $('#date-to').val();
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'hybrid_search_analytics_data',
                        type: 'table',
                        page: currentPage,
                        filters: currentFilters,
                        date_range: dateRange,
                        date_from: dateFrom,
                        date_to: dateTo,
                        nonce: '<?php echo wp_create_nonce('hybrid_search_analytics'); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            if (response.data.pagination) {
                                // Table data structure
                                updateAnalyticsTable(response.data);
                            } else {
                                // Dashboard data structure
                                updateMetrics(response.data.metrics);
                                updateCharts(response.data.charts);
                                updateInsights(response.data.insights);
                            }
                        } else {
                            console.error('Analytics error:', response.data);
                            alert('Failed to load analytics data: ' + (response.data.message || 'Unknown error'));
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Analytics AJAX error:', error);
                        alert('Failed to load analytics data. Please check your browser console for details.');
                    }
                });
            }
            
            function updateMetrics(metrics) {
                console.log('📊 Analytics Dashboard: updateMetrics called with:', metrics);
                
                if (!metrics || typeof metrics !== 'object') {
                    console.error('❌ Analytics Dashboard: Invalid metrics data:', metrics);
                    $('#metrics-content').html('<div class="error">Invalid metrics data received</div>');
                    return;
                }
                
                // Update metric values
                $('#total-searches').text(metrics.total_searches || 0);
                $('#successful-searches').text(metrics.successful_searches || 0);
                $('#zero-results').text(metrics.zero_results || 0);
                $('#avg-response-time').text((metrics.avg_response_time || 0) + 'ms');
                $('#ctr').text((metrics.ctr || 0) + '%');
                $('#unique-users').text(metrics.unique_users || 0);
                
                // Update change indicators
                updateChangeIndicator('#total-searches-change', metrics.total_searches_change || 0);
                updateChangeIndicator('#successful-searches-change', metrics.successful_searches_change || 0);
                updateChangeIndicator('#zero-results-change', metrics.zero_results_change || 0);
                updateChangeIndicator('#avg-response-time-change', metrics.avg_response_time_change || 0);
                updateChangeIndicator('#ctr-change', metrics.ctr_change || 0);
                updateChangeIndicator('#unique-users-change', metrics.unique_users_change || 0);
                
                console.log('✅ Analytics Dashboard: Metrics updated successfully');
            }
            
            function updateChangeIndicator(selector, change) {
                const $element = $(selector);
                if (change > 0) {
                    $element.text('+' + change + '%').addClass('positive').removeClass('negative');
                } else if (change < 0) {
                    $element.text(change + '%').addClass('negative').removeClass('positive');
                } else {
                    $element.text('0%').removeClass('positive negative');
                }
            }
            
            function updateCharts(charts) {
                // Update search volume chart
                if (charts.search_volume && typeof Chart !== 'undefined') {
                    updateSearchVolumeChart(charts.search_volume);
                }
                
                // Update top queries list
                updateTopQueriesList(charts.top_queries);
                
                // Update zero result queries list
                updateZeroResultQueriesList(charts.zero_result_queries);
                
                // Update device/browser chart
                if (charts.device_browser && typeof Chart !== 'undefined') {
                    updateDeviceBrowserChart(charts.device_browser);
                }
            }
            
            function updateSearchVolumeChart(data) {
                const ctx = document.getElementById('search-volume-chart').getContext('2d');
                new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: data.labels,
                        datasets: [{
                            label: 'Searches',
                            data: data.values,
                            borderColor: '#0073aa',
                            backgroundColor: 'rgba(0, 115, 170, 0.1)',
                            tension: 0.4
                        }]
                    },
                    options: {
                        responsive: true,
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            }
            
            function updateTopQueriesList(queries) {
                const $container = $('#top-queries-list');
                $container.empty();
                
                if (queries && queries.length > 0) {
                    queries.forEach(function(query, index) {
                        $container.append(`
                            <div class="query-item">
                                <span class="query-rank">${index + 1}</span>
                                <span class="query-text">${query.query}</span>
                                <span class="query-count">${query.count}</span>
                            </div>
                        `);
                    });
                } else {
                    $container.append('<p>No data available</p>');
                }
            }
            
            function updateZeroResultQueriesList(queries) {
                const $container = $('#zero-result-queries-list');
                $container.empty();
                
                if (queries && queries.length > 0) {
                    queries.forEach(function(query, index) {
                        $container.append(`
                            <div class="query-item">
                                <span class="query-rank">${index + 1}</span>
                                <span class="query-text">${query.query}</span>
                                <span class="query-count">${query.count}</span>
                            </div>
                        `);
                    });
                } else {
                    $container.append('<p>No zero result queries found</p>');
                }
            }
            
            function updateDeviceBrowserChart(data) {
                const ctx = document.getElementById('device-browser-chart').getContext('2d');
                new Chart(ctx, {
                    type: 'doughnut',
                    data: {
                        labels: data.labels,
                        datasets: [{
                            data: data.values,
                            backgroundColor: [
                                '#0073aa',
                                '#46b450',
                                '#ffb900',
                                '#dc3232',
                                '#826eb4'
                            ]
                        }]
                    },
                    options: {
                        responsive: true,
                        plugins: {
                            legend: {
                                position: 'bottom'
                            }
                        }
                    }
                });
            }
            
            function updateAnalyticsTable(data) {
                const $tbody = $('#analytics-table-body');
                $tbody.empty();
                
                // Handle both 'records' and 'data' keys for backward compatibility
                const records = data.records || data.data || [];
                
                if (records && records.length > 0) {
                    records.forEach(function(record) {
                        const timeTaken = record.time_taken ? (parseFloat(record.time_taken) * 1000).toFixed(2) + 'ms' : 'N/A';
                        $tbody.append(`
                            <tr>
                                <td>${escapeHtml(record.query || 'N/A')}</td>
                                <td>${record.result_count || 0}</td>
                                <td>${timeTaken}</td>
                                <td>${escapeHtml(record.device_type || 'N/A')}</td>
                                <td>${escapeHtml(record.browser_name || 'N/A')}</td>
                                <td>${formatDate(record.timestamp)}</td>
                                <td>
                                    <button class="button button-small" onclick="viewQueryDetails('${escapeHtml(record.query || '')}')">
                                        View Details
                                    </button>
                                </td>
                            </tr>
                        `);
                    });
                } else {
                    $tbody.append('<tr><td colspan="7">No analytics data available. Searches will appear here once users start searching.</td></tr>');
                }
                
                // Update pagination
                if (data.pagination) {
                    updatePagination(data.pagination);
                }
            }
            
            function escapeHtml(text) {
                const div = document.createElement('div');
                div.textContent = text;
                return div.innerHTML;
            }
            
            function formatDate(dateString) {
                if (!dateString) return 'N/A';
                const date = new Date(dateString);
                return date.toLocaleString();
            }
            
            function updatePagination(pagination) {
                $('#page-info').text(`Page ${pagination.current_page} of ${pagination.total_pages}`);
                $('#prev-page').prop('disabled', !pagination.has_prev);
                $('#next-page').prop('disabled', !pagination.has_next);
            }
            
            function updateInsights(insights) {
                const $container = $('#insights-content');
                $container.empty();
                
                if (insights && insights.length > 0) {
                    insights.forEach(function(insight) {
                        $container.append(`
                            <div class="insight-item ${insight.type}">
                                <strong>${insight.title}</strong>
                                <p>${insight.description}</p>
                                ${insight.recommendation ? `<p><em>Recommendation: ${insight.recommendation}</em></p>` : ''}
                            </div>
                        `);
                    });
                } else {
                    $container.append('<p>No insights available</p>');
                }
            }
            
            function exportAnalytics() {
                const dateRange = $('#date-range').val();
                const dateFrom = $('#date-from').val();
                const dateTo = $('#date-to').val();
                
                const form = $('<form>', {
                    method: 'POST',
                    action: ajaxurl
                });
                
                form.append($('<input>', {
                    type: 'hidden',
                    name: 'action',
                    value: 'hybrid_search_export_analytics'
                }));
                
                form.append($('<input>', {
                    type: 'hidden',
                    name: 'date_range',
                    value: dateRange
                }));
                
                form.append($('<input>', {
                    type: 'hidden',
                    name: 'date_from',
                    value: dateFrom
                }));
                
                form.append($('<input>', {
                    type: 'hidden',
                    name: 'date_to',
                    value: dateTo
                }));
                
                form.append($('<input>', {
                    type: 'hidden',
                    name: 'nonce',
                    value: '<?php echo wp_create_nonce('hybrid_search_export'); ?>'
                }));
                
                $('body').append(form);
                form.submit();
                form.remove();
            }
            
            // Global function for query details
            window.viewQueryDetails = function(query) {
                // Implement query details modal
                alert('Query details for: ' + query);
            };
        });
        </script>
        <?php
    }
    
    /**
     * Handle real-time analytics data
     */
    public function handleRealtimeAnalytics() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'hybrid_search_analytics')) {
            wp_send_json_error(['message' => 'Security check failed']);
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Insufficient permissions']);
            return;
        }

        try {
            $date_range = sanitize_text_field($_POST['date_range'] ?? '30');
            $date_from = sanitize_text_field($_POST['date_from'] ?? '');
            $date_to = sanitize_text_field($_POST['date_to'] ?? '');

            // Get real-time metrics
            $dates = $this->getDateRange($date_range, $date_from, $date_to);
            $metrics = $this->analytics_service->getMetrics($dates['from'], $dates['to']);

            wp_send_json_success([
                'metrics' => $metrics,
                'timestamp' => current_time('timestamp'),
                'last_updated' => current_time('mysql')
            ]);

        } catch (\Exception $e) {
            wp_send_json_error(['message' => $e->getMessage()]);
        }
    }

    /**
     * Handle analytics data AJAX request
     */
    public function handleAnalyticsData() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'hybrid_search_analytics')) {
            wp_send_json_error(['message' => 'Security check failed']);
            return;
        }

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Insufficient permissions']);
            return;
        }

        try {
            $date_range = sanitize_text_field($_POST['date_range'] ?? '30');
            $date_from = sanitize_text_field($_POST['date_from'] ?? '');
            $date_to = sanitize_text_field($_POST['date_to'] ?? '');
            $type = sanitize_text_field($_POST['type'] ?? 'dashboard');
            $filters = isset($_POST['filters']) ? json_decode(stripslashes($_POST['filters']), true) : [];
            $sort_by = sanitize_text_field($_POST['sort_by'] ?? 'timestamp');
            $sort_order = sanitize_text_field($_POST['sort_order'] ?? 'desc');

            if ($type === 'table') {
                $page = (int) ($_POST['page'] ?? 1);
                $data = $this->getAnalyticsTableData($page, $filters, $date_range, $date_from, $date_to, $sort_by, $sort_order);
            } else {
                $data = $this->getAnalyticsDashboardData($date_range, $date_from, $date_to, $filters);
            }

            wp_send_json_success($data);

        } catch (\Exception $e) {
            wp_send_json_error(['message' => $e->getMessage()]);
        }
    }
    
    /**
     * Get analytics dashboard data
     */
    private function getAnalyticsDashboardData($date_range, $date_from, $date_to, $filters = []) {
        error_log("Analytics Dashboard: getAnalyticsDashboardData called - range: {$date_range}, from: {$date_from}, to: {$date_to}");
        
        try {
            // Get date range
            $dates = $this->getDateRange($date_range, $date_from, $date_to);
            error_log("Analytics Dashboard: Date range calculated - from: {$dates['from']}, to: {$dates['to']}");
            
            // Clear cache before fetching to ensure fresh data
            $this->analytics_service->clearAnalyticsCaches();
            
            // Get metrics
            error_log("Analytics Dashboard: Fetching metrics...");
            $metrics = $this->analytics_service->getMetrics($dates['from'], $dates['to']);
            error_log("Analytics Dashboard: Metrics fetched - " . print_r($metrics, true));
            
            // Get charts data
            error_log("Analytics Dashboard: Fetching charts data...");
            $charts = [
                'search_volume' => $this->analytics_service->getSearchVolumeChart($dates['from'], $dates['to']),
                'top_queries' => $this->analytics_service->getTopQueries($dates['from'], $dates['to'], 10),
                'zero_result_queries' => $this->analytics_service->getZeroResultQueries($dates['from'], $dates['to'], 10),
                'device_browser' => $this->analytics_service->getDeviceBrowserDistribution($dates['from'], $dates['to'])
            ];
            error_log("Analytics Dashboard: Charts data fetched - search_volume: " . count($charts['search_volume']['labels'] ?? []) . " points");
            
            // Get insights
            error_log("Analytics Dashboard: Generating insights...");
            $insights = $this->generateInsights($metrics, $charts);
            error_log("Analytics Dashboard: Insights generated - " . count($insights) . " items");
            
            $result = [
                'metrics' => $metrics,
                'charts' => $charts,
                'insights' => $insights
            ];
            
            error_log("Analytics Dashboard: Dashboard data prepared successfully");
            return $result;
            
        } catch (\Exception $e) {
            error_log("Analytics Dashboard: Error in getAnalyticsDashboardData - " . $e->getMessage());
            error_log("Analytics Dashboard: Stack trace - " . $e->getTraceAsString());
            throw $e;
        }
    }
    
    /**
     * Get analytics table data
     */
    private function getAnalyticsTableData($page, $filters, $date_range, $date_from, $date_to, $sort_by = 'timestamp', $sort_order = 'desc') {
        $dates = $this->getDateRange($date_range, $date_from, $date_to);
        
        $args = [
            'page' => $page,
            'per_page' => 20,
            'date_from' => $dates['from'],
            'date_to' => $dates['to'],
            'sort_by' => $sort_by,
            'sort_order' => $sort_order
        ];
        
        // Add filters
        if (!empty($filters['search'])) {
            $args['search'] = $filters['search'];
        }
        if (!empty($filters['device'])) {
            $args['device_type'] = $filters['device'];
        }
        
        return $this->analytics_service->getAnalyticsData($args);
    }
    
    /**
     * Get date range
     */
    private function getDateRange($date_range, $date_from, $date_to) {
        if ($date_range === 'custom' && $date_from && $date_to) {
            return [
                'from' => $date_from . ' 00:00:00',
                'to' => $date_to . ' 23:59:59'
            ];
        }
        
        $days = (int) $date_range;
        if ($days < 1) {
            $days = 30; // Default to 30 days
        }
        
        // Ensure we include today's data by going to end of today
        return [
            'from' => date('Y-m-d 00:00:00', strtotime("-{$days} days")),
            'to' => date('Y-m-d 23:59:59') // Include all of today
        ];
    }
    
    /**
     * Generate insights
     */
    private function generateInsights($metrics, $charts) {
        $insights = [];
        
        // Ensure metrics is an array
        if (!is_array($metrics)) {
            error_log("Analytics Dashboard: generateInsights - metrics is not an array: " . gettype($metrics));
            return $insights;
        }
        
        $total_searches = $metrics['total_searches'] ?? 0;
        $zero_results = $metrics['zero_results'] ?? 0;
        $avg_response_time = $metrics['avg_response_time'] ?? 0;
        
        // Zero results insight
        if ($total_searches > 0 && $zero_results > 0) {
            $zero_result_rate = ($zero_results / $total_searches) * 100;
            if ($zero_result_rate > 20) {
                $insights[] = [
                    'type' => 'warning',
                    'title' => 'High Zero Result Rate',
                    'description' => sprintf('%.1f%% of searches return no results', $zero_result_rate),
                    'recommendation' => 'Consider adding more content or improving search relevance'
                ];
            }
        }
        
        // Response time insight
        if ($avg_response_time > 2000) {
            $insights[] = [
                'type' => 'warning',
                'title' => 'Slow Response Times',
                'description' => sprintf('Average response time is %.0fms', $avg_response_time),
                'recommendation' => 'Consider optimizing search queries or upgrading server resources'
            ];
        }
        
        // Popular queries insight
        if (!empty($charts['top_queries']) && is_array($charts['top_queries']) && count($charts['top_queries']) > 0) {
            $top_query = $charts['top_queries'][0];
            if (isset($top_query['query']) && isset($top_query['count'])) {
                $insights[] = [
                    'type' => 'info',
                    'title' => 'Most Popular Query',
                    'description' => sprintf('"%s" was searched %d times', $top_query['query'], $top_query['count']),
                    'recommendation' => 'Consider creating dedicated content for this topic'
                ];
            }
        }
        
        // If no insights, add a general one
        if (empty($insights) && $total_searches > 0) {
            $insights[] = [
                'type' => 'info',
                'title' => 'Search Analytics Active',
                'description' => sprintf('Tracking %d searches in the selected period', $total_searches),
                'recommendation' => 'Continue monitoring search patterns to improve user experience'
            ];
        } elseif (empty($insights)) {
            $insights[] = [
                'type' => 'info',
                'title' => 'No Search Data',
                'description' => 'No searches found in the selected period',
                'recommendation' => 'Start using the search feature to generate analytics data'
            ];
        }
        
        return $insights;
    }
    
    /**
     * Handle clear cache AJAX request
     */
    public function handleClearCache() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'] ?? '', 'hybrid_search_analytics')) {
            wp_send_json_error(['message' => 'Security check failed']);
            return;
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Insufficient permissions']);
            return;
        }
        
        try {
            $this->analytics_service->clearAnalyticsCaches();
            wp_send_json_success(['message' => 'Analytics cache cleared']);
        } catch (\Exception $e) {
            wp_send_json_error(['message' => $e->getMessage()]);
        }
    }
    
    /**
     * Handle export analytics AJAX request
     */
    public function handleExportAnalytics() {
        // Verify nonce
        if (!wp_verify_nonce($_POST['nonce'], 'hybrid_search_export')) {
            wp_die('Security check failed');
        }
        
        // Check permissions
        if (!current_user_can('manage_options')) {
            wp_die('Insufficient permissions');
        }
        
        $date_range = sanitize_text_field($_POST['date_range'] ?? '30');
        $date_from = sanitize_text_field($_POST['date_from'] ?? '');
        $date_to = sanitize_text_field($_POST['date_to'] ?? '');
        
        $dates = $this->getDateRange($date_range, $date_from, $date_to);
        
        // Get all analytics data
        $args = [
            'page' => 1,
            'per_page' => 10000, // Large number to get all data
            'date_from' => $dates['from'],
            'date_to' => $dates['to']
        ];
        
        $data = $this->analytics_service->getAnalyticsData($args);
        
        // Generate CSV
        $filename = 'hybrid-search-analytics-' . date('Y-m-d') . '.csv';
        
        header('Content-Type: text/csv');
        header('Content-Disposition: attachment; filename="' . $filename . '"');
        
        $output = fopen('php://output', 'w');
        
        // CSV headers
        fputcsv($output, [
            'Query',
            'Result Count',
            'Time Taken (ms)',
            'Has Results',
            'Device Type',
            'Browser Name',
            'Timestamp',
            'IP Address',
            'Session ID'
        ]);
        
        // CSV data
        foreach ($data['records'] as $record) {
            fputcsv($output, [
                $record['query'],
                $record['result_count'],
                $record['time_taken'],
                $record['has_results'] ? 'Yes' : 'No',
                $record['device_type'],
                $record['browser_name'],
                $record['timestamp'],
                $record['ip_address'],
                $record['session_id']
            ]);
        }
        
        fclose($output);
        exit;
    }
}





