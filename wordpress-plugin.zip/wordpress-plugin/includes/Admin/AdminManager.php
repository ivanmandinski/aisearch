<?php
/**
 * Admin Manager
 * 
 * Handles all admin interface functionality including menus, pages, and admin-specific features.
 * 
 * @package HybridSearch\Admin
 * @since 2.0.0
 */

namespace HybridSearch\Admin;

use HybridSearch\Services\AnalyticsService;
use HybridSearch\Services\CTRService;

class AdminManager {
    
    /**
     * Analytics service
     * 
     * @var AnalyticsService
     */
    private $analytics_service;
    
    /**
     * CTR service
     * 
     * @var CTRService
     */
    private $ctr_service;
    
    /**
     * Constructor
     * 
     * @param AnalyticsService $analytics_service
     * @param CTRService $ctr_service
     */
    public function __construct(AnalyticsService $analytics_service, CTRService $ctr_service) {
        $this->analytics_service = $analytics_service;
        $this->ctr_service = $ctr_service;
    }
    
    /**
     * Register WordPress hooks
     * 
     * @since 2.0.0
     */
    public function registerHooks() {
        add_action('admin_menu', [$this, 'addAdminMenu']);
        add_action('admin_enqueue_scripts', [$this, 'enqueueAssets']);
        add_action('admin_init', [$this, 'registerSettings']);
        add_action('wp_ajax_hybrid_search_test_connection', [$this, 'ajaxTestConnection']);
        add_action('wp_ajax_hybrid_search_check_status', [$this, 'ajaxCheckStatus']);
        add_action('wp_ajax_hybrid_search_dashboard_data', [$this, 'ajaxDashboardData']);
        add_action('wp_ajax_reindex_content', [$this, 'ajaxReindexContent']);
        add_action('wp_ajax_clear_search_cache', [$this, 'ajaxClearSearchCache']);
    }
    
    /**
     * Add admin menu
     * 
     * @since 2.0.0
     */
    public function addAdminMenu() {
        // Main menu page
        add_menu_page(
            'Hybrid Search',
            'Hybrid Search',
            'manage_options',
            'hybrid-search',
            [$this, 'dashboardPage'],
            'dashicons-search',
            30
        );
        
        // Submenu pages
        add_submenu_page(
            'hybrid-search',
            'Dashboard',
            'Dashboard',
            'manage_options',
            'hybrid-search',
            [$this, 'dashboardPage']
        );
        
        add_submenu_page(
            'hybrid-search',
            'Settings',
            'Settings',
            'manage_options',
            'hybrid-search-settings',
            [$this, 'settingsPage']
        );
        
        add_submenu_page(
            'hybrid-search',
            'Analytics',
            'Analytics',
            'manage_options',
            'hybrid-search-analytics',
            [$this, 'analyticsPage']
        );
        
        add_submenu_page(
            'hybrid-search',
            'Diagnostics',
            'Diagnostics',
            'manage_options',
            'hybrid-search-diagnostics',
            [$this, 'diagnosticsPage']
        );
    }
    
    /**
     * Register plugin settings
     * 
     * @since 2.0.0
     */
    public function registerSettings() {
        // Register settings group with enhanced sanitization
        register_setting('hybrid_search_settings', 'hybrid_search_api_url', [
            'type' => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default' => ''
        ]);
        
        register_setting('hybrid_search_settings', 'hybrid_search_api_key', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => ''
        ]);
        register_setting('hybrid_search_settings', 'hybrid_search_source_api_url', [
            'type' => 'string',
            'sanitize_callback' => 'esc_url_raw',
            'default' => ''
        ]);
        register_setting('hybrid_search_settings', 'hybrid_search_source_username', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => ''
        ]);
        register_setting('hybrid_search_settings', 'hybrid_search_source_password', [
            'type' => 'string',
            'sanitize_callback' => 'sanitize_text_field',
            'default' => ''
        ]);
        
        register_setting('hybrid_search_settings', 'hybrid_search_enabled', [
            'type' => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => false
        ]);
        
        register_setting('hybrid_search_settings', 'hybrid_search_max_results', [
            'type' => 'integer',
            'sanitize_callback' => function($value) {
                return max(1, min(100, intval($value)));
            },
            'default' => 10
        ]);
        
        register_setting('hybrid_search_settings', 'hybrid_search_show_ai_answer', [
            'type' => 'boolean',
            'sanitize_callback' => 'rest_sanitize_boolean',
            'default' => false
        ]);
        
        register_setting('hybrid_search_settings', 'hybrid_search_ai_instructions', [
            'type' => 'string',
            'sanitize_callback' => [$this, 'sanitizeAIInstructions'],
            'default' => ''
        ]);
        register_setting('hybrid_search_settings', 'hybrid_search_strict_ai_answer_mode', [
            'type' => 'boolean',
            'default' => true,
            'sanitize_callback' => 'rest_sanitize_boolean'
        ]);
        register_setting('hybrid_search_settings', 'hybrid_search_index_post_types');
        register_setting('hybrid_search_settings', 'hybrid_search_post_type_priority', [
            'type' => 'array',
            'sanitize_callback' => function($value) {
                if (!is_array($value)) {
                    return [];
                }
                // Remove duplicates and re-index
                return array_values(array_unique(array_filter($value)));
            },
            'default' => ['post', 'page']
        ]);
        register_setting('hybrid_search_settings', 'hybrid_search_auto_index_enabled');
        
        // AI Reranking settings
        register_setting('hybrid_search_settings', 'hybrid_search_ai_reranking_enabled', [
            'type' => 'boolean',
            'default' => true,
            'sanitize_callback' => [$this, 'sanitizeAIRerankingEnabled']
        ]);
        
        register_setting('hybrid_search_settings', 'hybrid_search_ai_weight', [
            'type' => 'integer',
            'default' => 70,
            'sanitize_callback' => function($value) {
                return max(0, min(100, intval($value)));
            }
        ]);
        
        register_setting('hybrid_search_settings', 'hybrid_search_ai_reranking_instructions', [
            'type' => 'string',
            'default' => '',
            'sanitize_callback' => [$this, 'sanitizeAIInstructions']
        ]);
    }
    
    /**
     * Dashboard page
     * 
     * @since 2.0.0
     */
    public function dashboardPage() {
        // Enqueue required assets
        wp_enqueue_style('hybrid-search-admin', plugins_url('assets/admin-dashboard.css', dirname(__FILE__, 2)), [], HYBRID_SEARCH_VERSION);
        wp_enqueue_script('chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', [], '4.4.0', true);
        wp_enqueue_script('hybrid-search-admin', plugins_url('assets/admin-dashboard.js', dirname(__FILE__, 2)), ['jquery', 'chart-js'], HYBRID_SEARCH_VERSION, true);

        // Localize script with data
        wp_localize_script('hybrid-search-admin', 'hybridSearchAdmin', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('hybrid-search-ajax'),
            'apiUrl' => get_option('hybrid_search_api_url', ''),
            'strings' => [
                'loading' => __('Loading...', 'hybrid-search'),
                'error' => __('Error loading data', 'hybrid-search'),
                'connected' => __('Connected', 'hybrid-search'),
                'disconnected' => __('Disconnected', 'hybrid-search'),
                'testing' => __('Testing...', 'hybrid-search'),
                'connectionOk' => __('Connection OK', 'hybrid-search'),
                'connectionFailed' => __('Connection Failed', 'hybrid-search'),
                'reindexing' => __('Reindexing...', 'hybrid-search'),
                'success' => __('Success!', 'hybrid-search'),
                'error' => __('Error', 'hybrid-search'),
                'failed' => __('Failed', 'hybrid-search'),
                'clearing' => __('Clearing...', 'hybrid-search'),
                'cleared' => __('Cleared!', 'hybrid-search'),
                'lastUpdated' => __('Last updated', 'hybrid-search'),
                'justNow' => __('Just now', 'hybrid-search'),
                'minutesAgo' => __('%d minutes ago', 'hybrid-search'),
                'hoursAgo' => __('%d hours ago', 'hybrid-search'),
                'daysAgo' => __('%d days ago', 'hybrid-search'),
                'rankIndexLoading' => __('Calculating rank index...', 'hybrid-search'),
                'rankIndexUnavailable' => __('Rank index unavailable', 'hybrid-search'),
                'rankIndexReady' => __('Rank index ready', 'hybrid-search'),
                'rankIndexPartial' => __('Rank index partially built', 'hybrid-search'),
                'indexedLabel' => __('indexed', 'hybrid-search'),
                'vectorsLabel' => __('vectors', 'hybrid-search'),
            ],
            'settings' => [
                'autoRefresh' => true,
                'refreshInterval' => 30000,
                'defaultRangeDays' => 30,
                'activityLimit' => 10,
            ]
        ]);

        ?>
        <div id="hybrid-search-admin-dashboard" class="hs-admin-dashboard">
            <!-- Dashboard Header -->
            <div class="hs-admin-header">
                <div class="hs-header-content">
                    <h1 class="hs-admin-title">
                        <span class="dashicons dashicons-dashboard"></span>
                        <?php _e('Hybrid Search Dashboard', 'hybrid-search'); ?>
                    </h1>
                    <p class="hs-admin-subtitle">
                        <?php _e('Monitor your search system performance and manage content indexing', 'hybrid-search'); ?>
                    </p>
                    </div>
                    
                <div class="hs-header-status">
                    <div class="hs-status-item">
                        <div class="hs-status-indicator">
                            <span class="hs-status-dot" id="api-status-dot"></span>
                            <span class="hs-status-label"><?php _e('API Status', 'hybrid-search'); ?></span>
                        </div>
                        <span class="hs-status-text" id="api-status-text"><?php _e('Checking...', 'hybrid-search'); ?></span>
                    </div>
                    
                    <div class="hs-status-item hs-rank-status" id="rank-index-status">
                        <div class="hs-status-indicator">
                            <span class="hs-status-label"><?php _e('Rank Index', 'hybrid-search'); ?></span>
                        </div>
                        <div class="hs-rank-progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" aria-live="polite">
                            <div class="hs-rank-progress-fill" id="rank-index-progress"></div>
                        </div>
                        <div class="hs-rank-progress-meta">
                            <span class="hs-rank-text" id="rank-index-text"><?php _e('Calculating...', 'hybrid-search'); ?></span>
                            <span class="hs-rank-meta" id="rank-index-meta"></span>
                        </div>
                    </div>
                    
                    <div class="hs-last-updated">
                        <span class="dashicons dashicons-clock"></span>
                        <span><?php _e('Last updated:', 'hybrid-search'); ?> <span id="last-updated-time"><?php _e('Just now', 'hybrid-search'); ?></span></span>
                    </div>
                </div>
                    </div>
                    
            <!-- Quick Stats Overview -->
            <div class="hs-stats-overview">
                <div class="hs-stats-grid" id="quick-stats">
                    <!-- Stats will be loaded dynamically -->
                    <div class="hs-loading-state">
                        <div class="hs-loading-spinner"></div>
                        <p><?php _e('Loading statistics...', 'hybrid-search'); ?></p>
                    </div>
                    </div>
                </div>
                
            <!-- Main Dashboard Content -->
            <div class="hs-dashboard-content">
                <div class="hs-content-grid">
                    <!-- Performance Chart -->
                    <div class="hs-chart-section">
                        <div class="hs-section-header">
                            <h2><?php _e('Performance Overview', 'hybrid-search'); ?></h2>
                            <div class="hs-chart-controls">
                                <button type="button" class="hs-chart-toggle active" data-chart="searches">
                                    <?php _e('Searches', 'hybrid-search'); ?>
                                </button>
                                <button type="button" class="hs-chart-toggle" data-chart="performance">
                                    <?php _e('Performance', 'hybrid-search'); ?>
                                </button>
                                    </div>
                                </div>

                        <div class="hs-chart-container" id="performance-chart">
                            <div class="hs-loading-state">
                                <div class="hs-loading-spinner"></div>
                                <p><?php _e('Loading chart data...', 'hybrid-search'); ?></p>
                            </div>
                    </div>
                </div>
                
                <!-- Quick Actions -->
                    <div class="hs-actions-section">
                        <div class="hs-section-header">
                            <h2><?php _e('Quick Actions', 'hybrid-search'); ?></h2>
                        </div>

                        <div class="hs-actions-grid">
                            <button type="button" class="hs-action-card" id="test-api-connection">
                                <div class="hs-action-icon">
                            <span class="dashicons dashicons-admin-tools"></span>
                                </div>
                                <div class="hs-action-content">
                                    <h3><?php _e('Test API Connection', 'hybrid-search'); ?></h3>
                                    <p><?php _e('Verify your FastAPI backend is responding', 'hybrid-search'); ?></p>
                                </div>
                                <div class="hs-action-status" id="api-test-status">
                                    <span class="dashicons dashicons-clock"></span>
                                </div>
                        </button>
                        
                            <button type="button" class="hs-action-card" id="reindex-content">
                                <div class="hs-action-icon">
                            <span class="dashicons dashicons-update"></span>
                                </div>
                                <div class="hs-action-content">
                                    <h3><?php _e('Reindex Content', 'hybrid-search'); ?></h3>
                                    <p><?php _e('Update search index with latest content', 'hybrid-search'); ?></p>
                                </div>
                                <div class="hs-action-status">
                                    <span class="dashicons dashicons-clock"></span>
                                </div>
                        </button>
                        
                            <button type="button" class="hs-action-card" id="clear-cache">
                                <div class="hs-action-icon">
                            <span class="dashicons dashicons-trash"></span>
                                </div>
                                <div class="hs-action-content">
                                    <h3><?php _e('Clear Cache', 'hybrid-search'); ?></h3>
                                    <p><?php _e('Remove cached search results', 'hybrid-search'); ?></p>
                                </div>
                                <div class="hs-action-status">
                                    <span class="dashicons dashicons-clock"></span>
                                </div>
                        </button>

                            <a href="<?php echo admin_url('admin.php?page=hybrid-search-analytics'); ?>" class="hs-action-card">
                                <div class="hs-action-icon">
                                    <span class="dashicons dashicons-chart-line"></span>
                    </div>
                                <div class="hs-action-content">
                                    <h3><?php _e('View Analytics', 'hybrid-search'); ?></h3>
                                    <p><?php _e('Detailed search analytics and insights', 'hybrid-search'); ?></p>
                </div>
                                <div class="hs-action-arrow">
                                    <span class="dashicons dashicons-arrow-right-alt"></span>
                                </div>
                            </a>
                        </div>
            </div>
        </div>
        
                <!-- Recent Activity -->
                <div class="hs-activity-section">
                    <div class="hs-section-header">
                        <h2><?php _e('Recent Activity', 'hybrid-search'); ?></h2>
                        <a href="<?php echo admin_url('admin.php?page=hybrid-search-analytics'); ?>" class="hs-view-all-link">
                            <?php _e('View All Analytics', 'hybrid-search'); ?>
                            <span class="dashicons dashicons-arrow-right-alt"></span>
                        </a>
                    </div>

                    <div class="hs-activity-container" id="recent-activity">
                        <div class="hs-loading-state">
                            <div class="hs-loading-spinner"></div>
                            <p><?php _e('Loading recent activity...', 'hybrid-search'); ?></p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- System Health -->
            <div class="hs-health-section">
                <div class="hs-section-header">
                    <h2><?php _e('System Health', 'hybrid-search'); ?></h2>
                </div>

                <div class="hs-health-grid" id="system-health">
                    <div class="hs-loading-state">
                        <div class="hs-loading-spinner"></div>
                        <p><?php _e('Checking system health...', 'hybrid-search'); ?></p>
                    </div>
                </div>
            </div>
        </div>
        <?php
    }
    
    /**
     * Settings page
     * 
     * @since 2.0.0
     */
    public function settingsPage() {
        $api_url = get_option('hybrid_search_api_url', '');
        $api_key = get_option('hybrid_search_api_key', '');
        
        // Try to get API status (this will be updated via AJAX)
        $api_status = get_transient('hybrid_search_api_status');
        if ($api_status === false) {
            $api_status = ['status' => 'unknown', 'message' => 'Checking...'];
        }
        
        ?>
        <div class="wrap">
            <!-- Modern Header with Status -->
            <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px 40px; margin: -20px -20px 30px -20px; border-radius: 8px; box-shadow: 0 4px 15px rgba(0,0,0,0.1);">
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 20px;">
                    <div>
                        <h1 style="color: white; margin: 0 0 10px 0; font-size: 28px;">⚡ Hybrid Search Settings</h1>
                        <p style="margin: 0; color: rgba(255,255,255,0.9); font-size: 14px;">
                            Configure AI-powered search with semantic understanding and intelligent reranking
                        </p>
                    </div>
                    <div style="background: rgba(255,255,255,0.15); backdrop-filter: blur(10px); padding: 15px 25px; border-radius: 8px; min-width: 200px;">
                        <div style="font-size: 12px; opacity: 0.9; margin-bottom: 5px;">Connection Status</div>
                        <div id="api-status-indicator" style="font-size: 24px; font-weight: bold; display: flex; align-items: center; gap: 10px;">
                            <span id="status-icon">⏳</span>
                            <span id="status-text">Checking...</span>
                        </div>
                        <button id="test-connection-btn" style="margin-top: 10px; padding: 8px 16px; background: white; color: #667eea; border: none; border-radius: 4px; cursor: pointer; font-weight: 600; font-size: 12px;">
                            🔄 Test Connection
                        </button>
                    </div>
                </div>
            </div>

            <!-- Tab Navigation -->
            <div style="margin-bottom: 20px; border-bottom: 2px solid #e0e0e0;">
                <div class="nav-tab-wrapper" style="display: flex; gap: 5px; flex-wrap: wrap;">
                    <a href="#" class="nav-tab nav-tab-active" data-tab="api">🔗 API Configuration</a>
                    <a href="#" class="nav-tab" data-tab="ai">🤖 AI Settings</a>
                    <a href="#" class="nav-tab" data-tab="indexing">📚 Indexing</a>
                </div>
            </div>

            <form method="post" action="options.php" id="hybrid-search-settings-form">
                <?php
                settings_fields('hybrid_search_settings');
                do_settings_sections('hybrid_search_settings');
                ?>
                
                <!-- API Configuration Tab -->
                <div id="tab-api" class="tab-content active">
                <table class="form-table">
                    <tr>
                        <th scope="row">API URL</th>
                        <td>
                            <input type="url" name="hybrid_search_api_url" value="<?php echo esc_attr(get_option('hybrid_search_api_url')); ?>" class="regular-text" />
                            <p class="description">Enter your hybrid search API endpoint URL.</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">API Key</th>
                        <td>
                            <input type="password" name="hybrid_search_api_key" value="<?php echo esc_attr(get_option('hybrid_search_api_key')); ?>" class="regular-text" />
                            <p class="description">Enter your API authentication key.</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Enable Hybrid Search</th>
                        <td>
                            <input type="checkbox" name="hybrid_search_enabled" value="1" <?php checked(get_option('hybrid_search_enabled'), 1); ?> />
                            <p class="description">Enable the hybrid search functionality.</p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Max Results</th>
                        <td>
                            <input type="number" name="hybrid_search_max_results" value="<?php echo esc_attr(get_option('hybrid_search_max_results', 10)); ?>" min="1" max="100" />
                            <p class="description">Maximum number of results to return per search.</p>
                        </td>
                    </tr>
                </table>
                </div>
                
                <!-- AI Settings Tab -->
                <div id="tab-ai" class="tab-content" style="display: none;">
                    <div style="background: #f0f6fc; padding: 20px; border-radius: 8px; border-left: 4px solid #667eea; margin-bottom: 20px;">
                        <h2 style="margin-top: 0;">🤖 AI-Powered Search Settings</h2>
                        <p style="margin-bottom: 0; color: #555;">Configure how AI enhances your search results with semantic understanding and intelligent reranking.</p>
                                        </div>
                    
                <table class="form-table">
                    <tr>
                        <th scope="row">Enable AI Answers</th>
                        <td>
                            <input type="checkbox" name="hybrid_search_show_ai_answer" value="1" <?php checked(get_option('hybrid_search_show_ai_answer'), 1); ?> />
                            <p class="description">
                                <strong>Enable AI-generated answers for search queries.</strong><br>
                                When enabled, the system will request AI answers from the search API and display them at the top of search results.<br>
                                <em>Note: This may increase search response time as AI answers require additional processing.</em>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Strict AI Answer Mode</th>
                        <td>
                            <input type="checkbox" name="hybrid_search_strict_ai_answer_mode" value="1" <?php checked(get_option('hybrid_search_strict_ai_answer_mode', true), 1); ?> />
                            <p class="description">
                                <strong>Enable strict mode for AI answers.</strong><br>
                                When enabled, AI answers will ONLY use information from search results and indexed content.<br>
                                <em>This prevents the AI from adding external knowledge not present in your content.</em>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">AI Answer Instructions</th>
                        <td>
                            <textarea name="hybrid_search_ai_instructions" rows="6" cols="60" class="large-text" placeholder="Enter custom instructions for AI answer generation...

Examples:
- 'Provide concise, helpful answers based on the search results'
- 'Focus on technical details and practical applications'
- 'Answer in a friendly, conversational tone'
- 'Include relevant examples and use cases'

Leave empty for default behavior."><?php echo esc_textarea(get_option('hybrid_search_ai_instructions')); ?></textarea>
                            <p class="description">
                                <strong>Custom instructions for AI answer generation.</strong><br>
                                These instructions will guide how the AI generates answers for search queries.<br>
                                <em>Leave empty to use default AI behavior.</em>
                            </p>
                        </td>
                    </tr>
                    
                    <!-- AI RERANKING SECTION -->
                    <tr>
                        <td colspan="2">
                            <h2 style="margin-top: 30px; padding-top: 30px; border-top: 2px solid #e0e0e0;">
                                🤖 AI-Powered Search Reranking
                            </h2>
                            <p style="font-size: 14px; color: #666; margin-bottom: 20px;">
                                Use AI to intelligently reorder search results based on semantic relevance and user intent, going beyond simple keyword matching.
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Enable AI Reranking</th>
                        <td>
                            <label>
                                <input type="checkbox" 
                                       name="hybrid_search_ai_reranking_enabled" 
                                       id="ai-reranking-enabled"
                                       value="1" 
                                       <?php checked(get_option('hybrid_search_ai_reranking_enabled', true), 1); ?> />
                                <strong>Use AI to intelligently rerank search results</strong>
                            </label>
                            <div style="margin-top: 15px; padding: 15px; background: #f0f6fc; border-left: 4px solid #667eea; border-radius: 4px;">
                                <p style="margin: 5px 0; font-size: 13px; color: #0066cc;">
                                    <strong>✨ How It Works:</strong><br>
                                    1. TF-IDF finds initial candidates (fast keyword matching)<br>
                                    2. AI analyzes top results for semantic relevance<br>
                                    3. Results are reordered by understanding, not just keywords<br>
                                    4. You get smarter, more relevant search results!
                                </p>
                            </div>
                            <p class="description" style="margin-top: 10px;">
                                When enabled, search results are reordered based on semantic understanding and user intent.<br>
                                <strong>Performance:</strong> Adds ~1-2 seconds to search time<br>
                                <strong>Cost:</strong> ~$0.15 per 1,000 searches (very affordable with Cerebras)<br>
                                <em>Recommended: Keep enabled for best search quality.</em>
                            </p>
                        </td>
                    </tr>
                    
                    <tr class="ai-reranking-setting">
                        <th scope="row">AI Reranking Weight</th>
                        <td>
                            <div style="display: flex; align-items: center; gap: 15px; margin-bottom: 10px;">
                                <label style="min-width: 120px; text-align: center;">
                                    <strong>Keyword Matching</strong><br>
                                    <small style="color: #666;">TF-IDF</small>
                                </label>
                                
                                <input type="range" 
                                       name="hybrid_search_ai_weight" 
                                       id="ai-weight-slider"
                                       min="0" 
                                       max="100" 
                                       value="<?php echo esc_attr(get_option('hybrid_search_ai_weight', 70)); ?>" 
                                       style="flex: 1; min-width: 300px;"
                                       oninput="updateAIWeightDisplay(this.value)" />
                                
                                <label style="min-width: 120px; text-align: center;">
                                    <strong>AI Understanding</strong><br>
                                    <small style="color: #666;">Semantic</small>
                                </label>
                            </div>
                            
                            <div style="margin-top: 15px; padding: 15px; background: #f0f6fc; border-left: 4px solid #667eea; border-radius: 4px;">
                                <div style="font-size: 18px; font-weight: 600; color: #667eea; margin-bottom: 8px;">
                                    Current Balance: 
                                    <span id="tfidf-percent"><?php echo 100 - get_option('hybrid_search_ai_weight', 70); ?>%</span> 
                                    TF-IDF + 
                                    <span id="ai-percent"><?php echo get_option('hybrid_search_ai_weight', 70); ?>%</span> 
                                    AI
                                </div>
                                
                                <div id="weight-description" style="font-size: 14px; color: #555;"></div>
                            </div>
                            
                            <p class="description" style="margin-top: 15px;">
                                <strong>How to choose:</strong><br>
                                • <strong>0-30%:</strong> Mostly keyword matching (fast, traditional search)<br>
                                • <strong>40-60%:</strong> Balanced approach (keywords + AI)<br>
                                • <strong>70-80%:</strong> Mostly AI (<span style="color: #667eea; font-weight: 600;">✓ Recommended</span> - best results)<br>
                                • <strong>90-100%:</strong> Pure AI semantic ranking (slowest but smartest)<br>
                            </p>
                            
                            <style>
                            #ai-weight-slider {
                                -webkit-appearance: none;
                                appearance: none;
                                height: 8px;
                                background: linear-gradient(to right, #3b82f6 0%, #667eea 100%);
                                border-radius: 4px;
                                outline: none;
                            }
                            
                            #ai-weight-slider::-webkit-slider-thumb {
                                -webkit-appearance: none;
                                appearance: none;
                                width: 24px;
                                height: 24px;
                                background: white;
                                border: 3px solid #667eea;
                                border-radius: 50%;
                                cursor: pointer;
                                box-shadow: 0 2px 8px rgba(0,0,0,0.2);
                            }
                            
                            #ai-weight-slider::-moz-range-thumb {
                                width: 24px;
                                height: 24px;
                                background: white;
                                border: 3px solid #667eea;
                                border-radius: 50%;
                                cursor: pointer;
                                box-shadow: 0 2px 8px rgba(0,0,0,0.2);
                            }
                            </style>
                            
                            <script>
                            function updateAIWeightDisplay(value) {
                                const aiWeight = parseInt(value);
                                const tfidfWeight = 100 - aiWeight;
                                
                                document.getElementById('ai-percent').textContent = aiWeight + '%';
                                document.getElementById('tfidf-percent').textContent = tfidfWeight + '%';
                                
                                const description = document.getElementById('weight-description');
                                
                                if (aiWeight <= 30) {
                                    description.innerHTML = '⚡ <strong>Fast & Traditional:</strong> Relies mostly on keyword matching. Good for exact phrase searches.';
                                } else if (aiWeight <= 60) {
                                    description.innerHTML = '⚖️ <strong>Balanced:</strong> Combines keyword precision with AI understanding. Good all-around choice.';
                                } else if (aiWeight <= 80) {
                                    description.innerHTML = '🎯 <strong>AI-Focused (Recommended):</strong> Prioritizes semantic relevance. Best for natural language queries.';
                                } else {
                                    description.innerHTML = '🤖 <strong>Pure AI:</strong> Maximum semantic understanding. Best for complex queries and user intent.';
                                }
                            }
                            
                            document.addEventListener('DOMContentLoaded', function() {
                                updateAIWeightDisplay(<?php echo get_option('hybrid_search_ai_weight', 70); ?>);
                                
                                const enableCheckbox = document.getElementById('ai-reranking-enabled');
                                const aiSettings = document.querySelectorAll('.ai-reranking-setting');
                                
                                function toggleAISettings() {
                                    aiSettings.forEach(setting => {
                                        setting.style.display = enableCheckbox.checked ? 'table-row' : 'none';
                                    });
                                }
                                
                                if (enableCheckbox) {
                                    enableCheckbox.addEventListener('change', toggleAISettings);
                                    toggleAISettings();
                                }
                            });
                            </script>
                        </td>
                    </tr>
                    
                    <tr class="ai-reranking-setting">
                        <th scope="row">
                            AI Reranking Instructions
                            <br>
                            <small style="font-weight: normal; color: #666;">Custom guidance for AI</small>
                        </th>
                        <td>
                            <textarea name="hybrid_search_ai_reranking_instructions" 
                                      rows="8" 
                                      cols="60" 
                                      class="large-text code" 
                                      placeholder="Enter custom instructions to guide how AI reranks results...

Examples:
• Prioritize service pages over blog posts when users search for solutions
• For 'how to' queries, rank actionable step-by-step content highest
• Boost technical documentation for developer-focused queries
• Consider content freshness for time-sensitive topics

Leave empty to use default AI behavior."
                                      style="font-family: 'Courier New', monospace; font-size: 13px; line-height: 1.6;"><?php echo esc_textarea(get_option('hybrid_search_ai_reranking_instructions', '')); ?></textarea>
                            
                            <div style="margin-top: 15px; padding: 15px; background: #fff9e6; border-left: 4px solid #f59e0b; border-radius: 4px;">
                                <div style="font-weight: 600; color: #92400e; margin-bottom: 8px;">
                                    💡 How Custom Instructions Work
                                </div>
                                <p style="margin: 5px 0; font-size: 13px; color: #78350f;">
                                    These instructions are sent to the AI with every search to guide result ranking.<br>
                                    <strong>Be specific!</strong> Tell the AI what types of content are most valuable for your users.
                                </p>
                            </div>
                            
                            <p class="description" style="margin-top: 15px;">
                                <strong>💡 Pro Tips:</strong><br>
                                • Be specific about your business priorities (services vs content)<br>
                                • Specify how to handle different query types (how-to, what-is, comparison)<br>
                                • Update based on user behavior from analytics<br>
                                • Test different instructions and monitor click-through rates<br>
                            </p>
                        </td>
                    </tr>
                    
                    <tr class="ai-reranking-setting">
                        <th scope="row">AI Reranking Performance</th>
                        <td>
                            <?php
                            // Get stats safely with default values
                            $ai_stats_option = get_option('hybrid_search_ai_reranking_stats');
                            $ai_stats = [
                                'total_searches' => 0,
                                'avg_response_time' => 0,
                                'total_cost' => 0,
                                'last_updated' => ''
                            ];
                            
                            if (is_array($ai_stats_option)) {
                                $ai_stats = array_merge($ai_stats, $ai_stats_option);
                            }
                            ?>
                            
                            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                                <div style="background: white; padding: 15px; border-radius: 8px; border: 1px solid #e5e7eb; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                                    <div style="font-size: 12px; color: #6b7280; margin-bottom: 5px;">Total AI Searches</div>
                                    <div style="font-size: 24px; font-weight: 600; color: #667eea;">
                                        <?php echo number_format((int) $ai_stats['total_searches']); ?>
                                    </div>
                                </div>
                                
                                <div style="background: white; padding: 15px; border-radius: 8px; border: 1px solid #e5e7eb; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                                    <div style="font-size: 12px; color: #6b7280; margin-bottom: 5px;">Avg Response Time</div>
                                    <div style="font-size: 24px; font-weight: 600; color: #10b981;">
                                        <?php echo $ai_stats['avg_response_time'] > 0 ? number_format((float) $ai_stats['avg_response_time'], 2) . 's' : '--'; ?>
                                    </div>
                                </div>
                                
                                <div style="background: white; padding: 15px; border-radius: 8px; border: 1px solid #e5e7eb; box-shadow: 0 1px 3px rgba(0,0,0,0.1);">
                                    <div style="font-size: 12px; color: #6b7280; margin-bottom: 5px;">Estimated Cost</div>
                                    <div style="font-size: 24px; font-weight: 600; color: #f59e0b;">
                                        $<?php echo $ai_stats['total_cost'] > 0 ? number_format((float) $ai_stats['total_cost'], 4) : '0.0000'; ?>
                                    </div>
                                </div>
                            </div>
                            
                            <p class="description" style="margin-top: 15px;">
                                Statistics update automatically. Cost based on Cerebras pricing (~$0.10 per 1M tokens).<br>
                                <em>Last updated: <?php echo !empty($ai_stats['last_updated']) ? esc_html($ai_stats['last_updated']) : 'Never'; ?></em>
                            </p>
                        </td>
                    </tr>
                </table>
                </div>
                
                <!-- Indexing Tab -->
                <div id="tab-indexing" class="tab-content" style="display: none;">
                    <div style="background: #f0f6fc; padding: 20px; border-radius: 8px; border-left: 4px solid #10b981; margin-bottom: 20px;">
                        <h2 style="margin-top: 0;">📚 Content Indexing Settings</h2>
                        <p style="margin-bottom: 0; color: #555;">Control how content is indexed and organized for search.</p>
                    </div>
                <table class="form-table">
                    <tr>
                        <th scope="row">Content Source API URL</th>
                        <td>
                            <input type="url"
                                   name="hybrid_search_source_api_url"
                                   value="<?php echo esc_attr(get_option('hybrid_search_source_api_url', '')); ?>"
                                   class="regular-text"
                                   placeholder="https://example.com/wp-json/wp/v2" />
                            <p class="description">
                                <strong>Override the WordPress REST API endpoint used for indexing.</strong><br>
                                Leave empty to use this site's default REST API. Provide a full URL (ending in <code>/wp-json/wp/v2</code>)
                                if you want to fetch content from another WordPress instance.<br>
                                <em>Note: The indexing service must be able to reach the provided URL.</em>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Content Source Credentials</th>
                        <td>
                            <input type="text"
                                   name="hybrid_search_source_username"
                                   value="<?php echo esc_attr(get_option('hybrid_search_source_username', '')); ?>"
                                   class="regular-text"
                                   placeholder="Username (optional)" />
                            <br>
                            <input type="password"
                                   name="hybrid_search_source_password"
                                   value="<?php echo esc_attr(get_option('hybrid_search_source_password', '')); ?>"
                                   class="regular-text"
                                   placeholder="Application password (optional)" />
                            <p class="description">
                                <strong>Provide optional Basic Auth credentials for the content source API.</strong><br>
                                Use a WordPress Application Password with read access. If left blank, the indexer will attempt anonymous access.<br>
                                <em>Credentials are stored in plain text within WordPress options. Use only if required by your remote site.</em>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Auto-Index Content</th>
                        <td>
                            <input type="checkbox" name="hybrid_search_auto_index_enabled" value="1" <?php checked(get_option('hybrid_search_auto_index_enabled', true), 1); ?> />
                            <p class="description">
                                <strong>Automatically index content when posts are created, updated, or deleted.</strong><br>
                                When enabled, new content is immediately searchable without manual reindexing.<br>
                                <em>Recommended: Keep this enabled for always up-to-date search results.</em>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Post Types to Index</th>
                        <td>
                            <?php
                            // Get all public post types
                            $post_types = get_post_types(['public' => true], 'objects');
                            $selected_types = get_option('hybrid_search_index_post_types', ['post', 'page']);
                            if (!is_array($selected_types)) {
                                $selected_types = ['post', 'page'];
                            }
                            ?>
                            <fieldset>
                                <legend class="screen-reader-text">Select post types to index</legend>
                                <?php foreach ($post_types as $post_type): ?>
                                    <label style="display: block; margin-bottom: 8px;">
                                        <input type="checkbox" 
                                               name="hybrid_search_index_post_types[]" 
                                               value="<?php echo esc_attr($post_type->name); ?>"
                                               <?php checked(in_array($post_type->name, $selected_types)); ?> />
                                        <strong><?php echo esc_html($post_type->labels->name); ?></strong>
                                        <span style="color: #666; font-size: 12px;">(<?php echo esc_html($post_type->name); ?>)</span>
                                    </label>
                                <?php endforeach; ?>
                            </fieldset>
                            <p class="description">
                                <strong>Select which post types to include in the search index.</strong><br>
                                Only selected post types will be indexed and searchable.<br>
                                <em>Note: You must reindex content after changing this setting.</em>
                            </p>
                        </td>
                    </tr>
                    
                    <tr>
                        <th scope="row">Post Type Priority</th>
                        <td>
                            <?php
                            // Get all public post types
                            $all_post_types = get_post_types(['public' => true], 'objects');
                            $priority_order = get_option('hybrid_search_post_type_priority', ['post', 'page']);
                            if (!is_array($priority_order)) {
                                $priority_order = ['post', 'page'];
                            }
                            
                            // Remove duplicates first (in case database has duplicates)
                            $priority_order = array_unique($priority_order);
                            $priority_order = array_values($priority_order); // Re-index array
                            
                            // Add any post types that aren't in the priority list yet
                            foreach ($all_post_types as $pt) {
                                if (!in_array($pt->name, $priority_order)) {
                                    $priority_order[] = $pt->name;
                                }
                            }
                            ?>
                            <div id="post-type-priority-list" style="max-width: 500px;">
                                <?php foreach ($priority_order as $index => $post_type_name): ?>
                                    <?php 
                                    $post_type_obj = get_post_type_object($post_type_name);
                                    if (!$post_type_obj) continue;
                                    ?>
                                    <div class="post-type-priority-item" data-type="<?php echo esc_attr($post_type_name); ?>" style="
                                        background: #fff;
                                        border: 1px solid #ddd;
                                        border-radius: 6px;
                                        padding: 12px 15px;
                                        margin-bottom: 8px;
                                        cursor: move;
                                        display: flex;
                                        align-items: center;
                                        gap: 12px;
                                        transition: all 0.2s ease;
                                    ">
                                        <span style="
                                            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                                            color: white;
                                            width: 28px;
                                            height: 28px;
                                            border-radius: 50%;
                                            display: flex;
                                            align-items: center;
                                            justify-content: center;
                                            font-weight: 600;
                                            font-size: 13px;
                                        "><?php echo $index + 1; ?></span>
                                        <span style="
                                            font-size: 16px;
                                            cursor: move;
                                        ">⋮⋮</span>
                                        <div style="flex: 1;">
                                            <strong><?php echo esc_html($post_type_obj->labels->name); ?></strong>
                                            <span style="color: #666; font-size: 12px; margin-left: 8px;">(<?php echo esc_html($post_type_name); ?>)</span>
                                        </div>
                                        <input type="hidden" name="hybrid_search_post_type_priority[]" value="<?php echo esc_attr($post_type_name); ?>">
                                    </div>
                                <?php endforeach; ?>
                            </div>
                <p class="description">
                    <strong>Drag and drop to set search result priority order.</strong><br>
                    Search results will be grouped by post type in this order. All results from priority #1 will show first, then #2, etc.<br>
                    Within each group, results are sorted by relevance score (highest first).<br>
                    <em>Example: If "Services" is #1, all Service results appear before any Posts or Pages, regardless of relevance.</em><br>
                    <em>Tip: Put your most important content types at the top (e.g., Services, Products, Team Members).</em>
                </p>
                            
                            <script>
                            jQuery(document).ready(function($) {
                                // Make the list sortable (remove 'handle' to make entire item draggable)
                                $('#post-type-priority-list').sortable({
                                    cursor: 'move',
                                    placeholder: 'post-type-priority-placeholder',
                                    tolerance: 'pointer',
                                    update: function(event, ui) {
                                        // Update the numbers when order changes
                                        $('#post-type-priority-list .post-type-priority-item').each(function(index) {
                                            $(this).find('span:first').text(index + 1);
                                        });
                                    },
                                    start: function(event, ui) {
                                        $(ui.item).css('opacity', '0.6');
                                    },
                                    stop: function(event, ui) {
                                        $(ui.item).css('opacity', '1');
                                    }
                                });
                                
                                // Add hover effect
                                $('.post-type-priority-item').hover(
                                    function() {
                                        $(this).css({
                                            'background': '#f8f9fa',
                                            'border-color': '#667eea',
                                            'box-shadow': '0 2px 8px rgba(0,0,0,0.1)'
                                        });
                                    },
                                    function() {
                                        $(this).css({
                                            'background': '#fff',
                                            'border-color': '#ddd',
                                            'box-shadow': 'none'
                                        });
                                    }
                                );
                            });
                            </script>
                            
                            <style>
                            .post-type-priority-placeholder {
                                background: #e9ecef;
                                border: 2px dashed #667eea;
                                border-radius: 6px;
                                height: 52px;
                                margin-bottom: 8px;
                            }
                            </style>
                        </td>
                    </tr>
                </table>
                </div>
                
                <?php submit_button('Save All Settings', 'primary', 'submit', true, ['style' => 'margin-top: 20px;']); ?>
            </form>
        </div>
        
        <style>
        /* Modern Tab Styles */
        .nav-tab-wrapper {
            padding: 0 !important;
            border: none !important;
        }
        
        .nav-tab {
            background: #f5f5f5 !important;
            color: #555 !important;
            border: 1px solid #ddd !important;
            border-bottom: none !important;
            margin-right: 5px !important;
            padding: 12px 20px !important;
            font-weight: 600 !important;
            transition: all 0.3s ease !important;
        }
        
        .nav-tab:hover {
            background: #e9ecef !important;
        }
        
        .nav-tab-active {
            background: white !important;
            color: #667eea !important;
            border-color: #e0e0e0 #e0e0e0 white !important;
            border-bottom: 2px solid white !important;
            margin-bottom: -2px !important;
        }
        
        .tab-content {
            padding: 20px 0;
        }
        
        .tab-content.active {
            display: block !important;
        }
        
        .connection-status-good { color: #10b981; }
        .connection-status-error { color: #ef4444; }
        .connection-status-warning { color: #f59e0b; }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            // Tab switching
            $('.nav-tab').on('click', function(e) {
                e.preventDefault();
                
                // Remove active classes
                $('.nav-tab').removeClass('nav-tab-active');
                $('.tab-content').removeClass('active').hide();
                
                // Add active class to clicked tab
                $(this).addClass('nav-tab-active');
                
                // Show corresponding content
                const tab = $(this).data('tab');
                $('#tab-' + tab).addClass('active').show();
            });
            
            // Test connection button
            $('#test-connection-btn').on('click', function() {
                const btn = $(this);
                const indicator = $('#api-status-indicator');
                
                btn.prop('disabled', true).text('Testing...');
                indicator.html('<span id="status-icon">⏳</span><span id="status-text">Testing...</span>');
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'hybrid_search_test_connection',
                        _ajax_nonce: '<?php echo wp_create_nonce('hybrid-search-ajax'); ?>'
                    },
                    success: function(response) {
                        if (response.success) {
                            $('#status-icon').text('✅');
                            $('#status-text').html('<span class="connection-status-good">Connected</span>');
                            indicator.addClass('connection-status-good');
                        } else {
                            $('#status-icon').text('❌');
                            $('#status-text').html('<span class="connection-status-error">Failed</span>');
                            indicator.addClass('connection-status-error');
                            alert('Connection failed: ' + (response.data.message || 'Unknown error'));
                        }
                    },
                    error: function() {
                        $('#status-icon').text('❌');
                        $('#status-text').html('<span class="connection-status-error">Error</span>');
                        alert('Failed to test connection. Please check your API URL.');
                    },
                    complete: function() {
                        btn.prop('disabled', false).text('🔄 Test Connection');
                    }
                });
            });
            
            // Auto-check API status on load
            $.ajax({
                url: ajaxurl,
                type: 'POST',
                data: { 
                    action: 'hybrid_search_check_status',
                    _ajax_nonce: '<?php echo wp_create_nonce('hybrid-search-ajax'); ?>'
                },
                success: function(response) {
                    if (response.success) {
                        $('#status-icon').text('✅');
                        $('#status-text').html('<span class="connection-status-good">' + response.data.message + '</span>');
                    } else {
                        $('#status-icon').text('⚠️');
                        $('#status-text').html('<span class="connection-status-warning">' + response.data.message + '</span>');
                    }
                }
            });
            
            // Prevent accidental form submission
            $('#hybrid-search-settings-form').on('keydown', function(e) {
                if (e.key === 'Enter' && e.target.tagName !== 'TEXTAREA') {
                    e.preventDefault();
                }
            });
            
            // Ctrl+S / Cmd+S to save
            $(document).on('keydown', function(e) {
                if ((e.ctrlKey || e.metaKey) && e.key === 's') {
                    e.preventDefault();
                    $('#submit').click();
                    return false;
                }
            });
        });
        </script>
        
        <?php
    }
    
    /**
     * AJAX: Test API connection
     * 
     * @since 2.15.7
     */
    public function ajaxTestConnection() {
        check_ajax_referer('hybrid-search-ajax', 'nonce');
        
        $api_url = get_option('hybrid_search_api_url', '');
        $api_key = get_option('hybrid_search_api_key', '');
        
        if (empty($api_url)) {
            wp_send_json_error(['message' => 'API URL is not configured']);
        }
        
        $timeout = (int) apply_filters('hybrid_search_api_health_timeout', 15);
        
        $response = wp_remote_get($api_url . '/health', [
            'timeout' => $timeout,
            'redirection' => 3,
            'headers' => [
                'User-Agent' => 'WordPress Hybrid Search Plugin/' . HYBRID_SEARCH_VERSION,
                'x-hybrid-search-check' => 'api-test'
            ]
        ]);
        
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            if (stripos($error_message, 'cURL error 28') !== false) {
                $friendly = sprintf(
                    __('The API request timed out after %d seconds. Please ensure the Hybrid Search API is reachable from this server (firewall/allow-list) or increase the timeout.', 'hybrid-search'),
                    $timeout
                );
                wp_send_json_error([
                    'message' => $friendly,
                    'details' => $error_message,
                    'reason' => 'timeout'
                ]);
            }
            
            wp_send_json_error([
                'message' => sprintf(__('API connection failed: %s', 'hybrid-search'), $error_message),
                'reason' => 'connection_error'
            ]);
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code === 200) {
            wp_send_json_success(['message' => 'Connection successful!']);
        } else {
            wp_send_json_error(['message' => 'Connection failed (Status: ' . $status_code . ')']);
        }
    }
    
    /**
     * AJAX: Check API status
     * 
     * @since 2.15.7
     */
    public function ajaxCheckStatus() {
        check_ajax_referer('hybrid-search-ajax', 'nonce');
        
        $api_url = get_option('hybrid_search_api_url', '');
        
        if (empty($api_url)) {
            wp_send_json_error(['message' => 'API URL not configured']);
        }
        
        // Try to get cached status
        $status = get_transient('hybrid_search_api_status');
        if ($status !== false) {
            wp_send_json_success($status);
        }
        
        $timeout = (int) apply_filters('hybrid_search_api_status_timeout', 8);
        
        $response = wp_remote_get($api_url . '/health/quick', [
            'timeout' => $timeout,
            'redirection' => 3,
            'headers' => [
                'User-Agent' => 'WordPress Hybrid Search Plugin/' . HYBRID_SEARCH_VERSION,
                'x-hybrid-search-check' => 'status-quick'
            ]
        ]);
        
        if (is_wp_error($response) || wp_remote_retrieve_response_code($response) !== 200) {
            // Fallback to full health endpoint for more detail
            $response = wp_remote_get($api_url . '/health', [
                'timeout' => $timeout + 7,
                'redirection' => 3,
                'headers' => [
                    'User-Agent' => 'WordPress Hybrid Search Plugin/' . HYBRID_SEARCH_VERSION,
                    'x-hybrid-search-check' => 'status-full'
                ]
            ]);
        }
        
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            if (stripos($error_message, 'cURL error 28') !== false) {
                $friendly = sprintf(
                    __('Timed out after %d seconds while contacting the Hybrid Search API. Verify that the API endpoint is reachable and not blocked by a firewall.', 'hybrid-search'),
                    $timeout
                );
                wp_send_json_error([
                    'message' => $friendly,
                    'details' => $error_message,
                    'status' => 'timeout'
                ]);
            }
            
            wp_send_json_error([
                'message' => sprintf(__('Unable to connect to the API: %s', 'hybrid-search'), $error_message),
                'status' => 'unreachable'
            ]);
        }
        
            $status_code = wp_remote_retrieve_response_code($response);
            if ($status_code === 200) {
            $result = ['status' => 'healthy', 'message' => __('API is responding', 'hybrid-search')];
            set_transient('hybrid_search_api_status', $result, 60);
                wp_send_json_success($result);
            }
        
        wp_send_json_error([
            'message' => sprintf(__('API responded with status: %d', 'hybrid-search'), $status_code),
            'status' => 'unexpected_status'
        ]);
    }

    /**
     * AJAX: Reindex content
     *
     * @since 2.21.0
     */
    public function ajaxReindexContent() {
        check_ajax_referer('hybrid-search-ajax', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Insufficient permissions']);
            return;
        }

        try {
            // Trigger content reindexing via FastAPI
            $api_url = get_option('hybrid_search_api_url', '');
            if (empty($api_url)) {
                wp_send_json_error(['message' => 'API URL not configured']);
                return;
            }

            $post_types = apply_filters('hybrid_search_reindex_post_types', ['post', 'page']);
                $payload = [
                'force_reindex' => true,
                'post_types' => array_values(array_unique((array) $post_types))
            ];
                
                $source_api_url = trim((string) get_option('hybrid_search_source_api_url', ''));
                if (!empty($source_api_url)) {
                    $payload['wordpress_api_url'] = esc_url_raw($source_api_url);
                }
                
                $source_username = trim((string) get_option('hybrid_search_source_username', ''));
                $source_password = trim((string) get_option('hybrid_search_source_password', ''));
                if (!empty($source_username) && !empty($source_password)) {
                    $payload['wordpress_username'] = sanitize_text_field($source_username);
                    $payload['wordpress_password'] = sanitize_text_field($source_password);
                }

            $response = wp_remote_post($api_url . '/index', [
                'body' => wp_json_encode($payload),
                'headers' => [
                    'Content-Type' => 'application/json'
                ],
                'timeout' => 0.01,
                'blocking' => false
            ]);

            if (is_wp_error($response)) {
                wp_send_json_error(['message' => 'Failed to connect to API: ' . $response->get_error_message()]);
                return;
            }

            wp_send_json_success([
                'message' => __('Reindexing has started in the background. You can safely leave this page.', 'hybrid-search'),
                'status' => 'queued'
            ]);

        } catch (\Exception $e) {
            wp_send_json_error(['message' => 'Reindexing error: ' . $e->getMessage()]);
        }
    }

    /**
     * AJAX: Clear search cache
     *
     * @since 2.21.0
     */
    public function ajaxClearSearchCache() {
        check_ajax_referer('hybrid_search_analytics', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error(['message' => 'Insufficient permissions']);
            return;
        }

        try {
            // Clear WordPress transients used for caching
            global $wpdb;

            // Clear analytics cache
            delete_transient('hybrid_search_analytics_data');
            delete_transient('hybrid_search_api_status');

            // Clear any cached search results (if using WordPress object cache)
            if (function_exists('wp_cache_flush')) {
                wp_cache_flush();
            }

            // Clear analytics service caches
            if (method_exists($this->analytics_service, 'clearAnalyticsCaches')) {
                $this->analytics_service->clearAnalyticsCaches();
            }

            wp_send_json_success([
                'message' => 'Search cache cleared successfully',
                'cache_cleared' => true
            ]);

        } catch (\Exception $e) {
            wp_send_json_error(['message' => 'Cache clearing error: ' . $e->getMessage()]);
        }
    }
    
    /**
     * Analytics page
     * 
     * @since 2.0.0
     */
    public function analyticsPage() {
        // Enqueue required assets
        wp_enqueue_style('hybrid-search-analytics', plugins_url('assets/analytics-dashboard.css', dirname(__FILE__, 2)), [], HYBRID_SEARCH_VERSION);
        wp_enqueue_script('chart-js', 'https://cdn.jsdelivr.net/npm/chart.js', [], '4.4.0', true);
        wp_enqueue_script('hybrid-search-analytics', plugins_url('assets/analytics-dashboard.js', dirname(__FILE__, 2)), ['jquery', 'chart-js'], HYBRID_SEARCH_VERSION, true);

        // Localize script with data
        wp_localize_script('hybrid-search-analytics', 'hybridSearchAnalytics', [
            'ajaxUrl' => admin_url('admin-ajax.php'),
            'nonce' => wp_create_nonce('hybrid-search-ajax'),
            'strings' => [
                'loading' => __('Loading analytics...', 'hybrid-search'),
                'error' => __('Failed to load analytics data', 'hybrid-search'),
                'connected' => __('Connected', 'hybrid-search'),
                'disconnected' => __('Disconnected', 'hybrid-search'),
            ]
        ]);

        $analytics_data = $this->analytics_service->getAnalyticsData();
        $ctr_data = $this->ctr_service->getCTRStats();
        ?>
        <style>
            @keyframes spin {
                0% { transform: rotate(0deg); }
                100% { transform: rotate(360deg); }
            }

            @media (max-width: 768px) {
                .analytics-header { flex-direction: column; align-items: flex-start; gap: 15px; }
                .analytics-actions { width: 100%; justify-content: space-between; }
                .filter-row { flex-direction: column; gap: 15px; }
                .analytics-refresh-controls div:first-child { flex-direction: column; gap: 10px; align-items: flex-start; }
                .analytics-refresh-controls div:last-child { width: 100%; justify-content: center; }
                .analytics-overview-grid { grid-template-columns: 1fr; }
                .analytics-charts { grid-template-columns: 1fr; }
            }

            .analytics-table-container {
                overflow-x: auto;
                padding: 0 24px 24px 24px;
            }

            .analytics-table {
                width: 100%;
                border-collapse: collapse;
                font-size: 14px;
            }

            .analytics-table th {
                background: #f8fafc;
                padding: 12px;
                text-align: left;
                font-weight: 600;
                color: #374151;
                border-bottom: 2px solid #e5e7eb;
            }

            .analytics-table td {
                padding: 12px;
                border-bottom: 1px solid #e5e7eb;
                color: #4b5563;
            }

            .analytics-table tr:hover {
                background: #f9fafb;
            }

            .analytics-table .status-badge {
                padding: 4px 8px;
                border-radius: 12px;
                font-size: 12px;
                font-weight: 500;
                text-transform: uppercase;
            }

            .analytics-table .status-success {
                background: #dcfce7;
                color: #166534;
            }

            .analytics-table .status-error {
                background: #fef2f2;
                color: #dc2626;
            }
        </style>
        <div class="wrap">
            <div class="analytics-header" style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid #e5e7eb;">
                <div>
                    <h1 style="margin: 0; color: #1f2937;">Search Analytics</h1>
                    <p style="margin: 5px 0 0 0; color: #6b7280; font-size: 14px;">Monitor search performance and user behavior</p>
                </div>
                <div class="analytics-actions" style="display: flex; gap: 10px;">
                    <button type="button" id="export-analytics-btn" class="button button-secondary" style="display: flex; align-items: center; gap: 5px;">
                        <span class="dashicons dashicons-download"></span> Export CSV
                    </button>
                    <button type="button" id="clear-analytics-btn" class="button button-secondary" style="display: flex; align-items: center; gap: 5px;">
                        <span class="dashicons dashicons-trash"></span> Clear Data
                    </button>
                </div>
            </div>

            <!-- Filters Section -->
            <div class="analytics-filters" style="background: #f8fafc; padding: 20px; border-radius: 8px; margin-bottom: 25px; border: 1px solid #e2e8f0;">
                <h3 style="margin-top: 0; color: #374151;">Filters & Controls</h3>
                <div class="filter-row" style="display: flex; gap: 20px; flex-wrap: wrap; align-items: center;">
                    <div class="filter-group">
                        <label for="date-range" style="display: block; font-weight: 500; margin-bottom: 5px;">Date Range:</label>
                        <select id="date-range" style="min-width: 150px; padding: 8px 12px; border-radius: 6px; border: 1px solid #d1d5db;">
                            <option value="7">Last 7 days</option>
                            <option value="30" selected>Last 30 days</option>
                            <option value="90">Last 90 days</option>
                            <option value="custom">Custom range</option>
                        </select>
                    </div>

                    <div class="filter-group custom-date-range" style="display: none;">
                        <label style="display: block; font-weight: 500; margin-bottom: 5px;">From:</label>
                        <input type="date" id="date-from" style="padding: 8px 12px; border-radius: 6px; border: 1px solid #d1d5db;">
                    </div>

                    <div class="filter-group custom-date-range" style="display: none;">
                        <label style="display: block; font-weight: 500; margin-bottom: 5px;">To:</label>
                        <input type="date" id="date-to" style="padding: 8px 12px; border-radius: 6px; border: 1px solid #d1d5db;">
                    </div>

                    <div class="filter-group">
                        <label for="search-query-filter" style="display: block; font-weight: 500; margin-bottom: 5px;">Search Query:</label>
                        <input type="text" id="search-query-filter" placeholder="Filter by query..." style="min-width: 200px; padding: 8px 12px; border-radius: 6px; border: 1px solid #d1d5db;">
                    </div>

                    <div class="filter-group">
                        <label for="device-filter" style="display: block; font-weight: 500; margin-bottom: 5px;">Device:</label>
                        <select id="device-filter" style="min-width: 120px; padding: 8px 12px; border-radius: 6px; border: 1px solid #d1d5db;">
                            <option value="">All devices</option>
                            <option value="desktop">Desktop</option>
                            <option value="mobile">Mobile</option>
                            <option value="tablet">Tablet</option>
                        </select>
                    </div>
                </div>
            </div>

            <!-- Refresh Controls -->
            <div class="analytics-refresh-controls" style="background: #fef3c7; padding: 15px; border-radius: 8px; margin-bottom: 25px; border: 1px solid #f59e0b;">
                <div style="display: flex; justify-content: space-between; align-items: center; flex-wrap: wrap; gap: 15px;">
                    <div style="display: flex; align-items: center; gap: 15px;">
                        <label style="display: flex; align-items: center; gap: 8px; font-weight: 500;">
                            <input type="checkbox" id="auto-refresh-analytics" checked style="width: 16px; height: 16px;">
                            Auto-refresh
                </label>
                
                        <label style="display: flex; align-items: center; gap: 8px;">
                            <span>Interval:</span>
                            <select id="refresh-interval" style="padding: 4px 8px; border-radius: 4px; border: 1px solid #d97706;">
                                <option value="15000">15 seconds</option>
                        <option value="30000" selected>30 seconds</option>
                        <option value="60000">1 minute</option>
                                <option value="300000">5 minutes</option>
                    </select>
                </label>
                    </div>
                
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <button type="button" id="refresh-now-btn" class="button button-primary" style="display: flex; align-items: center; gap: 5px;">
                    <span class="dashicons dashicons-update"></span> Refresh Now
                </button>
                        <span id="last-refresh-time" style="color: #92400e; font-size: 13px; font-weight: 500;"></span>
                    </div>
                </div>
            </div>
            
            <!-- Loading State -->
            <div id="analytics-loading" style="display: none; text-align: center; padding: 50px;">
                <div style="display: inline-block; width: 40px; height: 40px; border: 4px solid #f3f3f3; border-top: 4px solid #3498db; border-radius: 50%; animation: spin 1s linear infinite;"></div>
                <p style="margin-top: 15px; color: #6b7280;">Loading analytics data...</p>
            </div>

            <!-- Error State -->
            <div id="analytics-error" style="display: none; background: #fef2f2; border: 1px solid #fecaca; border-radius: 8px; padding: 20px; margin-bottom: 25px;">
                <div style="display: flex; align-items: center; gap: 10px;">
                    <span class="dashicons dashicons-warning" style="color: #dc2626; font-size: 20px;"></span>
                    <div>
                        <h4 style="margin: 0; color: #dc2626;">Failed to load analytics data</h4>
                        <p style="margin: 5px 0 0 0; color: #7f1d1d;" id="analytics-error-message">Please try refreshing the page.</p>
                    </div>
                </div>
            </div>
            
            <div class="analytics-dashboard" id="analytics-dashboard-content">
                <!-- Analytics Overview Cards -->
                <div class="analytics-overview-grid" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 20px; margin-bottom: 30px;">
                    <div class="analytics-card" style="background: white; border: 1px solid #e5e7eb; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);">
                        <div style="display: flex; align-items: center; justify-content: space-between;">
                            <div>
                                <h4 style="margin: 0 0 8px 0; color: #374151; font-size: 14px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Total Searches</h4>
                                <div style="font-size: 32px; font-weight: 700; color: #1f2937;" id="total-searches"><?php echo number_format($analytics_data['pagination']['total_count'] ?? 0); ?></div>
                            </div>
                            <div style="background: #dbeafe; padding: 12px; border-radius: 8px;">
                                <span class="dashicons dashicons-search" style="color: #3b82f6; font-size: 24px;"></span>
                            </div>
                        </div>
                    </div>

                    <div class="analytics-card" style="background: white; border: 1px solid #e5e7eb; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);">
                        <div style="display: flex; align-items: center; justify-content: space-between;">
                            <div>
                                <h4 style="margin: 0 0 8px 0; color: #374151; font-size: 14px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Avg Response Time</h4>
                                <div style="font-size: 32px; font-weight: 700; color: #1f2937;" id="avg-response-time">
                                    <?php
                                    $avg_time = 0;
                                    if (!empty($analytics_data['data'])) {
                                        $times = array_column($analytics_data['data'], 'time_taken');
                                        $avg_time = array_sum($times) / count($times);
                                    }
                                    echo number_format($avg_time, 2) . 's';
                                    ?>
                                </div>
                            </div>
                            <div style="background: #dcfce7; padding: 12px; border-radius: 8px;">
                                <span class="dashicons dashicons-clock" style="color: #16a34a; font-size: 24px;"></span>
                            </div>
                        </div>
                        </div>
                        
                    <div class="analytics-card" style="background: white; border: 1px solid #e5e7eb; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);">
                        <div style="display: flex; align-items: center; justify-content: space-between;">
                            <div>
                                <h4 style="margin: 0 0 8px 0; color: #374151; font-size: 14px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Success Rate</h4>
                                <div style="font-size: 32px; font-weight: 700; color: #1f2937;" id="success-rate">
                                    <?php
                                    if (!empty($analytics_data['data'])) {
                                        $with_results = count(array_filter($analytics_data['data'], fn($item) => $item['has_results']));
                                        $total = count($analytics_data['data']);
                                        $rate = $total > 0 ? ($with_results / $total) * 100 : 0;
                                        echo number_format($rate, 1) . '%';
                                    } else {
                                        echo '0%';
                                    }
                                    ?>
                                </div>
                            </div>
                            <div style="background: #fef3c7; padding: 12px; border-radius: 8px;">
                                <span class="dashicons dashicons-yes" style="color: #d97706; font-size: 24px;"></span>
                            </div>
                        </div>
                    </div>

                    <div class="analytics-card" style="background: white; border: 1px solid #e5e7eb; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);">
                        <div style="display: flex; align-items: center; justify-content: space-between;">
                            <div>
                                <h4 style="margin: 0 0 8px 0; color: #374151; font-size: 14px; font-weight: 600; text-transform: uppercase; letter-spacing: 0.5px;">Unique Users</h4>
                                <div style="font-size: 32px; font-weight: 700; color: #1f2937;" id="unique-users">
                                    <?php
                                    if (!empty($analytics_data['data'])) {
                                        $user_ids = array_unique(array_column($analytics_data['data'], 'user_id'));
                                        echo number_format(count($user_ids));
                                    } else {
                                        echo '0';
                                    }
                                    ?>
                                </div>
                            </div>
                            <div style="background: #f3e8ff; padding: 12px; border-radius: 8px;">
                                <span class="dashicons dashicons-admin-users" style="color: #8b5cf6; font-size: 24px;"></span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Charts Section -->
                <div class="analytics-charts" style="display: grid; grid-template-columns: 1fr 1fr; gap: 25px; margin-bottom: 30px;">
                    <div class="analytics-card" style="background: white; border: 1px solid #e5e7eb; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);">
                        <h4 style="margin: 0 0 20px 0; color: #374151; font-size: 16px; font-weight: 600;">Search Volume Trend</h4>
                        <canvas id="search-volume-chart" style="width: 100%; height: 250px;"></canvas>
                    </div>

                    <div class="analytics-card" style="background: white; border: 1px solid #e5e7eb; border-radius: 12px; padding: 24px; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);">
                        <h4 style="margin: 0 0 20px 0; color: #374151; font-size: 16px; font-weight: 600;">Device Distribution</h4>
                        <canvas id="device-chart" style="width: 100%; height: 250px;"></canvas>
                    </div>
                        </div>
                    </div>
                    
                    <!-- Search Results Table -->
            <div class="analytics-table-section" style="background: white; border: 1px solid #e5e7eb; border-radius: 12px; overflow: hidden; box-shadow: 0 1px 3px rgba(0, 0, 0, 0.1);">
                <div style="padding: 24px 24px 0 24px; border-bottom: 1px solid #e5e7eb;">
                    <h4 style="margin: 0; color: #374151; font-size: 16px; font-weight: 600;">Recent Search Activity</h4>
                </div>
                    <div class="analytics-table-container">
                        <table class="analytics-table">
                            <thead>
                                <tr>
                                    <th>Query</th>
                                    <th>Results</th>
                                    <th>Time</th>
                                    <th>Device</th>
                                    <th>Browser</th>
                                    <th>Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if (!empty($analytics_data['data'])): ?>
                                    <?php foreach ($analytics_data['data'] as $search): ?>
                                        <tr>
                                            <td><?php echo wp_kses($search['query'], []); ?></td>
                                            <td><?php echo absint($search['result_count']); ?></td>
                                            <td><?php echo esc_html(round($search['time_taken'], 3)); ?>s</td>
                                            <td><?php echo sanitize_text_field($search['device_type']); ?></td>
                                            <td><?php echo sanitize_text_field($search['browser_name']); ?></td>
                                            <td><?php echo esc_html(date('M j, Y', strtotime($search['timestamp']))); ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6">No search data available. Perform some searches to see analytics.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                
                <!-- CTR Analytics -->
                <div class="analytics-card">
                    <h3>Click-Through Rate Analytics</h3>
                    
                    <?php if (!empty($ctr_data['overall_stats'])): ?>
                        <div class="ctr-overview">
                            <div class="ctr-metric">
                                <span class="ctr-label">Total Impressions:</span>
                                <span class="ctr-value"><?php echo esc_html(array_sum(array_column($ctr_data['overall_stats'], 'position_impressions'))); ?></span>
                            </div>
                            
                            <div class="ctr-metric">
                                <span class="ctr-label">Total Clicks:</span>
                                <span class="ctr-value"><?php echo esc_html(array_sum(array_column($ctr_data['overall_stats'], 'position_clicks'))); ?></span>
                            </div>
                        </div>
                        
                        <table class="analytics-table">
                            <thead>
                                <tr>
                                    <th>Position</th>
                                    <th>Impressions</th>
                                    <th>Clicks</th>
                                    <th>CTR</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($ctr_data['overall_stats'] as $stat): ?>
                                    <tr>
                                        <td><?php echo esc_html($stat['result_position']); ?></td>
                                        <td><?php echo esc_html($stat['position_impressions']); ?></td>
                                        <td><?php echo esc_html($stat['position_clicks']); ?></td>
                                        <td><?php echo esc_html(round($stat['ctr_rate'] * 100, 2)); ?>%</td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="no-data">
                            <p>No CTR data available yet. Perform some searches and click on results to see CTR analytics.</p>
                        </div>
                    <?php endif; ?>
                </div>
                
                <!-- Top Clicked Results -->
                <div class="analytics-card">
                    <h3>Top Clicked Results</h3>
                    
                    <?php if (!empty($ctr_data['top_clicked'])): ?>
                        <table class="analytics-table">
                            <thead>
                                <tr>
                                    <th>Title</th>
                                    <th>Position</th>
                                    <th>Clicks</th>
                                    <th>Avg Score</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($ctr_data['top_clicked'] as $result): ?>
                                    <tr>
                                        <td><?php echo esc_html($result['result_title']); ?></td>
                                        <td><?php echo esc_html($result['result_position']); ?></td>
                                        <td><?php echo esc_html($result['total_clicks']); ?></td>
                                        <td><?php echo esc_html(round($result['avg_score'], 3)); ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else: ?>
                        <div class="no-data">
                            <p>No clicked results data available yet.</p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        
        <style>
        .analytics-dashboard {
            background: linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
            padding: 25px;
            border-radius: 15px;
            margin-top: 20px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.1);
        }
        
        .analytics-card {
            background: white;
            border: 1px solid #e2e8f0;
            border-radius: 12px;
            padding: 25px;
            margin-bottom: 25px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.05);
            position: relative;
            overflow: hidden;
        }
        
        .analytics-card::before {
            content: '';
            position: absolute;
            top: 0;
            left: 0;
            right: 0;
            height: 4px;
            background: linear-gradient(90deg, #10b981, #059669);
        }
        
        .analytics-card h3 {
            position: sticky;
            top: 0;
            z-index: 15;
            background: white;
            margin: -25px -25px 20px -25px;
            padding: 25px 25px 15px 25px;
            border-bottom: 1px solid #e2e8f0;
            color: #1f2937;
            font-size: 1.25rem;
            font-weight: 600;
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .analytics-card h3::before {
            content: '';
            width: 4px;
            height: 20px;
            background: linear-gradient(90deg, #10b981, #059669);
            border-radius: 2px;
        }
        
        .analytics-table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        
        .analytics-table th {
            background: linear-gradient(135deg, #1f2937 0%, #374151 100%);
            color: white;
            padding: 12px 15px;
            text-align: left;
            font-weight: 600;
            border: none;
        }
        
        .analytics-table td {
            padding: 12px 15px;
            border-bottom: 1px solid #e2e8f0;
        }
        
        .analytics-table tbody tr:hover {
            background: #f8fafc;
        }
        
        .analytics-stats {
            display: flex;
            gap: 30px;
            margin-bottom: 20px;
        }
        
        .stat-item {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        
        .stat-label {
            font-size: 0.875rem;
            color: #6b7280;
            font-weight: 500;
        }
        
        .stat-value {
            font-size: 1.5rem;
            font-weight: 700;
            color: #1f2937;
        }
        
        .ctr-overview {
            background: linear-gradient(135deg, #f0fdf4 0%, #dcfce7 100%);
            padding: 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            display: flex;
            gap: 30px;
        }
        
        .ctr-metric {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        
        .ctr-label {
            font-size: 0.875rem;
            color: #166534;
            font-weight: 500;
        }
        
        .ctr-value {
            font-size: 1.25rem;
            font-weight: 700;
            color: #15803d;
        }
        
        .no-data {
            text-align: center;
            padding: 40px;
            color: #6b7280;
            border: 2px dashed #d1d5db;
            border-radius: 10px;
            background: #f9fafb;
        }
        
        .analytics-table-container {
            max-height: 400px;
            overflow-y: auto;
            border: 1px solid #e2e8f0;
            border-radius: 8px;
        }
        
        .analytics-table thead {
            position: sticky;
            top: 60px;
            z-index: 10;
        }
        
        #refresh-now-btn .dashicons {
            vertical-align: middle;
            margin-right: 5px;
        }
        
        #refresh-now-btn.refreshing .dashicons {
            animation: spin 1s linear infinite;
        }
        
        @keyframes spin {
            from { transform: rotate(0deg); }
            to { transform: rotate(360deg); }
        }
        
        .analytics-dashboard-loading {
            opacity: 0.6;
            pointer-events: none;
            position: relative;
        }
        
        .analytics-dashboard-loading::after {
            content: 'Refreshing...';
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: rgba(255, 255, 255, 0.95);
            padding: 20px 40px;
            border-radius: 8px;
            font-weight: 600;
            font-size: 16px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.15);
            z-index: 1000;
        }
        </style>
        
        <script>
        jQuery(document).ready(function($) {
            let refreshInterval = null;
            let lastRefreshTime = Date.now();
            
            // Update last refresh time display
            function updateLastRefreshTime() {
                const elapsed = Math.floor((Date.now() - lastRefreshTime) / 1000);
                const timeString = elapsed < 60 ? 
                    `${elapsed} seconds ago` : 
                    `${Math.floor(elapsed / 60)} minute${Math.floor(elapsed / 60) > 1 ? 's' : ''} ago`;
                $('#last-refresh-time').text(`Last updated: ${timeString}`);
            }
            
            // Refresh analytics data
            function refreshAnalytics() {
                const $dashboard = $('#analytics-dashboard-content');
                const $refreshBtn = $('#refresh-now-btn');
                
                $dashboard.addClass('analytics-dashboard-loading');
                $refreshBtn.addClass('refreshing').prop('disabled', true);
                
                // Store current scroll position
                const scrollPos = window.scrollY;
                
                $.ajax({
                    url: ajaxurl,
                    type: 'POST',
                    data: {
                        action: 'get_search_analytics',
                        nonce: '<?php echo wp_create_nonce("get_analytics"); ?>'
                    },
                    success: function(response) {
                        if (response.success && response.data) {
                            // Update dashboard content (you'll need to render the HTML)
                            console.log('Analytics refreshed:', response.data);
                            lastRefreshTime = Date.now();
                            updateLastRefreshTime();
                            
                            // In production, you'd update the dashboard HTML here
                            // For now, just show a success message
                        }
                    },
                    error: function(xhr, status, error) {
                        console.error('Analytics refresh failed:', error);
                    },
                    complete: function() {
                        $dashboard.removeClass('analytics-dashboard-loading');
                        $refreshBtn.removeClass('refreshing').prop('disabled', false);
                        
                        // Restore scroll position
                        window.scrollTo(0, scrollPos);
                    }
                });
            }
            
            // Manual refresh button
            $('#refresh-now-btn').on('click', function() {
                refreshAnalytics();
            });
            
            // Auto-refresh toggle
            $('#auto-refresh-analytics').on('change', function() {
                if ($(this).is(':checked')) {
                    startAutoRefresh();
                } else {
                    stopAutoRefresh();
                }
            });
            
            // Refresh interval change
            $('#refresh-interval').on('change', function() {
                if ($('#auto-refresh-analytics').is(':checked')) {
                    stopAutoRefresh();
                    startAutoRefresh();
                }
            });
            
            function startAutoRefresh() {
                const interval = parseInt($('#refresh-interval').val());
                refreshInterval = setInterval(refreshAnalytics, interval);
                console.log(`Auto-refresh started: every ${interval}ms`);
            }
            
            function stopAutoRefresh() {
                if (refreshInterval) {
                    clearInterval(refreshInterval);
                    refreshInterval = null;
                    console.log('Auto-refresh stopped');
                }
            }
            
            // Update time display every second
            setInterval(updateLastRefreshTime, 1000);
            
            // Initialize
            updateLastRefreshTime();
            if ($('#auto-refresh-analytics').is(':checked')) {
                startAutoRefresh();
            }
            
            // Stop auto-refresh when page is hidden
            document.addEventListener('visibilitychange', function() {
                if (document.hidden) {
                    stopAutoRefresh();
                } else if ($('#auto-refresh-analytics').is(':checked')) {
                    startAutoRefresh();
                }
            });
        });
        </script>
        <?php
    }
    
    /**
     * Diagnostics page
     * 
     * @since 2.7.0
     */
    public function diagnosticsPage() {
        // Handle diagnostic run
        $report = null;
        if (isset($_POST['run_diagnostics']) && check_admin_referer('hybrid_search_diagnostics')) {
            require_once HYBRID_SEARCH_PLUGIN_PATH . 'includes/Admin/DiagnosticTool.php';
            $report = DiagnosticTool::runDiagnostics();
        }
        
        ?>
        <div class="wrap">
            <h1>🔧 Hybrid Search Diagnostics</h1>
            <p>Run diagnostics to check for issues with analytics tracking and AI reranking.</p>
            
            <div class="diagnostic-tools">
                <form method="post">
                    <?php wp_nonce_field('hybrid_search_diagnostics'); ?>
                    <button type="submit" name="run_diagnostics" class="button button-primary button-large">
                        ▶️ Run Full Diagnostics
                    </button>
                </form>
                
                <?php if ($report): ?>
                    <div class="diagnostic-report">
                        <h2>Diagnostic Report</h2>
                        
                        <div class="status-badge status-<?php echo esc_attr($report['status']); ?>">
                            <?php if ($report['status'] === 'healthy'): ?>
                                ✅ All Systems Healthy
                            <?php else: ?>
                                ⚠️ Issues Found
                            <?php endif; ?>
                        </div>
                        
                        <?php if (!empty($report['fixes_applied'])): ?>
                            <div class="fixes-applied">
                                <h3>🔧 Fixes Applied</h3>
                                <ul>
                                    <?php foreach ($report['fixes_applied'] as $fix): ?>
                                        <li><?php echo esc_html($fix); ?></li>
                                    <?php endforeach; ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        
                        <h3>🔍 Diagnostic Checks</h3>
                        <table class="diagnostic-table">
                            <thead>
                                <tr>
                                    <th>Check</th>
                                    <th>Status</th>
                                    <th>Details</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($report['checks'] as $check_name => $check): ?>
                                    <tr class="check-<?php echo esc_attr($check['status']); ?>">
                                        <td><strong><?php echo esc_html(ucwords(str_replace('_', ' ', $check_name))); ?></strong></td>
                                        <td>
                                            <?php if ($check['status'] === 'pass'): ?>
                                                <span class="status-icon">✅</span> Pass
                                            <?php elseif ($check['status'] === 'fail'): ?>
                                                <span class="status-icon">❌</span> Fail
                                            <?php else: ?>
                                                <span class="status-icon">⚠️</span> Warning
                                            <?php endif; ?>
                                        </td>
                                        <td>
                                            <?php echo esc_html($check['message']); ?>
                                            <?php if (isset($check['value'])): ?>
                                                <br><code><?php echo esc_html($check['value']); ?></code>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                        
                        <div class="report-raw">
                            <h3>📋 Raw Report (for debugging)</h3>
                            <pre><?php echo esc_html(json_encode($report, JSON_PRETTY_PRINT)); ?></pre>
                        </div>
                    </div>
                <?php else: ?>
                    <div class="diagnostic-help">
                        <h2>📖 What does this check?</h2>
                        <ul>
                            <li>✅ Analytics database table exists and is working</li>
                            <li>✅ All required columns are present</li>
                            <li>✅ Can insert test records successfully</li>
                            <li>✅ AI reranking stats are configured</li>
                            <li>✅ API URL is properly configured</li>
                            <li>✅ AI reranking is enabled</li>
                        </ul>
                        
                        <h2>🔧 When to run diagnostics?</h2>
                        <p>Run diagnostics if you're experiencing:</p>
                        <ul>
                            <li>❌ Analytics dashboard shows no data</li>
                            <li>❌ AI Reranking Performance not updating</li>
                            <li>❌ Search tracking not working</li>
                            <li>❌ Database errors in logs</li>
                        </ul>
                    </div>
                <?php endif; ?>
            </div>
        </div>
        
        <style>
        .diagnostic-tools {
            background: #fff;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            margin-top: 20px;
        }
        
        .diagnostic-tools form {
            margin-bottom: 30px;
        }
        
        .button-large {
            font-size: 16px !important;
            padding: 12px 24px !important;
            height: auto !important;
        }
        
        .diagnostic-report {
            margin-top: 30px;
            padding-top: 30px;
            border-top: 3px solid #e5e7eb;
        }
        
        .status-badge {
            display: inline-block;
            padding: 12px 24px;
            border-radius: 6px;
            font-size: 18px;
            font-weight: bold;
            margin: 20px 0;
        }
        
        .status-badge.status-healthy {
            background: #d1fae5;
            color: #065f46;
            border: 2px solid #10b981;
        }
        
        .status-badge.status-issues_found {
            background: #fef3c7;
            color: #92400e;
            border: 2px solid #f59e0b;
        }
        
        .fixes-applied {
            background: #dbeafe;
            border-left: 4px solid #3b82f6;
            padding: 15px;
            margin: 20px 0;
        }
        
        .fixes-applied h3 {
            margin-top: 0;
            color: #1e40af;
        }
        
        .fixes-applied ul {
            margin: 10px 0;
            padding-left: 20px;
        }
        
        .diagnostic-table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
            background: #fff;
        }
        
        .diagnostic-table th,
        .diagnostic-table td {
            padding: 12px;
            text-align: left;
            border: 1px solid #e5e7eb;
        }
        
        .diagnostic-table th {
            background: #f3f4f6;
            font-weight: 600;
        }
        
        .diagnostic-table .check-pass {
            background: #f0fdf4;
        }
        
        .diagnostic-table .check-fail {
            background: #fef2f2;
        }
        
        .diagnostic-table .check-warning {
            background: #fffbeb;
        }
        
        .diagnostic-table code {
            background: #f3f4f6;
            padding: 2px 6px;
            border-radius: 3px;
            font-size: 12px;
        }
        
        .report-raw {
            margin-top: 30px;
            padding-top: 20px;
            border-top: 1px solid #e5e7eb;
        }
        
        .report-raw pre {
            background: #1f2937;
            color: #f3f4f6;
            padding: 20px;
            border-radius: 6px;
            overflow-x: auto;
            font-size: 12px;
            line-height: 1.5;
        }
        
        .diagnostic-help {
            background: #f0fdf4;
            border-left: 4px solid #10b981;
            padding: 20px;
            margin: 20px 0;
        }
        
        .diagnostic-help h2 {
            color: #065f46;
            margin-top: 20px;
        }
        
        .diagnostic-help h2:first-child {
            margin-top: 0;
        }
        
        .diagnostic-help ul {
            margin: 10px 0;
            padding-left: 20px;
        }
        
        .diagnostic-help li {
            margin: 8px 0;
        }
        </style>
        <?php
    }
    
    /**
     * Sanitize AI instructions
     * Enhanced sanitization for textarea fields with security checks
     * 
     * @param string $value Raw input
     * @return string Sanitized output
     * @since 2.15.1
     */
    /**
     * Sanitize AI reranking enabled checkbox
     * WordPress checkboxes: unchecked = not in POST = should default to true
     * 
     * @param mixed $value The value to sanitize
     * @return bool
     */
    public function sanitizeAIRerankingEnabled($value) {
        // If checkbox is checked, it sends '1'
        // If checkbox is unchecked, it's not in POST at all (null/empty)
        // Default to true (enabled) unless explicitly set to false
        if ($value === null || $value === '' || $value === false) {
            // Check if it was explicitly unchecked (value is in POST but empty)
            // WordPress sends empty string for unchecked checkboxes in some cases
            if (isset($_POST['hybrid_search_ai_reranking_enabled'])) {
                // Explicitly unchecked - return false
                return false;
            }
            // Not in POST at all - default to true
            return true;
        }
        
        // Explicitly checked or value is '1', true, or 1
        return rest_sanitize_boolean($value);
    }
    
    public function sanitizeAIInstructions($value) {
        // Remove any script tags and other dangerous HTML
        $value = wp_strip_all_tags($value);
        
        // Sanitize as textarea field
        $value = sanitize_textarea_field($value);
        
        // Limit length to prevent abuse
        if (strlen($value) > 5000) {
            $value = substr($value, 0, 5000);
            add_settings_error(
                'hybrid_search_ai_instructions',
                'instructions_too_long',
                'AI instructions were truncated to 5000 characters.',
                'warning'
            );
        }
        
        // Check for suspicious patterns
        $suspicious_patterns = [
            '/system\s*prompt/i',
            '/ignore\s*(previous|all)\s*instructions/i',
            '/jailbreak/i',
            '/<\?php/i',
            '/eval\s*\(/i',
            '/exec\s*\(/i',
        ];
        
        foreach ($suspicious_patterns as $pattern) {
            if (preg_match($pattern, $value)) {
                add_settings_error(
                    'hybrid_search_ai_instructions',
                    'suspicious_content',
                    'AI instructions contain potentially unsafe content and were not saved.',
                    'error'
                );
                return get_option('hybrid_search_ai_instructions', '');
            }
        }
        
        return $value;
    }
    
    /**
     * Enqueue admin assets
     * 
     * @since 2.0.0
     */
    public function enqueueAssets($hook) {
        // Only load on our admin pages
        if (strpos($hook, 'hybrid-search') === false) {
            return;
        }
        
        // Enqueue jQuery and jQuery UI for sortable functionality
        wp_enqueue_script('jquery');
        wp_enqueue_script('jquery-ui-core');
        wp_enqueue_script('jquery-ui-sortable');
        
        // Assets are handled inline in the admin pages
        // No external CSS/JS files needed
    }

    private function getDashboardDateRanges($days) {
        $now = current_time('timestamp');
        $current_from_ts = strtotime(sprintf('-%d days', $days), $now);
        $current_from_start = strtotime(date('Y-m-d 00:00:00', $current_from_ts));
        $current_to = date('Y-m-d H:i:s', $now);

        $previous_to_ts = $current_from_start - 1;
        $previous_from_ts = strtotime(sprintf('-%d days', $days), $previous_to_ts);
        $previous_from_start = strtotime(date('Y-m-d 00:00:00', $previous_from_ts));

        return [
            'days' => $days,
            'current_from' => date('Y-m-d 00:00:00', $current_from_start),
            'current_to' => $current_to,
            'previous_from' => date('Y-m-d H:i:s', $previous_from_start),
            'previous_to' => date('Y-m-d H:i:s', $previous_to_ts),
        ];
    }

    /**
     * AJAX: Provide dashboard data for admin UI
     *
     * @since 2.23.0
     */
    public function ajaxDashboardData() {
        check_ajax_referer('hybrid-search-ajax', 'nonce');

        if (!current_user_can('manage_options')) {
            wp_send_json_error([
                'message' => __('Insufficient permissions.', 'hybrid-search'),
            ]);
        }

        $section = sanitize_text_field($_POST['section'] ?? 'stats');
        $days = absint($_POST['days'] ?? 30);
        $limit = absint($_POST['limit'] ?? 10);

        if ($days < 1) {
            $days = 30;
        }

        if ($limit < 1) {
            $limit = 10;
        }

        $ranges = $this->getDashboardDateRanges($days);

        try {
            switch ($section) {
                case 'stats':
                    $payload = $this->prepareDashboardStats($ranges);
                    break;
                case 'activity':
                    $payload = $this->prepareDashboardActivity($limit);
                    break;
                case 'health':
                    $payload = $this->prepareDashboardHealth();
                    break;
                case 'charts':
                    $payload = $this->prepareDashboardCharts($ranges);
                    break;
                case 'rank_index':
                    $payload = $this->prepareDashboardRankIndex();
                    break;
                case 'all':
                    $payload = [
                        'stats' => $this->prepareDashboardStats($ranges),
                        'activity' => $this->prepareDashboardActivity($limit),
                        'health' => $this->prepareDashboardHealth(),
                        'charts' => $this->prepareDashboardCharts($ranges),
                        'rank_index' => $this->prepareDashboardRankIndex(),
                    ];
                    break;
                default:
                    wp_send_json_error([
                        'message' => __('Unknown dashboard section.', 'hybrid-search'),
                    ]);
                    return;
            }

            wp_send_json_success($payload);

        } catch (\Exception $e) {
            wp_send_json_error([
                'message' => $e->getMessage(),
            ]);
        }
    }

    /**
     * Prepare stats payload for dashboard widgets.
     */
    private function prepareDashboardStats(array $ranges) {
        $current_metrics = $this->analytics_service->getMetrics($ranges['current_from'], $ranges['current_to']);
        $previous_metrics = $this->analytics_service->getMetrics($ranges['previous_from'], $ranges['previous_to']);

        $total_current = (int) ($current_metrics['total_searches'] ?? 0);
        $total_previous = (int) ($previous_metrics['total_searches'] ?? 0);

        $successful_current = (int) ($current_metrics['successful_searches'] ?? 0);
        $successful_previous = (int) ($previous_metrics['successful_searches'] ?? 0);

        $zero_current = (int) ($current_metrics['zero_results'] ?? 0);
        $zero_previous = (int) ($previous_metrics['zero_results'] ?? 0);

        $unique_current = (int) ($current_metrics['unique_users'] ?? 0);
        $unique_previous = (int) ($previous_metrics['unique_users'] ?? 0);

        $avg_response_current_ms = isset($current_metrics['avg_response_time']) ? (float) $current_metrics['avg_response_time'] : 0.0;
        $avg_response_previous_ms = isset($previous_metrics['avg_response_time']) ? (float) $previous_metrics['avg_response_time'] : 0.0;

        $avg_response_current = round($avg_response_current_ms / 1000, 2);
        $avg_response_previous = round($avg_response_previous_ms / 1000, 2);

        $ctr_stats = $this->ctr_service->getCTRStats($ranges['days']);
        $ctr_current = round($this->calculateCtrRate($ctr_stats), 2);

        return [
            'total_searches' => $total_current,
            'total_searches_change' => $this->formatPercentageChange($total_current, $total_previous),
            'successful_searches' => $successful_current,
            'successful_searches_change' => $this->formatPercentageChange($successful_current, $successful_previous),
            'zero_results' => $zero_current,
            'zero_results_change' => $this->formatPercentageChange($zero_current, $zero_previous),
            'avg_response_time' => $avg_response_current,
            'avg_response_time_change' => $this->formatTimeChange($avg_response_current, $avg_response_previous),
            'ctr' => $ctr_current,
            'ctr_change' => [
                'value' => 0.0,
                'type' => 'percentage',
            ],
            'unique_users' => $unique_current,
            'unique_users_change' => $this->formatPercentageChange($unique_current, $unique_previous),
        ];
    }

    /**
     * Prepare recent activity payload.
     */
    private function prepareDashboardActivity($limit) {
        $recent_searches = $this->analytics_service->getRecentSearches($limit);

        if (empty($recent_searches) || !is_array($recent_searches)) {
            return [];
        }

        return array_map(function ($search) {
            $time_taken = 0.0;
            if (isset($search['time_taken']) && is_numeric($search['time_taken'])) {
                $time_taken = (float) $search['time_taken'];
            } elseif (isset($search['response_time']) && is_numeric($search['response_time'])) {
                $time_taken = ((float) $search['response_time']) / 1000;
            }

            return [
                'query' => wp_strip_all_tags($search['query'] ?? ''),
                'result_count' => (int) ($search['result_count'] ?? 0),
                'time_taken' => round($time_taken, 3),
                'device_type' => strtolower(sanitize_text_field($search['device_type'] ?? 'unknown')),
                'browser_name' => sanitize_text_field($search['browser_name'] ?? ''),
                'timestamp' => $this->formatIsoTimestamp($search['timestamp'] ?? ''),
            ];
        }, $recent_searches);
    }

    /**
     * Prepare system health payload.
     */
    private function prepareDashboardHealth() {
        $api = $this->checkApiHealthStatus();
        $database = $this->checkDatabaseHealthStatus();
        $cache = $this->checkCacheHealthStatus();

        return [
            $this->buildHealthItem(
                __('API Connection', 'hybrid-search'),
                $api['status'],
                __('FastAPI backend connectivity', 'hybrid-search'),
                $api['metric']
            ),
            $this->buildHealthItem(
                __('Database', 'hybrid-search'),
                $database['status'],
                __('Analytics storage status', 'hybrid-search'),
                $database['metric']
            ),
            $this->buildHealthItem(
                __('Cache System', 'hybrid-search'),
                $cache['status'],
                __('Search analytics caching', 'hybrid-search'),
                $cache['metric']
            ),
        ];
    }

    /**
     * Prepare rank index status payload.
     */
    private function prepareDashboardRankIndex() {
        $default = [
            'available' => false,
            'status' => 'unavailable',
            'percent' => 0,
            'indexed' => 0,
            'expected' => 0,
            'vectors' => 0,
            'collection' => '',
            'message' => __('Rank index status unavailable.', 'hybrid-search'),
        ];

        $api_url = trim(get_option('hybrid_search_api_url', ''));
        if (empty($api_url)) {
            $default['message'] = __('API URL not configured.', 'hybrid-search');
            return $default;
        }

        $timeout = (int) apply_filters('hybrid_search_rank_index_timeout', 12);
        $stats_endpoint = trailingslashit($api_url) . 'stats';

        $response = wp_remote_get($stats_endpoint, [
            'timeout' => $timeout,
            'redirection' => 3,
            'headers' => [
                'User-Agent' => 'WordPress Hybrid Search Plugin/' . HYBRID_SEARCH_VERSION,
                'x-hybrid-search-check' => 'rank-index'
            ],
        ]);

        if (is_wp_error($response)) {
            $default['message'] = $response->get_error_message();
            return $default;
        }

        $status_code = wp_remote_retrieve_response_code($response);
        if ($status_code !== 200) {
            $default['message'] = sprintf(
                __('Stats endpoint responded with status %d.', 'hybrid-search'),
                $status_code
            );
            return $default;
        }

        $body = wp_remote_retrieve_body($response);
        $data = json_decode($body, true);

        if (!is_array($data) || !isset($data['index_stats']) || !is_array($data['index_stats'])) {
            $default['message'] = __('Unexpected stats response from API.', 'hybrid-search');
            return $default;
        }

        $index_stats = $data['index_stats'];

        $indexed = (int) ($index_stats['total_documents'] ?? 0);
        $vectors = (int) ($index_stats['indexed_vectors'] ?? 0);
        $collection = sanitize_text_field($index_stats['collection_name'] ?? '');
        $raw_status = strtolower(sanitize_text_field($index_stats['status'] ?? 'unknown'));

        $expected = $this->calculateExpectedIndexDocuments();
        if ($expected < $indexed) {
            $expected = $indexed;
        }

        $percent = $expected > 0 ? round(($indexed / max(1, $expected)) * 100, 1) : 0.0;
        $percent = min(100.0, max(0.0, $percent));

        $status = $this->mapRankIndexStatus($raw_status, $percent, $indexed);

        if ($percent >= 99.5) {
            $status = 'healthy';
        }

        if ($expected === 0 && $indexed === 0) {
            $message = __('Waiting for first index run.', 'hybrid-search');
        } elseif ($expected > 0) {
            /* translators: 1: indexed documents, 2: expected documents */
            $message = sprintf(
                __('Indexed %1$s of %2$s documents', 'hybrid-search'),
                number_format_i18n($indexed),
                number_format_i18n($expected)
            );
        } else {
            /* translators: %s: indexed documents */
            $message = sprintf(
                __('Indexed %s documents', 'hybrid-search'),
                number_format_i18n($indexed)
            );
        }

        $result = [
            'available' => true,
            'status' => $status,
            'raw_status' => $raw_status,
            'percent' => $percent,
            'indexed' => $indexed,
            'expected' => $expected,
            'vectors' => $vectors,
            'collection' => $collection,
            'message' => $message,
            'last_checked' => current_time('mysql'),
        ];

        if (!empty($data['service_info']['api_version'])) {
            $result['api_version'] = sanitize_text_field($data['service_info']['api_version']);
        }

        return $result;
    }

    /**
     * Estimate the number of published documents expected in the index.
     *
     * @return int
     */
    private function calculateExpectedIndexDocuments() {
        $post_types = apply_filters('hybrid_search_reindex_post_types', ['post', 'page']);

        $total = 0;
        foreach ((array) $post_types as $post_type) {
            $counts = wp_count_posts($post_type);
            if ($counts && !is_wp_error($counts)) {
                $total += (int) ($counts->publish ?? 0);
                $total += (int) ($counts->future ?? 0);
            }
        }

        return max(0, $total);
    }

    /**
     * Normalize rank index status labels.
     *
     * @param string $raw
     * @param float  $percent
     * @param int    $indexed
     * @return string
     */
    private function mapRankIndexStatus($raw, $percent, $indexed) {
        switch ($raw) {
            case 'green':
            case 'ready':
            case 'optimal':
                return 'healthy';
            case 'yellow':
            case 'orange':
            case 'partial':
            case 'degraded':
                return 'warning';
            case 'red':
            case 'stopped':
            case 'error':
                return 'error';
            default:
                if ($percent >= 80 || $indexed === 0) {
                    return 'healthy';
                }

                if ($percent >= 40) {
                    return 'warning';
                }

                return 'error';
        }
    }

    /**
     * Prepare chart payload (search volume & response time).
     */
    private function prepareDashboardCharts(array $ranges) {
        $analytics = $this->analytics_service->getAnalyticsData([
            'date_from' => $ranges['current_from'],
            'date_to' => $ranges['current_to'],
            'limit' => 10000,
            'per_page' => 10000,
            'page' => 1,
        ]);

        $records = $analytics['records'] ?? [];

        $daily_counts = [];
        $daily_time_sum = [];
        $daily_time_count = [];

        foreach ($records as $record) {
            $timestamp = $record['timestamp'] ?? '';
            if (empty($timestamp)) {
                continue;
            }

            $date_key = gmdate('Y-m-d', strtotime($timestamp));

            if (!isset($daily_counts[$date_key])) {
                $daily_counts[$date_key] = 0;
                $daily_time_sum[$date_key] = 0;
                $daily_time_count[$date_key] = 0;
            }

            $daily_counts[$date_key]++;

            if (isset($record['time_taken']) && is_numeric($record['time_taken'])) {
                $daily_time_sum[$date_key] += (float) $record['time_taken'];
                $daily_time_count[$date_key]++;
            }
        }

        ksort($daily_counts);

        if (empty($daily_counts)) {
            $labels = [];
            $searches = [];
            $performance = [];

            for ($i = $ranges['days'] - 1; $i >= 0; $i--) {
                $date = gmdate('Y-m-d', strtotime(sprintf('-%d days', $i), strtotime($ranges['current_to'])));
                $labels[] = date_i18n('M j', strtotime($date));
                $searches[] = 0;
                $performance[] = 0;
            }

            return [
                'labels' => $labels,
                'searches' => $searches,
                'performance' => $performance,
            ];
        }

        $labels = [];
        $searches = [];
        $performance = [];

        foreach ($daily_counts as $date => $count) {
            $labels[] = date_i18n('M j', strtotime($date));
            $searches[] = $count;

            if (!empty($daily_time_count[$date])) {
                $avg = $daily_time_sum[$date] / $daily_time_count[$date];
                $performance[] = round($avg, 2);
            } else {
                $performance[] = 0;
            }
        }

        return [
            'labels' => $labels,
            'searches' => $searches,
            'performance' => $performance,
        ];
    }

    /**
     * Calculate CTR rate based on CTR stats payload.
     */
    private function calculateCtrRate(array $ctr_stats) {
        $overall = $ctr_stats['overall_stats'] ?? [];

        $total_impressions = 0;
        $total_clicks = 0;

        foreach ($overall as $row) {
            $total_impressions += (int) ($row['position_impressions'] ?? 0);
            $total_clicks += (int) ($row['position_clicks'] ?? 0);
        }

        if ($total_impressions <= 0) {
            return 0.0;
        }

        return ($total_clicks / $total_impressions) * 100;
    }

    /**
     * Calculate percentage change helper.
     */
    private function formatPercentageChange($current, $previous) {
        if ($previous == 0) {
            $value = $current > 0 ? 100.0 : 0.0;
        } else {
            $value = (($current - $previous) / $previous) * 100;
        }

        return [
            'value' => round($value, 1),
            'type' => 'percentage',
        ];
    }

    /**
     * Format change for time values (seconds).
     */
    private function formatTimeChange($current_seconds, $previous_seconds) {
        $difference = $current_seconds - $previous_seconds;

        return [
            'value' => round($difference, 2),
            'type' => 'time',
        ];
    }

    /**
     * Build health item structure for frontend.
     */
    private function buildHealthItem($name, $status, $description, $metric) {
        $valid_statuses = ['healthy', 'warning', 'error'];
        if (!in_array($status, $valid_statuses, true)) {
            $status = 'warning';
        }

        return [
            'name' => $name,
            'status' => $status,
            'description' => $description,
            'metric' => $metric,
        ];
    }

    private function checkApiHealthStatus() {
        $api_url = get_option('hybrid_search_api_url', '');

        if (empty($api_url)) {
            return [
                'status' => 'error',
                'metric' => __('API URL not configured', 'hybrid-search'),
            ];
        }

        $response = wp_remote_get($api_url . '/health', [
            'timeout' => 10,
            'headers' => [
                'User-Agent' => 'WordPress Hybrid Search Plugin/' . HYBRID_SEARCH_VERSION,
            ],
        ]);

        if (is_wp_error($response)) {
            return [
                'status' => 'error',
                'metric' => $response->get_error_message(),
            ];
        }

        $status_code = wp_remote_retrieve_response_code($response);

        if ($status_code === 200) {
            return [
                'status' => 'healthy',
                'metric' => __('Connection successful', 'hybrid-search'),
            ];
        }

        return [
            'status' => 'warning',
            'metric' => sprintf(__('Unexpected status: %s', 'hybrid-search'), $status_code),
        ];
    }

    private function checkDatabaseHealthStatus() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'hybrid_search_analytics';
        $table_exists = $wpdb->get_var($wpdb->prepare('SHOW TABLES LIKE %s', $table_name)) === $table_name;

        if (!$table_exists) {
            return [
                'status' => 'error',
                'metric' => __('Analytics table missing', 'hybrid-search'),
            ];
        }

        $record_count = (int) $wpdb->get_var("SELECT COUNT(*) FROM {$table_name}");
        $latest_entry = $wpdb->get_var("SELECT MAX(timestamp) FROM {$table_name}");

        $metric = sprintf(_n('%d record', '%d records', $record_count, 'hybrid-search'), $record_count);

        if (!empty($latest_entry)) {
            $latest_timestamp = strtotime($latest_entry);
            if ($latest_timestamp) {
                $metric .= ' • ' . sprintf(
                    __('Last entry %s ago', 'hybrid-search'),
                    human_time_diff($latest_timestamp, current_time('timestamp'))
                );
            }
        }

        return [
            'status' => 'healthy',
            'metric' => $metric,
        ];
    }

    private function checkCacheHealthStatus() {
        $test_key = 'hybrid_search_cache_test_' . wp_generate_password(6, false, false);
        $set = wp_cache_set($test_key, 'ok', '', 5);
        $cached = wp_cache_get($test_key);

        if ($set && $cached === 'ok') {
            $metric = wp_using_ext_object_cache()
                ? __('Object cache active', 'hybrid-search')
                : __('WordPress cache operational', 'hybrid-search');

            return [
                'status' => 'healthy',
                'metric' => $metric,
            ];
        }

        return [
            'status' => 'warning',
            'metric' => __('Cache check failed', 'hybrid-search'),
        ];
    }

    private function formatIsoTimestamp($timestamp) {
        if (empty($timestamp)) {
            return gmdate('c');
        }

        $time = strtotime($timestamp);
        if (!$time) {
            return gmdate('c');
        }

        return gmdate('c', $time);
    }
}
