<?php
/**
 * Diagnostic Tool
 * Check and fix analytics/database issues
 * 
 * @package HybridSearch\Admin
 * @since 2.7.0
 */

namespace HybridSearch\Admin;

class DiagnosticTool {
    
    /**
     * Run complete diagnostics
     */
    public static function runDiagnostics() {
        global $wpdb;
        
        $report = [
            'status' => 'unknown',
            'checks' => [],
            'fixes_applied' => []
        ];
        
        error_log('═══════════════════════════════════════════════');
        error_log('HYBRID SEARCH DIAGNOSTICS STARTING');
        error_log('═══════════════════════════════════════════════');
        
        // Check 1: Analytics table exists
        $analytics_table = $wpdb->prefix . 'hybrid_search_analytics';
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$analytics_table'") === $analytics_table;
        
        $report['checks']['analytics_table'] = [
            'status' => $table_exists ? 'pass' : 'fail',
            'message' => $table_exists ? 'Analytics table exists' : 'Analytics table MISSING!'
        ];
        
        error_log('CHECK: Analytics table exists? ' . ($table_exists ? 'YES ✓' : 'NO ✗'));
        
        if (!$table_exists) {
            error_log('FIX: Attempting to create analytics table...');
            self::createAnalyticsTable();
            $report['fixes_applied'][] = 'Created analytics table';
        }
        
        // Check 2: Analytics table has correct columns
        if ($table_exists) {
            $columns = $wpdb->get_results("DESCRIBE $analytics_table", ARRAY_A);
            $column_names = array_column($columns, 'Field');
            
            $required_columns = ['query', 'timestamp', 'time_taken', 'has_results', 'result_count'];
            $missing_columns = array_diff($required_columns, $column_names);
            
            $report['checks']['analytics_columns'] = [
                'status' => empty($missing_columns) ? 'pass' : 'fail',
                'message' => empty($missing_columns) ? 'All required columns exist' : 'Missing columns: ' . implode(', ', $missing_columns),
                'found_columns' => $column_names
            ];
            
            error_log('CHECK: Analytics columns - ' . implode(', ', $column_names));
            
            if (!empty($missing_columns)) {
                error_log('WARNING: Missing columns: ' . implode(', ', $missing_columns));
            }
        }
        
        // Check 3: Can insert into analytics
        if ($table_exists) {
            $test_insert = $wpdb->insert(
                $analytics_table,
                [
                    'query' => 'diagnostic_test_' . time(),
                    'result_count' => 0,
                    'time_taken' => 0.1,
                    'has_results' => 0,
                    'timestamp' => current_time('mysql'),
                    'session_id' => 'test_session',
                    'ip_address' => '127.0.0.1'
                ],
                ['%s', '%d', '%f', '%d', '%s', '%s', '%s']
            );
            
            if ($test_insert) {
                $insert_id = $wpdb->insert_id;
                error_log('CHECK: Test insert successful (ID: ' . $insert_id . ') ✓');
                
                // Clean up test record
                $wpdb->delete($analytics_table, ['id' => $insert_id], ['%d']);
                
                $report['checks']['analytics_insert'] = [
                    'status' => 'pass',
                    'message' => 'Can insert into analytics table'
                ];
            } else {
                error_log('CHECK: Test insert FAILED ✗');
                error_log('ERROR: ' . $wpdb->last_error);
                
                $report['checks']['analytics_insert'] = [
                    'status' => 'fail',
                    'message' => 'Cannot insert: ' . $wpdb->last_error
                ];
            }
        }
        
        // Check 4: AI reranking stats option exists
        $ai_stats = get_option('hybrid_search_ai_reranking_stats', false);
        
        if ($ai_stats === false) {
            error_log('CHECK: AI stats option does not exist, creating...');
            add_option('hybrid_search_ai_reranking_stats', [
                'total_searches' => 0,
                'avg_response_time' => 0,
                'total_cost' => 0,
                'last_updated' => ''
            ], '', 'no');
            $report['fixes_applied'][] = 'Created AI stats option';
        } else {
            error_log('CHECK: AI stats option exists ✓');
            error_log('  Total searches: ' . ($ai_stats['total_searches'] ?? 0));
            error_log('  Total cost: $' . number_format($ai_stats['total_cost'] ?? 0, 6));
        }
        
        $report['checks']['ai_stats_option'] = [
            'status' => 'pass',
            'message' => 'AI stats option configured',
            'data' => $ai_stats
        ];
        
        // Check 5: API URL configured
        $api_url = get_option('hybrid_search_api_url', '');
        
        $report['checks']['api_url'] = [
            'status' => !empty($api_url) ? 'pass' : 'fail',
            'message' => !empty($api_url) ? "API URL: $api_url" : 'API URL not configured!',
            'value' => $api_url
        ];
        
        error_log('CHECK: API URL configured? ' . (!empty($api_url) ? 'YES ✓ (' . $api_url . ')' : 'NO ✗'));
        
        // Check 6: AI reranking enabled
        $ai_enabled = get_option('hybrid_search_ai_reranking_enabled', true);
        
        $report['checks']['ai_enabled'] = [
            'status' => $ai_enabled ? 'pass' : 'warning',
            'message' => $ai_enabled ? 'AI reranking is enabled' : 'AI reranking is disabled'
        ];
        
        error_log('CHECK: AI reranking enabled? ' . ($ai_enabled ? 'YES ✓' : 'NO ✗'));
        
        // Overall status
        $failed_checks = array_filter($report['checks'], function($check) {
            return $check['status'] === 'fail';
        });
        
        $report['status'] = empty($failed_checks) ? 'healthy' : 'issues_found';
        
        error_log('═══════════════════════════════════════════════');
        error_log('DIAGNOSTICS COMPLETE: ' . strtoupper($report['status']));
        error_log('Issues found: ' . count($failed_checks));
        error_log('Fixes applied: ' . count($report['fixes_applied']));
        error_log('═══════════════════════════════════════════════');
        
        return $report;
    }
    
    /**
     * Create analytics table if missing
     */
    private static function createAnalyticsTable() {
        global $wpdb;
        
        $table_name = $wpdb->prefix . 'hybrid_search_analytics';
        $charset_collate = $wpdb->get_charset_collate();
        
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            query varchar(255) NOT NULL,
            result_count int(11) NOT NULL DEFAULT 0,
            time_taken decimal(10,3) DEFAULT NULL,
            has_results tinyint(1) NOT NULL DEFAULT 0,
            user_agent text,
            language varchar(10),
            screen_resolution varchar(20),
            viewport_size varchar(20),
            referrer text,
            session_id varchar(100),
            user_id varchar(100),
            device_type varchar(20),
            browser_name varchar(50),
            browser_version varchar(20),
            search_method varchar(50),
            filters text,
            sort_method varchar(50),
            timestamp datetime NOT NULL,
            ip_address varchar(45),
            PRIMARY KEY (id),
            KEY query_index (query),
            KEY timestamp_index (timestamp),
            KEY session_index (session_id),
            KEY user_index (user_id),
            KEY device_index (device_type),
            KEY browser_index (browser_name),
            KEY ip_index (ip_address)
        ) $charset_collate;";
        
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        
        error_log('Created analytics table: ' . $table_name);
    }

    /**
     * Create CTR table if missing
     */
    private static function createCTRTable() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'hybrid_search_ctr';
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            search_id mediumint(9) NOT NULL,
            result_id varchar(255) NOT NULL,
            result_title text NOT NULL,
            result_url text NOT NULL,
            result_position int(11) NOT NULL,
            result_score decimal(10,3),
            clicked tinyint(1) NOT NULL DEFAULT 0,
            click_timestamp datetime,
            session_id varchar(100),
            user_id varchar(100),
            ip_address varchar(45),
            user_agent text,
            device_type varchar(20),
            browser_name varchar(50),
            query varchar(255) NOT NULL,
            timestamp datetime NOT NULL,
            PRIMARY KEY (id),
            KEY search_id_index (search_id),
            KEY result_id_index (result_id),
            KEY clicked_index (clicked),
            KEY query_index (query),
            KEY timestamp_index (timestamp),
            KEY session_index (session_id),
            KEY user_index (user_id),
            KEY position_index (result_position)
        ) $charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        error_log('Created CTR table: ' . $table_name);
    }

    /**
     * Create cache table if missing
     */
    private static function createCacheTable() {
        global $wpdb;
        $table_name = $wpdb->prefix . 'hybrid_search_cache';
        $charset_collate = $wpdb->get_charset_collate();
        $sql = "CREATE TABLE $table_name (
            id mediumint(9) NOT NULL AUTO_INCREMENT,
            cache_key varchar(255) NOT NULL,
            cache_value longtext NOT NULL,
            expires_at datetime NOT NULL,
            created_at datetime NOT NULL,
            PRIMARY KEY (id),
            UNIQUE KEY cache_key_unique (cache_key),
            KEY expires_index (expires_at)
        ) $charset_collate;";
        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
        error_log('Created cache table: ' . $table_name);
    }

    /**
     * Extended diagnostics for CTR and Cache tables with auto-fix
     */
    public static function runExtendedDiagnostics() {
        global $wpdb;
        $report = self::runDiagnostics();
        
        // CTR table
        $ctr_table = $wpdb->prefix . 'hybrid_search_ctr';
        $ctr_exists = $wpdb->get_var("SHOW TABLES LIKE '$ctr_table'") === $ctr_table;
        $report['checks']['ctr_table'] = [
            'status' => $ctr_exists ? 'pass' : 'fail',
            'message' => $ctr_exists ? 'CTR table exists' : 'CTR table MISSING!'
        ];
        if (!$ctr_exists) {
            self::createCTRTable();
            $report['fixes_applied'][] = 'Created CTR table';
        }
        
        // Cache table
        $cache_table = $wpdb->prefix . 'hybrid_search_cache';
        $cache_exists = $wpdb->get_var("SHOW TABLES LIKE '$cache_table'") === $cache_table;
        $report['checks']['cache_table'] = [
            'status' => $cache_exists ? 'pass' : 'fail',
            'message' => $cache_exists ? 'Cache table exists' : 'Cache table MISSING!'
        ];
        if (!$cache_exists) {
            self::createCacheTable();
            $report['fixes_applied'][] = 'Created cache table';
        }
        
        return $report;
    }
}

