<?php
/**
 * Input Validation and Security Module
 * 
 * Comprehensive input validation and sanitization for the Hybrid Search plugin.
 * 
 * @package HybridSearch\Core
 * @since 2.11.0
 */

namespace HybridSearch\Core;

class InputValidator {
    
    /**
     * Validate search query
     * 
     * @param string $query Search query
     * @return string Sanitized query
     * @throws \InvalidArgumentException
     */
    public static function validateSearchQuery($query) {
        if (empty($query) || !is_string($query)) {
            throw new \InvalidArgumentException('Search query cannot be empty');
        }
        
        $query = trim($query);
        
        if (strlen($query) < 1) {
            throw new \InvalidArgumentException('Search query too short');
        }
        
        if (strlen($query) > 255) {
            throw new \InvalidArgumentException('Search query too long (max 255 characters)');
        }
        
        // Check for SQL injection patterns
        $sql_patterns = [
            '/(union|select|insert|update|delete|drop|create|alter)\s+/i',
            '/(or|and)\s+\d+\s*=\s*\d+/i',
            '/;\s*(drop|delete|insert|update)/i',
            '/--\s*$/i',
            '/\/\*.*\*\//i',
        ];
        
        foreach ($sql_patterns as $pattern) {
            if (preg_match($pattern, $query)) {
                error_log("Hybrid Search: Potential SQL injection attempt detected: {$query}");
                throw new \InvalidArgumentException('Invalid query format');
            }
        }
        
        // Check for XSS patterns
        $xss_patterns = [
            '/<script[^>]*>.*?<\/script>/i',
            '/javascript:/i',
            '/on\w+\s*=/i',
            '/<iframe[^>]*>/i',
            '/<object[^>]*>/i',
            '/<embed[^>]*>/i',
        ];
        
        foreach ($xss_patterns as $pattern) {
            if (preg_match($pattern, $query)) {
                error_log("Hybrid Search: Potential XSS attempt detected: {$query}");
                throw new \InvalidArgumentException('Invalid query format');
            }
        }
        
        // Remove potentially dangerous characters
        $query = preg_replace('/[<>"\']/', '', $query);
        
        // Limit consecutive special characters
        if (preg_match('/[^\w\s]{3,}/', $query)) {
            throw new \InvalidArgumentException('Query contains too many special characters');
        }
        
        return $query;
    }
    
    /**
     * Validate AI instructions
     * 
     * @param string $instructions AI instructions
     * @return string Sanitized instructions
     * @throws \InvalidArgumentException
     */
    public static function validateAIInstructions($instructions) {
        if (empty($instructions)) {
            return '';
        }
        
        if (strlen($instructions) > 1000) {
            throw new \InvalidArgumentException('AI instructions too long (max 1000 characters)');
        }
        
        // Remove HTML tags
        $cleaned = wp_strip_all_tags($instructions);
        
        // Check for command injection patterns
        $dangerous_patterns = [
            '/`[^`]*`/',  // Backticks
            '/\$\([^)]*\)/',  // Command substitution
            '/;\s*\w+/',  // Command chaining
            '/\|\s*\w+/',  // Pipe commands
        ];
        
        foreach ($dangerous_patterns as $pattern) {
            if (preg_match($pattern, $cleaned)) {
                error_log("Hybrid Search: Potential command injection in instructions: {$instructions}");
                throw new \InvalidArgumentException('Invalid instructions format');
            }
        }
        
        return $cleaned;
    }
    
    /**
     * Validate search filters
     * 
     * @param array $filters Search filters
     * @return array Sanitized filters
     */
    public static function validateFilters($filters) {
        if (!is_array($filters)) {
            return [];
        }
        
        $allowed_keys = ['type', 'author', 'categories', 'tags', 'date', 'sort'];
        $sanitized = [];
        
        foreach ($filters as $key => $value) {
            if (!in_array($key, $allowed_keys)) {
                error_log("Hybrid Search: Invalid filter key: {$key}");
                continue;
            }
            
            if (is_string($value)) {
                $sanitized_value = sanitize_text_field($value);
                if (strlen($sanitized_value) <= 100) {
                    $sanitized[$key] = $sanitized_value;
                }
            } elseif (is_array($value)) {
                $sanitized_list = [];
                foreach ($value as $item) {
                    if (is_string($item)) {
                        $sanitized_item = sanitize_text_field($item);
                        if (strlen($sanitized_item) <= 100) {
                            $sanitized_list[] = $sanitized_item;
                        }
                    }
                }
                if (!empty($sanitized_list)) {
                    $sanitized[$key] = $sanitized_list;
                }
            } else {
                $sanitized[$key] = $value;
            }
        }
        
        return $sanitized;
    }
    
    /**
     * Validate pagination parameters
     * 
     * @param int $limit Results limit
     * @param int $offset Results offset
     * @return array [limit, offset]
     */
    public static function validatePagination($limit, $offset) {
        $limit = (int) $limit;
        $offset = (int) $offset;
        
        if ($limit < 1) {
            $limit = 10;
        }
        if ($limit > 100) {
            $limit = 100;
        }
        if ($offset < 0) {
            $offset = 0;
        }
        if ($offset > 10000) {
            $offset = 10000;
        }
        
        return [$limit, $offset];
    }
    
    /**
     * Validate API URL
     * 
     * @param string $url API URL
     * @return bool True if valid
     */
    public static function validateAPIUrl($url) {
        if (empty($url)) {
            return false;
        }
        
        // Check URL format
        if (!filter_var($url, FILTER_VALIDATE_URL)) {
            return false;
        }
        
        // Must be HTTPS in production
        if (is_ssl() && !preg_match('/^https:/', $url)) {
            return false;
        }
        
        // Check for suspicious patterns
        $suspicious_patterns = [
            '/javascript:/i',
            '/data:/i',
            '/file:/i',
            '/ftp:/i',
        ];
        
        foreach ($suspicious_patterns as $pattern) {
            if (preg_match($pattern, $url)) {
                return false;
            }
        }
        
        return true;
    }
    
    /**
     * Validate API key
     * 
     * @param string $key API key
     * @return bool True if valid
     */
    public static function validateAPIKey($key) {
        if (empty($key)) {
            return false;
        }
        
        // Check format (alphanumeric, length 20-100)
        if (!preg_match('/^[a-zA-Z0-9_-]{20,100}$/', $key)) {
            return false;
        }
        
        return true;
    }
    
    /**
     * Sanitize text content
     * 
     * @param string $text Text to sanitize
     * @param int $max_length Maximum length
     * @return string Sanitized text
     */
    public static function sanitizeText($text, $max_length = 1000) {
        if (!is_string($text)) {
            return '';
        }
        
        // Remove HTML tags
        $cleaned = wp_strip_all_tags($text);
        
        // Remove dangerous characters
        $cleaned = preg_replace('/[<>"\']/', '', $cleaned);
        
        // Limit length
        if (strlen($cleaned) > $max_length) {
            $cleaned = substr($cleaned, 0, $max_length);
        }
        
        return trim($cleaned);
    }
    
    /**
     * Validate IP address
     * 
     * @param string $ip IP address
     * @return bool True if valid
     */
    public static function validateIP($ip) {
        return filter_var($ip, FILTER_VALIDATE_IP) !== false;
    }
    
    /**
     * Rate limit check
     * 
     * @param string $ip IP address
     * @param string $endpoint Endpoint
     * @param int $limit Rate limit
     * @param int $window Time window in seconds
     * @return bool True if within limits
     */
    public static function checkRateLimit($ip, $endpoint, $limit = 100, $window = 3600) {
        // Simple rate limiting using WordPress transients
        $key = 'hybrid_search_rate_' . md5($ip . $endpoint);
        $count = get_transient($key);
        
        if ($count === false) {
            set_transient($key, 1, $window);
            return true;
        }
        
        if ($count >= $limit) {
            return false;
        }
        
        set_transient($key, $count + 1, $window);
        return true;
    }
    
    /**
     * Validate nonce
     * 
     * @param string $nonce Nonce value
     * @param string $action Action name
     * @return bool True if valid
     */
    public static function validateNonce($nonce, $action) {
        return wp_verify_nonce($nonce, $action);
    }
    
    /**
     * Validate user capability
     * 
     * @param string $capability Required capability
     * @return bool True if user has capability
     */
    public static function validateCapability($capability) {
        return current_user_can($capability);
    }
    
    /**
     * Sanitize file upload
     * 
     * @param array $file Uploaded file array
     * @return array|false Sanitized file array or false if invalid
     */
    public static function validateFileUpload($file) {
        if (!isset($file['tmp_name']) || !is_uploaded_file($file['tmp_name'])) {
            return false;
        }
        
        // Check file type
        $allowed_types = ['text/plain', 'text/csv', 'application/json'];
        $file_type = wp_check_filetype($file['name']);
        
        if (!in_array($file_type['type'], $allowed_types)) {
            return false;
        }
        
        // Check file size (max 1MB)
        if ($file['size'] > 1048576) {
            return false;
        }
        
        // Check for suspicious content
        $content = file_get_contents($file['tmp_name']);
        if (strpos($content, '<?php') !== false || strpos($content, '<script') !== false) {
            return false;
        }
        
        return $file;
    }
}

