<?php
/**
 * API Client
 * 
 * @package SCS\HybridSearch\API
 * @since 2.0.0
 */

namespace HybridSearch\API;

class APIClient {
    
    /**
     * API configuration
     * 
     * @var array
     */
    private $config;
    
    /**
     * Default headers
     * 
     * @var array
     */
    private $default_headers;
    
    /**
     * Constructor
     * 
     * @param array $config
     */
    public function __construct($config = []) {
        $this->config = wp_parse_args($config, [
            'url' => '',
            'key' => '',
            'timeout' => 45,  // Increased timeout for search requests (AI reranking can take time)
            'long_timeout' => 1800,  // 30 minutes for indexing operations (embedding generation is slow)
            'verify_ssl' => true,
            'user_agent' => 'WordPress Hybrid Search Plugin/' . HYBRID_SEARCH_VERSION,
            'retry_attempts' => 1,  // Retry once on timeout
            'retry_delay' => 2,  // Wait 2 seconds before retry
        ]);
        
        $this->default_headers = [
            'Content-Type' => 'application/json',
            'User-Agent' => $this->config['user_agent'],
            'Accept' => 'application/json',
        ];
        
        if (!empty($this->config['key'])) {
            $this->default_headers['Authorization'] = 'Bearer ' . $this->config['key'];
        }
    }
    
    /**
     * Make GET request
     * 
     * @param string $endpoint
     * @param array $params
     * @param array $headers
     * @return array
     */
    public function get($endpoint, $params = [], $headers = []) {
        $url = $this->buildUrl($endpoint, $params);
        $request_headers = array_merge($this->default_headers, $headers);
        
        return $this->makeRequest('GET', $url, null, $request_headers);
    }
    
    /**
     * Make POST request
     * 
     * @param string $endpoint
     * @param array $data
     * @param array $headers
     * @param bool $long_running Whether this is a long-running operation
     * @return array
     */
    public function post($endpoint, $data = [], $headers = [], $long_running = false) {
        $url = $this->buildUrl($endpoint);
        $request_headers = array_merge($this->default_headers, $headers);
        
        return $this->makeRequest('POST', $url, $data, $request_headers, $long_running);
    }
    
    /**
     * Make PUT request
     * 
     * @param string $endpoint
     * @param array $data
     * @param array $headers
     * @return array
     */
    public function put($endpoint, $data = [], $headers = []) {
        $url = $this->buildUrl($endpoint);
        $request_headers = array_merge($this->default_headers, $headers);
        
        return $this->makeRequest('PUT', $url, $data, $request_headers);
    }
    
    /**
     * Make DELETE request
     * 
     * @param string $endpoint
     * @param array $headers
     * @return array
     */
    public function delete($endpoint, $headers = []) {
        $url = $this->buildUrl($endpoint);
        $request_headers = array_merge($this->default_headers, $headers);
        
        return $this->makeRequest('DELETE', $url, null, $request_headers);
    }
    
    /**
     * Make HTTP request with retry logic
     * 
     * @param string $method
     * @param string $url
     * @param array|null $data
     * @param array $headers
     * @param bool $long_running Whether this is a long-running operation (indexing, etc.)
     * @return array
     */
    private function makeRequest($method, $url, $data = null, $headers = [], $long_running = false) {
        // Use longer timeout for indexing/reindexing operations
        $timeout = $long_running ? $this->config['long_timeout'] : $this->config['timeout'];
        $retry_attempts = $this->config['retry_attempts'] ?? 1;
        $retry_delay = $this->config['retry_delay'] ?? 2;
        
        $args = [
            'method' => $method,
            'timeout' => $timeout,
            'headers' => $headers,
            'sslverify' => $this->config['verify_ssl'],
            'redirection' => 5,
            'httpversion' => '1.1',
            'blocking' => true,
            'cookies' => [],
            'compress' => true,  // Enable compression
        ];
        
        if ($data !== null && in_array($method, ['POST', 'PUT', 'PATCH'])) {
            $args['body'] = json_encode($data);
        }
        
        // Add request logging
        $this->logRequest($method, $url, $data, $headers);
        
        // Retry logic for timeout errors
        $last_error = null;
        for ($attempt = 0; $attempt <= $retry_attempts; $attempt++) {
            if ($attempt > 0) {
                // Wait before retry
                sleep($retry_delay);
                error_log(sprintf(
                    'Hybrid Search API: Retrying request (attempt %d/%d) - %s %s',
                    $attempt,
                    $retry_attempts + 1,
                    $method,
                    $url
                ));
            }
            
            $response = wp_remote_request($url, $args);
            
            // Check if it's a timeout error that we should retry
            if (is_wp_error($response)) {
                $error_code = $response->get_error_code();
                $error_message = $response->get_error_message();
                
                // Check if it's a timeout error
                if (strpos($error_message, 'timeout') !== false || 
                    strpos($error_message, 'timed out') !== false ||
                    $error_code === 'http_request_failed') {
                    $last_error = $response;
                    
                    // Don't retry if we've exhausted attempts or it's not a timeout
                    if ($attempt < $retry_attempts) {
                        continue; // Retry
                    }
                }
            }
            
            // Success or non-retryable error - return response
            return $this->handleResponse($response, $method, $url);
        }
        
        // All retries exhausted - return last error
        return $this->handleResponse($last_error, $method, $url);
    }
    
    /**
     * Handle HTTP response
     * 
     * @param array|\WP_Error $response
     * @param string $method
     * @param string $url
     * @return array
     */
    private function handleResponse($response, $method, $url) {
        if (is_wp_error($response)) {
            $error_message = $response->get_error_message();
            $error_code = $response->get_error_code();
            $this->logError($method, $url, $error_message);
            
            // Provide user-friendly error messages for common issues
            $user_friendly_error = $this->getUserFriendlyError($error_message, $error_code);
            
            return [
                'success' => false,
                'error' => $user_friendly_error,
                'error_details' => $error_message,
                'error_code' => $error_code,
                'data' => null,
                'status_code' => 0,
            ];
        }
        
        $status_code = wp_remote_retrieve_response_code($response);
        $body = wp_remote_retrieve_body($response);
        $headers = wp_remote_retrieve_headers($response);
        
        // Parse JSON response
        $data = json_decode($body, true);
        if (json_last_error() !== JSON_ERROR_NONE) {
            $this->logError($method, $url, 'Invalid JSON response: ' . json_last_error_msg());
            
            return [
                'success' => false,
                'error' => 'Invalid JSON response',
                'data' => null,
                'status_code' => $status_code,
                'raw_body' => $body,
            ];
        }
        
        $success = $status_code >= 200 && $status_code < 300;
        
        // Log response
        $this->logResponse($method, $url, $status_code, $data, $success);
        
        return [
            'success' => $success,
            'error' => $success ? null : $this->getErrorMessage($status_code, $data),
            'data' => $data,
            'status_code' => $status_code,
            'headers' => $headers,
        ];
    }
    
    /**
     * Build URL with endpoint and parameters
     * 
     * @param string $endpoint
     * @param array $params
     * @return string
     */
    private function buildUrl($endpoint, $params = []) {
        $url = rtrim($this->config['url'], '/') . '/' . ltrim($endpoint, '/');
        
        if (!empty($params)) {
            $url .= '?' . http_build_query($params);
        }
        
        return $url;
    }
    
    /**
     * Get error message from response
     * 
     * @param int $status_code
     * @param array $data
     * @return string
     */
    private function getErrorMessage($status_code, $data) {
        if (isset($data['error'])) {
            return $data['error'];
        }
        
        if (isset($data['message'])) {
            return $data['message'];
        }
        
        switch ($status_code) {
            case 400:
                return 'Bad Request';
            case 401:
                return 'Unauthorized';
            case 403:
                return 'Forbidden';
            case 404:
                return 'Not Found';
            case 429:
                return 'Too Many Requests';
            case 500:
                return 'Internal Server Error';
            case 502:
                return 'Bad Gateway';
            case 503:
                return 'Service Unavailable';
            default:
                return 'HTTP Error ' . $status_code;
        }
    }
    
    /**
     * Test API connection
     * 
     * @return array
     */
    public function testConnection() {
        $start_time = microtime(true);
        
        try {
            $response = $this->get('health');
            $end_time = microtime(true);
            $response_time = round(($end_time - $start_time) * 1000, 2);
            
            if ($response['success']) {
                return [
                    'success' => true,
                    'message' => 'API connection successful',
                    'response_time' => $response_time,
                    'status_code' => $response['status_code'],
                    'data' => $response['data'],
                ];
            } else {
                return [
                    'success' => false,
                    'message' => 'API connection failed: ' . $response['error'],
                    'response_time' => $response_time,
                    'status_code' => $response['status_code'],
                ];
            }
        } catch (Exception $e) {
            return [
                'success' => false,
                'message' => 'API connection failed: ' . $e->getMessage(),
                'response_time' => 0,
                'status_code' => 0,
            ];
        }
    }
    
    /**
     * Update configuration
     * 
     * @param array $config
     */
    public function updateConfig($config) {
        $this->config = wp_parse_args($config, $this->config);
        
        // Update authorization header if key changed
        if (isset($config['key'])) {
            if (!empty($config['key'])) {
                $this->default_headers['Authorization'] = 'Bearer ' . $config['key'];
            } else {
                unset($this->default_headers['Authorization']);
            }
        }
    }
    
    /**
     * Get current configuration
     * 
     * @return array
     */
    public function getConfig() {
        return $this->config;
    }
    
    /**
     * Log request
     * 
     * @param string $method
     * @param string $url
     * @param array|null $data
     * @param array $headers
     */
    private function logRequest($method, $url, $data, $headers) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log(sprintf(
                'Hybrid Search API Request: %s %s - Data: %s - Headers: %s',
                $method,
                $url,
                $data ? json_encode($data) : 'null',
                json_encode($headers)
            ));
        }
    }
    
    /**
     * Log response
     * 
     * @param string $method
     * @param string $url
     * @param int $status_code
     * @param array $data
     * @param bool $success
     */
    private function logResponse($method, $url, $status_code, $data, $success) {
        if (defined('WP_DEBUG') && WP_DEBUG) {
            error_log(sprintf(
                'Hybrid Search API Response: %s %s - Status: %d - Success: %s - Data: %s',
                $method,
                $url,
                $status_code,
                $success ? 'true' : 'false',
                json_encode($data)
            ));
        }
    }
    
    /**
     * Get user-friendly error message
     * 
     * @param string $error_message Raw error message
     * @param string $error_code Error code
     * @return string User-friendly error message
     */
    private function getUserFriendlyError($error_message, $error_code) {
        // Check for timeout errors
        if (strpos($error_message, 'timeout') !== false || 
            strpos($error_message, 'timed out') !== false ||
            strpos($error_message, 'Operation timed out') !== false) {
            return 'Search request timed out. The server may be processing a complex query. Please try again or simplify your search query.';
        }
        
        // Check for connection errors
        if (strpos($error_message, 'could not resolve host') !== false ||
            strpos($error_message, 'connection') !== false) {
            return 'Unable to connect to search server. Please check your internet connection and try again.';
        }
        
        // Check for SSL errors
        if (strpos($error_message, 'SSL') !== false ||
            strpos($error_message, 'certificate') !== false) {
            return 'SSL connection error. Please contact the administrator.';
        }
        
        // Generic error
        return 'Search request failed. Please try again.';
    }
    
    /**
     * Log error
     * 
     * @param string $method
     * @param string $url
     * @param string $error
     */
    private function logError($method, $url, $error) {
        error_log(sprintf(
            'Hybrid Search API Error: %s %s - Error: %s',
            $method,
            $url,
            $error
        ));
    }
}
